package com.mervolt.edits

import kotlin.math.*

/**
 * Mamorona terrain manodidina ny lalana:
 * - faritra fisaka manamorona ny lalana
 * - profil havoana na fidinana amin'ny sisiny
 * - rampe mitohy manomboka amin'ny haavo voafaritra
 */
object Gen {
    var flat = 5f
    val names = arrayOf("Havoana havanana", "Havoana havia", "Midina roa tonta", "Miakatra roa tonta")

    private class Nr(val d: Float, val lat: Float, val i: Int, val u: Float, val sAt: Float)

    private fun sm(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun nearest(rs: List<Row>, x: Float, z: Float): Nr {
        var bd = Float.POSITIVE_INFINITY
        var bi = 0
        var bu = 0f
        var lat = 0f
        var bs = 0f
        for (q in 0 until rs.size - 1) {
            val a = rs[q]; val b = rs[q + 1]
            val dx = b.cx - a.cx; val dz = b.cz - a.cz
            val l2 = dx * dx + dz * dz
            if (l2 < 1e-9f) continue
            val rawU = ((x - a.cx) * dx + (z - a.cz) * dz) / l2
            val u = rawU.coerceIn(0f, 1f)
            val px = a.cx + dx * u; val pz = a.cz + dz * u
            val d2 = (x - px) * (x - px) + (z - pz) * (z - pz)
            if (d2 < bd) {
                val len = sqrt(l2)
                bd = d2; bi = q; bu = u
                // Extrapole uniquement au-delà des deux extrémités pour le fondu longitudinal.
                val along = if ((q == 0 && rawU < 0f) || (q == rs.lastIndex - 1 && rawU > 1f)) rawU else u
                bs = a.s + (b.s - a.s) * along
                lat = ((x - px) * -dz + (z - pz) * dx) / len
            }
        }
        if (!bd.isFinite()) return Nr(Float.POSITIVE_INFINITY, 0f, 0, 0f, 0f)
        return Nr(sqrt(bd), lat, bi, bu, bs)
    }

    /** Mamerina ny haavo farany (endH) mba hahafahan'ny génération manaraka manohy azy. */
    fun apply(
        ts: List<Terrain>, rs: List<Row>, profile: Int, rise: Float,
        hf: (Float, Float) -> Float, others: List<List<Row>>,
        forcedStartH: Float? = null, joinStart: Boolean = false
    ): Float {
        if (rs.isEmpty()) return forcedStartH ?: 0f
        val n = rs.size
        if (n < 2) return forcedStartH ?: hf(rs.first().cx, rs.first().cz)

        val base = FloatArray(n) { hf(rs[it].cx, rs[it].cz) }
        val smBase = FloatArray(n) { i ->
            var sum = 0f; var count = 0
            for (k in max(0, i - 8)..min(n - 1, i + 8)) { sum += base[k]; count++ }
            sum / count
        }
        val startH = forcedStartH ?: smBase.first()
        val endH = startH + rise
        val total = max(1f, rs.last().s)
        val hc = FloatArray(n) { i -> startH + rise * sm((rs[i].s / total).coerceIn(0f, 1f)) }

        val half = Road.width / 2f + flat
        val reach = 60f
        val endBlendDist = 12f
        val minx = rs.minOf { it.cx } - reach; val maxx = rs.maxOf { it.cx } + reach
        val minz = rs.minOf { it.cz } - reach; val maxz = rs.maxOf { it.cz } + reach
        val aff = HashMap<Terrain, ArrayList<Pair<Int, Float>>>()

        for (t in ts) for (j in 0 until t.n) {
            val wz = t.oz + t.cc(j)
            if (wz < minz || wz > maxz) continue
            for (i in 0 until t.n) {
                val wx = t.ox + t.cc(i)
                if (wx < minx || wx > maxx) continue
                val nr = nearest(rs, wx, wz); val a = nr.d
                if (a > reach) continue
                var skip = false
                for (o in others) if (o.size >= 2 && nearest(o, wx, wz).d + 0.5f < a) { skip = true; break }
                if (skip) continue

                val hcAt = hc[nr.i] + (hc[nr.i + 1] - hc[nr.i]) * nr.u
                val m = max(0f, a - half)
                val hill = when (profile) { 0 -> nr.lat > 0f; 1 -> nr.lat < 0f; 2 -> false; else -> true }
                val e = m - 6f * (1f - exp(-m / 6f))
                val amp = if (hill) 14f else 10f
                val slope = if (hill) 0.55f else 0.45f
                val off = if (m <= 0f) 0f else (if (hill) 1f else -1f) * amp * tanh(slope * e / amp)
                val noise = (sin(wx * 0.13f) * cos(wz * 0.17f) + 0.5f * sin(wx * 0.31f + wz * 0.23f)) * min(1f, m / 15f) * 1.2f
                val targetH = hcAt + off + noise
                val lateralW = if (a <= 30f) 1f else 1f - sm((a - 30f) / (reach - 30f))
                val distFromStart = max(0f, -nr.sAt)
                val distFromEnd = max(0f, nr.sAt - total)
                val startW = if (joinStart || distFromStart <= 0f) 1f else 1f - sm(distFromStart / endBlendDist)
                val endW = if (distFromEnd <= 0f) 1f else 1f - sm(distFromEnd / endBlendDist)
                val w = lateralW * min(startW, endW)
                val k = j * t.n + i
                val blended = if (a <= half) {
                    val roadBlend = sm((a / max(0.01f, half)).coerceIn(0f, 1f))
                    val desiredRoadH = t.h[k] * (1f - roadBlend) + hcAt * roadBlend
                    t.h[k] * (1f - w) + desiredRoadH * w
                } else t.h[k] * (1f - w) + targetH * w
                t.setH(k, blended)
                aff.getOrPut(t) { ArrayList() }.add(k to a)
            }
        }
        repeat(2) {
            for ((t, list) in aff) {
                val cp = t.h.copyOf(); val nn = t.n
                for ((k, a) in list) {
                    if (a <= half) continue
                    val i = k % nn; val j = k / nn
                    val avg = (cp[j * nn + max(i - 1, 0)] + cp[j * nn + min(i + 1, nn - 1)] +
                        cp[max(j - 1, 0) * nn + i] + cp[min(j + 1, nn - 1) * nn + i]) / 4f
                    t.setH(k, cp[k] * 0.5f + avg * 0.5f)
                }
            }
        }
        return endH
    }
}
