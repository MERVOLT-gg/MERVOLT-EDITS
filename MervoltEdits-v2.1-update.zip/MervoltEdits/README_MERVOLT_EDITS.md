# MERVOLT EDITS — Fanavaozana terrain generation

## Fanovana tafiditra
- Fanatsarana ny `Gen.kt` amin'ny profil terrain sy ny ramp.
- Fitehirizana ny haavo farany (`endH`) isaky ny génération.
- Fanohizana génération vaovao amin'ny haavo faran'ny génération teo aloha rehefa mifandray amin'ny tendrony farany.
- Fiarovana ny projets taloha: mbola ekena ny format `MEV2` taloha, ary ampiasaina ny format `MEV3` amin'ny sauvegarde vaovao.

## Fichiers novaina
- `app/src/main/java/com/mervolt/edits/Gen.kt`
- `app/src/main/java/com/mervolt/edits/MainActivity.kt`

## Fanamarinana
Alefaso ao amin'ny repository ny projet, manaova commit/push, ary jereo ny **Actions**. Rehefa vita ny workflow **Build APK**, alao ny artifact `MervoltEdits-apk`.

## Fanamarihana
Fanavaozana ny projet source efa misy ity fa tsy APK vaovao misaraka. Tehirizo aloha ny version taloha ho backup ary andramo amin'ny copie iray amin'ny profil taloha aloha ny APK vaovao.
