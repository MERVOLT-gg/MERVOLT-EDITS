# MERVOLT EDITS Claude ai - Dingana 1
Viewer OBJ + MTL + PNG, Separate by Material (anarana: base, base.001, ...), Export .3ds mivantana.

## Fananganana APK
**Android Studio:** File > Open > lahatahiry ity > Build > Build APK(s).
**GitHub (telefaona fotsiny):** apetraho ao amin'ny repo GitHub; Actions > "Build APK" > alaivo ny artifact "MervoltEdits-apk".

## Fampiasana
1. "Sokafy OBJ": aleo misafidy lahatahiry misy .obj + .mtl + PNG.
2. 1 rantsantanana = mihodina, 2 rantsantanana = zoom.
3. "Export .3ds": manoratra <anarana>.3ds ao amin'ny lahatahiry iray ihany (PNG efa ao).
Ny objet mizara ho azy isaky ny material. Ny _cutout_ dia mahazo opacity map (0xA210).
