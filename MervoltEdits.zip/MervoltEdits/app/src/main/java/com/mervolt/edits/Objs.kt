package com.mervolt.edits

import kotlin.math.*

/** Objet azo afindra/hodina/ovaina habe. Ny Part dia tazonina amin'ny tontolo (world). */
class Obj3(val name: String, val parts: List<Part>, val snap: Boolean) {
    val base = parts.map { it.pos.copyOf() }
    var cat = -1; var cid = 0
    var src: Obj3? = null   // ny modely nanomezana ny clone (ho an'ny vegetation)
    /** Clone ho an'ny generate objet: mitovy material (ka mitovy texture), manaraka ny terrain (snap). */
    fun cloneAs(n: String): Obj3 {
        val ps = parts.mapIndexed { i, p -> Part("${n}_$i", p.mat, base[i].copyOf(), p.uv, p.idx).also { it.smooth = p.smooth; it.quad = p.quad; it.poly = p.poly; it.polySizes = p.polySizes } }
        return Obj3(n, ps, true).also { it.src = src ?: this }
    }
    var x = 0f; var y = 0f; var z = 0f; var yaw = 0f; var scale = 1f
    fun apply() {
        val c = cos(yaw); val s = sin(yaw)
        for ((pi, p) in parts.withIndex()) { val b = base[pi]
            for (i in 0 until b.size / 3) { val bx = b[i * 3] * scale; val by = b[i * 3 + 1] * scale; val bz = b[i * 3 + 2] * scale
                p.pos[i * 3] = x + bx * c + bz * s; p.pos[i * 3 + 1] = y + by; p.pos[i * 3 + 2] = z - bx * s + bz * c } }
    }
    /** Mamadika ny pivot ho afovoan'ny objet (ho an'ny OBJ nampidirina): ny Rot/Sc dia manodidina ny afovoany. */
    fun recenter() {
        val b = bounds(); val cx = (b[0] + b[3]) / 2; val cy = b[1]; val cz = (b[2] + b[5]) / 2
        for (a in base) for (i in 0 until a.size / 3) { a[i * 3] -= cx; a[i * 3 + 1] -= cy; a[i * 3 + 2] -= cz }
        x = cx; y = cy; z = cz; apply()
    }
    fun state() = floatArrayOf(x, y, z, yaw, scale)
    fun restore(s: FloatArray) { x = s[0]; y = s[1]; z = s[2]; yaw = s[3]; scale = s[4]; apply() }
    fun bounds(): FloatArray {
        val b = floatArrayOf(1e9f, 1e9f, 1e9f, -1e9f, -1e9f, -1e9f)
        for (p in parts) for (i in p.pos.indices) { val k = i % 3; if (p.pos[i] < b[k]) b[k] = p.pos[i]; if (p.pos[i] > b[k + 3]) b[k + 3] = p.pos[i] }
        return b
    }
}

private class B {
    val pos = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>()
    private fun face(c: FloatArray) {
        val b = pos.size / 3; for (v in c) pos.add(v)
        uv.addAll(listOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)); idx.addAll(listOf(b, b + 2, b + 1, b, b + 3, b + 2))
    }
    fun box(cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float) {
        val x0 = cx - w / 2; val x1 = cx + w / 2; val y0 = cy - h / 2; val y1 = cy + h / 2; val z0 = cz - d / 2; val z1 = cz + d / 2
        face(floatArrayOf(x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0))
        face(floatArrayOf(x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1))
        face(floatArrayOf(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1))
        face(floatArrayOf(x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0))
        face(floatArrayOf(x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1))
        face(floatArrayOf(x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0))
    }
    fun pyramid(cx: Float, y0: Float, cz: Float, w: Float, d: Float, h: Float) {
        val a = floatArrayOf(cx - w / 2, y0, cz - d / 2); val b = floatArrayOf(cx + w / 2, y0, cz - d / 2)
        val c = floatArrayOf(cx + w / 2, y0, cz + d / 2); val e = floatArrayOf(cx - w / 2, y0, cz + d / 2)
        val t = floatArrayOf(cx, y0 + h, cz)
        for (tri in listOf(listOf(b, a), listOf(c, b), listOf(e, c), listOf(a, e))) {
            val s = pos.size / 3; for (v in listOf(tri[0], tri[1], t)) for (f in v) pos.add(f)
            uv.addAll(listOf(0f, 0f, 1f, 0f, 0.5f, 1f)); idx.addAll(listOf(s, s + 1, s + 2))
        }
    }
    fun part(name: String, color: FloatArray) = Part(name, Mat(name).apply { kd = color }, pos.toFloatArray(), uv.toFloatArray(), idx.toIntArray())
}

object Catalog {
    val names = arrayOf("Trano", "Trano vato etage", "Tetezana", "Tambo", "Poto jirama")
    fun make(i: Int, id: Int): Obj3 {
        val tag = "%s_%02d".format(arrayOf("trano", "tranovato", "tetezana", "tambo", "poto")[i], id)
        val ps = ArrayList<Part>()
        when (i) {
            0 -> { val w = B(); w.box(0f, 1.5f, 0f, 6f, 3f, 5f); ps.add(w.part("${tag}_rindrina", floatArrayOf(0.85f, 0.8f, 0.7f)))
                   val r = B(); r.pyramid(0f, 3f, 0f, 7f, 6f, 2f); ps.add(r.part("${tag}_tafo", floatArrayOf(0.6f, 0.25f, 0.2f))) }
            1 -> { val w = B(); w.box(0f, 3f, 0f, 8f, 6f, 6f); w.box(0f, 3f, 0f, 8.3f, 0.3f, 6.3f); ps.add(w.part("${tag}_rindrina", floatArrayOf(0.62f, 0.6f, 0.58f)))
                   val r = B(); r.box(0f, 6.2f, 0f, 8.6f, 0.4f, 6.6f); ps.add(r.part("${tag}_tafo", floatArrayOf(0.4f, 0.38f, 0.36f))) }
            2 -> { val d = B(); d.box(0f, 0.8f, 0f, 4f, 0.4f, 14f); d.box(0f, 0.3f, -5f, 3.6f, 0.6f, 0.8f); d.box(0f, 0.3f, 5f, 3.6f, 0.6f, 0.8f)
                   ps.add(d.part("${tag}_dalle", floatArrayOf(0.55f, 0.55f, 0.55f)))
                   val r = B(); r.box(-1.9f, 1.5f, 0f, 0.2f, 1f, 14f); r.box(1.9f, 1.5f, 0f, 0.2f, 1f, 14f); ps.add(r.part("${tag}_rampe", floatArrayOf(0.5f, 0.4f, 0.3f))) }
            3 -> { val f = B(); for (k in -2..2) f.box(k * 2f, 0.6f, 0f, 0.2f, 1.2f, 0.2f); f.box(0f, 0.4f, 0f, 10f, 0.1f, 0.1f); f.box(0f, 0.9f, 0f, 10f, 0.1f, 0.1f)
                   ps.add(f.part(tag, floatArrayOf(0.55f, 0.4f, 0.25f))) }
            else -> { val f = B(); f.box(0f, 4f, 0f, 0.25f, 8f, 0.25f); f.box(0f, 7.6f, 0f, 2f, 0.15f, 0.15f); ps.add(f.part(tag, floatArrayOf(0.45f, 0.38f, 0.3f))) }
        }
        return Obj3(tag, ps, true).also { it.cat = i; it.cid = id }
    }
}
