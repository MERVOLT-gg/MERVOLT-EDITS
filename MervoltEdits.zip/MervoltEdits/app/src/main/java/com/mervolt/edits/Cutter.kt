package com.mervolt.edits

import kotlin.math.*

/** Mitapaka ny mesh an'ny terrain ihany ho road (polygon clipping): ny triangle mizara eo amin'ny sisin'ny road, ary ny ao anatiny dia material road. */
object Cutter {
    private const val EPS = 1e-6

    private class Q(val p: DoubleArray, val sgn: Double, val a: Row, val b: Row, val rough: Boolean) {
        val minx = min(min(p[0], p[2]), min(p[4], p[6])); val maxx = max(max(p[0], p[2]), max(p[4], p[6]))
        val minz = min(min(p[1], p[3]), min(p[5], p[7])); val maxz = max(max(p[1], p[3]), max(p[5], p[7]))
    }

    private class MB(val t: Terrain) {
        val pos = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>(); val map = HashMap<Long, Int>()
        fun v(x: Double, z: Double, q: Q?): Int = map.getOrPut(Math.round(x * 1000) * 1000003L + Math.round(z * 1000)) {
            pos.add(x.toFloat()); pos.add(t.height(x.toFloat(), z.toFloat())); pos.add(z.toFloat())
            if (q == null) { uv.add((x / 10).toFloat()); uv.add((z / 10).toFloat()) }
            else {
                val a = q.a; val b = q.b
                var tx = (b.cx - a.cx).toDouble(); var tz = (b.cz - a.cz).toDouble(); val tl = hypot(tx, tz).let { if (it < 1e-6) 1.0 else it }; tx /= tl; tz /= tl
                var rx = ((a.rx - a.lx) + (b.rx - b.lx)) / 2.0; var rz = ((a.rz - a.lz) + (b.rz - b.lz)) / 2.0
                val w = hypot(rx, rz).let { if (it < 1e-6) 1.0 else it }; rx /= w; rz /= w
                val mx = (a.cx + b.cx) / 2.0; val mz = (a.cz + b.cz) / 2.0
                uv.add((0.5 + ((x - mx) * rx + (z - mz) * rz) / w).toFloat()); uv.add(((a.s + (x - a.cx) * tx + (z - a.cz) * tz) / w).toFloat())
            }
            pos.size / 3 - 1
        }
        fun poly(p: DoubleArray, q: Q?) {
            val pts = ArrayList<DoubleArray>()
            for (i in 0 until p.size / 2) { val x = p[i * 2]; val z = p[i * 2 + 1]; val l = pts.lastOrNull()
                if (l == null || hypot(x - l[0], z - l[1]) > 1e-6) pts.add(doubleArrayOf(x, z)) }
            if (pts.size > 1 && hypot(pts.first()[0] - pts.last()[0], pts.first()[1] - pts.last()[1]) < 1e-6) pts.removeAt(pts.lastIndex)
            if (pts.size < 3) return
            val ids = pts.map { v(it[0], it[1], q) }
            for (i in 1 until ids.size - 1) {
                val a = pts[0]; val b = pts[i]; val c = pts[i + 1]
                if (abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) < 1e-9) continue
                idx.add(ids[0]); idx.add(ids[i]); idx.add(ids[i + 1])
            }
        }
    }

    private fun shoe(p: DoubleArray): Double { var s = 0.0; val n = p.size / 2; for (i in 0 until n) { val j = (i + 1) % n; s += p[i * 2] * p[j * 2 + 1] - p[j * 2] * p[i * 2 + 1] }; return s / 2 }
    private fun area(p: DoubleArray): Double = if (p.size < 6) 0.0 else abs(shoe(p))

    private fun clip(poly: DoubleArray, q: DoubleArray, k: Int, sgn: Double, inside: Boolean): DoubleArray {
        val ax = q[k * 2]; val az = q[k * 2 + 1]; val bx = q[((k + 1) % 4) * 2]; val bz = q[((k + 1) % 4) * 2 + 1]
        val n = poly.size / 2; val out = ArrayList<Double>()
        for (i in 0 until n) {
            val j = (i + 1) % n
            val x0 = poly[i * 2]; val z0 = poly[i * 2 + 1]; val x1 = poly[j * 2]; val z1 = poly[j * 2 + 1]
            var f0 = sgn * ((bx - ax) * (z0 - az) - (bz - az) * (x0 - ax)); var f1 = sgn * ((bx - ax) * (z1 - az) - (bz - az) * (x1 - ax))
            if (!inside) { f0 = -f0; f1 = -f1 }
            val in0 = f0 >= 0; val in1 = f1 >= 0
            if (in0) { out.add(x0); out.add(z0) }
            if (in0 != in1) { val t = f0 / (f0 - f1); out.add(x0 + (x1 - x0) * t); out.add(z0 + (z1 - z0) * t) }
        }
        return out.toDoubleArray()
    }

    /** Mizara ny piece ho anatiny (ao amin'ny quad) sy ivelany (sisiny aloha, avy eo tendron'ny quad). */
    private fun split(piece: DoubleArray, q: Q): Pair<DoubleArray?, List<DoubleArray>> {
        var rem = piece; val outs = ArrayList<DoubleArray>()
        for (k in intArrayOf(1, 3, 0, 2)) {
            val o = clip(rem, q.p, k, q.sgn, false); if (area(o) > EPS) outs.add(o)
            rem = clip(rem, q.p, k, q.sgn, true); if (area(rem) <= EPS) return Pair(null, listOf(piece))
        }
        return Pair(rem, outs)
    }

    /** Miverina null raha tsy misy road mikasika ity terrain ity (mijanona ilay grid tany am-boalohany). */
    fun cut(t: Terrain, rows: List<List<Row>>, rough: List<Boolean>, roadMat: Mat): List<Part>? {
        val qs = ArrayList<Q>()
        for ((ri, rs) in rows.withIndex()) for (j in 0 until rs.size - 1) {
            val a = rs[j]; val b = rs[j + 1]
            val p = doubleArrayOf(a.lx.toDouble(), a.lz.toDouble(), a.rx.toDouble(), a.rz.toDouble(), b.rx.toDouble(), b.rz.toDouble(), b.lx.toDouble(), b.lz.toDouble())
            val ar = shoe(p); if (abs(ar) < 1e-6) continue
            qs.add(Q(p, if (ar > 0) 1.0 else -1.0, a, b, rough[ri]))
        }
        if (qs.isEmpty()) return null
        val cs = 8.0; val grid = HashMap<Long, ArrayList<Int>>()
        fun key(gx: Int, gz: Int) = (gx.toLong() shl 32) xor (gz.toLong() and 0xffffffffL)
        for ((qi, q) in qs.withIndex()) for (gx in floor(q.minx / cs).toInt()..floor(q.maxx / cs).toInt()) for (gz in floor(q.minz / cs).toInt()..floor(q.maxz / cs).toInt())
            grid.getOrPut(key(gx, gz)) { ArrayList() }.add(qi)
        val g = MB(t); val rd = MB(t); var touched = false
        val n = t.n
        for (j in 0 until n - 1) for (i in 0 until n - 1) {
            val x0 = (t.ox + t.cc(i)).toDouble(); val x1 = (t.ox + t.cc(i + 1)).toDouble(); val z0 = (t.oz + t.cc(j)).toDouble(); val z1 = (t.oz + t.cc(j + 1)).toDouble()
            for (poly in arrayOf(doubleArrayOf(x0, z0, x0, z1, x1, z0), doubleArrayOf(x1, z0, x0, z1, x1, z1))) {
                val mnx = min(min(poly[0], poly[2]), poly[4]); val mxx = max(max(poly[0], poly[2]), poly[4])
                val mnz = min(min(poly[1], poly[3]), poly[5]); val mxz = max(max(poly[1], poly[3]), poly[5])
                val cand = java.util.TreeSet<Int>()
                for (gx in floor(mnx / cs).toInt()..floor(mxx / cs).toInt()) for (gz in floor(mnz / cs).toInt()..floor(mxz / cs).toInt())
                    grid[key(gx, gz)]?.let { l -> for (qi in l) { val q = qs[qi]; if (q.maxx >= mnx && q.minx <= mxx && q.maxz >= mnz && q.minz <= mxz) cand.add(qi) } }
                if (cand.isEmpty()) { g.poly(poly, null); continue }
                touched = true
                var outs = arrayListOf(poly)
                for (qi in cand) {
                    val q = qs[qi]; val next = ArrayList<DoubleArray>()
                    for (pc in outs) {
                        var a0 = 1e18; var a1 = -1e18; var b0 = 1e18; var b1 = -1e18
                        for (m in 0 until pc.size / 2) { a0 = min(a0, pc[m * 2]); a1 = max(a1, pc[m * 2]); b0 = min(b0, pc[m * 2 + 1]); b1 = max(b1, pc[m * 2 + 1]) }
                        if (q.maxx < a0 || q.minx > a1 || q.maxz < b0 || q.minz > b1) { next.add(pc); continue }
                        val (ins, os) = split(pc, q)
                        if (ins != null && !q.rough) rd.poly(ins, q)   // road lavaka: ny mesh lavaka no mameno ny fonenana
                        next.addAll(os)
                    }
                    outs = next
                }
                for (pc in outs) g.poly(pc, null)
            }
        }
        if (!touched) return null
        val out = ArrayList<Part>()
        if (g.idx.isNotEmpty()) out.add(Part(t.name, t.part.mat, g.pos.toFloatArray(), g.uv.toFloatArray(), g.idx.toIntArray()).also { it.smooth = true })
        if (rd.idx.isNotEmpty()) out.add(Part("${t.name}_road", roadMat, rd.pos.toFloatArray(), rd.uv.toFloatArray(), rd.idx.toIntArray()).also { it.smooth = true })
        return out
    }
}
