package com.mervolt.edits

import kotlin.math.*

/** Mamorona ho azy ny endriky ny terrain manodidina ny lalana: sisiny iray mitsangana (havoana), ny iray mianjera, ary 5 m plate eo akaikin'ny road. */
object Gen {
    var flat = 5f

    fun apply(ts: List<Terrain>, paths: List<List<Row>>, hillRight: Boolean, hf: (Float, Float) -> Float) {
        for (rs in paths) {
            val n = rs.size; if (n < 2) continue
            val base = FloatArray(n) { hf(rs[it].cx, rs[it].cz) }
            val hc = FloatArray(n) { i -> var s = 0f; var c = 0; for (k in max(0, i - 5)..min(n - 1, i + 5)) { s += base[k]; c++ }; s / c }   // lalana malama
            val half = Road.width / 2 + flat; val reach = 60f
            val minx = rs.minOf { it.cx } - reach; val maxx = rs.maxOf { it.cx } + reach; val minz = rs.minOf { it.cz } - reach; val maxz = rs.maxOf { it.cz } + reach
            for (t in ts) for (j in 0 until t.n) for (i in 0 until t.n) {
                val x = t.ox + t.cc(i); val z = t.oz + t.cc(j)
                if (x < minx || x > maxx || z < minz || z > maxz) continue
                var bd = 1e18f; var bi = 0; var bu = 0f; var lat = 0f
                for (q in 0 until n - 1) {
                    val a = rs[q]; val b = rs[q + 1]; val dx = b.cx - a.cx; val dz = b.cz - a.cz; val l2 = dx * dx + dz * dz
                    if (l2 < 1e-9f) continue
                    val u = (((x - a.cx) * dx + (z - a.cz) * dz) / l2).coerceIn(0f, 1f); val px = a.cx + dx * u; val pz = a.cz + dz * u
                    val d2 = (x - px) * (x - px) + (z - pz) * (z - pz)
                    if (d2 < bd) { bd = d2; bi = q; bu = u; lat = ((x - px) * -dz + (z - pz) * dx) / sqrt(l2) }
                }
                val a = sqrt(bd); if (a > reach) continue
                val hcAt = hc[bi] + (hc[bi + 1] - hc[bi]) * bu
                val m = max(0f, a - half)
                val hill = (lat > 0) == hillRight
                val off = if (a <= half) 0f else if (hill) min(m * 0.55f, 14f) else -min(m * 0.45f, 10f)
                val noise = (sin(x * 0.13f) * cos(z * 0.17f) + 0.5f * sin(x * 0.31f + z * 0.23f)) * min(1f, m / 15f) * 1.2f
                val w = if (a <= 30f) 1f else { val u = ((a - 30f) / (reach - 30f)).coerceIn(0f, 1f); 1 - u * u * (3 - 2 * u) }
                val k = j * t.n + i
                t.setH(k, t.h[k] * (1 - w) + (hcAt + off + noise) * w)
            }
        }
    }
}
