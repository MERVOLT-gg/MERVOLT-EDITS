package com.mervolt.edits

/** Export .obj + .mtl (texture PNG tazonina araka ny anarany ao amin'ny map_Kd). */
object ObjWriter {
    fun write(parts: List<Part>, name: String): Pair<String, String> {
        val o = StringBuilder("mtllib $name.mtl\n"); var base = 0
        for (p in parts) {
            o.append("o ").append(p.name).append('\n')
            for (i in 0 until p.pos.size / 3) o.append("v ").append(p.pos[i * 3]).append(' ').append(p.pos[i * 3 + 1]).append(' ').append(p.pos[i * 3 + 2]).append('\n')
            for (i in 0 until p.uv.size / 2) o.append("vt ").append(p.uv[i * 2]).append(' ').append(p.uv[i * 2 + 1]).append('\n')
            o.append("usemtl ").append(p.mat.name.replace(' ', '_')).append('\n')
            for (t in 0 until p.idx.size / 3) {
                val a = p.idx[t * 3] + 1 + base; val b = p.idx[t * 3 + 1] + 1 + base; val c = p.idx[t * 3 + 2] + 1 + base
                o.append("f $a/$a $b/$b $c/$c\n")
            }
            base += p.pos.size / 3
        }
        val m = StringBuilder()
        for (mt in parts.map { it.mat }.distinctBy { it.name }) {
            m.append("newmtl ${mt.name.replace(' ', '_')}\nKd ${mt.kd[0]} ${mt.kd[1]} ${mt.kd[2]}\n")
            mt.tex?.let { m.append("map_Kd $it\n") }
        }
        return o.toString() to m.toString()
    }
}
