package com.mervolt.edits

import kotlin.math.*

/** Andalana iray amin'ny lalana: sisiny havia (l), havanana (r), afovoany (c), halavany (s). */
class Row(val lx: Float, val lz: Float, val rx: Float, val rz: Float, val cx: Float, val cz: Float, val s: Float)

object Road {
    var width = 4f; var spacing = 1f; var raise = 0.12f; var shoulder = 0.8f

    /** Catmull-Rom centripetal: tsy misy overshoot na kink, na tsy mitovy elanelana ny teboka (soratra amin'ny tanana). */
    private fun cp(p0: FloatArray, p1: FloatArray, p2: FloatArray, p3: FloatArray, t: Float): FloatArray {
        fun d(a: FloatArray, b: FloatArray) = max(1e-3f, sqrt(sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]))))
        fun lp(a: FloatArray, b: FloatArray, ta: Float, tb: Float, x: Float): FloatArray { val f = (x - ta) / (tb - ta); return floatArrayOf(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f) }
        val t0 = 0f; val t1 = t0 + d(p0, p1); val t2 = t1 + d(p1, p2); val t3 = t2 + d(p2, p3); val u = t1 + (t2 - t1) * t
        val a1 = lp(p0, p1, t0, t1, u); val a2 = lp(p1, p2, t1, t2, u); val a3 = lp(p2, p3, t2, t3, u)
        return lp(lp(a1, a2, t0, t2, u), lp(a2, a3, t1, t3, u), t1, t2, u)
    }

    private fun dense(p: List<FloatArray>, pre: FloatArray?, post: FloatArray?): List<FloatArray> {
        val out = ArrayList<FloatArray>(); val last = p.size - 1
        for (i in 0 until last) {
            val p0 = if (i >= 1) p[i - 1] else (pre ?: p[0]); val p1 = p[i]; val p2 = p[i + 1]; val p3 = if (i + 2 <= last) p[i + 2] else (post ?: p[last])
            for (s in 0 until 12) out.add(cp(p0, p1, p2, p3, s / 12f))
        }
        out.add(p[last]); return out
    }

    private fun resample(d: List<FloatArray>, step: Float, hf: (Float, Float) -> Float): List<FloatArray> {
        val out = ArrayList<FloatArray>(); out.add(d[0]); var acc = 0f
        for (i in 1 until d.size) {
            val a = d[i - 1]; val b = d[i]
            val dy = hf(b[0], b[1]) - hf(a[0], a[1])
            val len = sqrt((b[0] - a[0]).pow(2) + dy * dy + (b[1] - a[1]).pow(2))
            if (len < 1e-5f) continue
            var pos = step - acc
            while (pos <= len) { val f = pos / len
                out.add(floatArrayOf(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)); pos += step }
            acc = len - (pos - step)
        }
        return out
    }

    private fun right(a: FloatArray, b: FloatArray): FloatArray? {
        val dx = b[0] - a[0]; val dz = b[1] - a[1]; val l = sqrt(dx * dx + dz * dz)
        return if (l < 1e-4f) null else floatArrayOf(-dz / l, dx / l)
    }

    /** Andalana: step<=1 -> isaky ny 1 m. step>1 -> mahitsy 2 m, virage 1 m (malama kokoa). s = halavany (m). */
    fun rows(ctrl: List<FloatArray>, hf: (Float, Float) -> Float, step: Float, pre: FloatArray?, post: FloatArray?): List<Row> {
        val dn = dense(ctrl, pre, post); val f0 = resample(dn, 1f, hf)
        val fine = if (hypot(f0.last()[0] - dn.last()[0], f0.last()[1] - dn.last()[1]) > 0.05f) f0 + listOf(dn.last()) else f0   // mifarana marina amin'ny tendrony
        val idx = ArrayList<Int>(); var i = 0
        while (i < fine.size) {
            idx.add(i)
            if (step <= 1f || i + 2 >= fine.size) i += 1
            else {
                val a = fine[i]; val b = fine[i + 1]; val c = fine[i + 2]
                var da = abs(atan2(c[1] - b[1], c[0] - b[0]) - atan2(b[1] - a[1], b[0] - a[0])); if (da > 3.1415927f) da = 6.2831855f - da
                i += if (da > 0.1f) 1 else 2
            }
        }
        if (idx.last() != fine.lastIndex) idx.add(fine.lastIndex)
        val cs = idx.map { fine[it] }
        return cs.indices.map { k ->
            val r = right(cs[max(k - 1, 0)], cs[min(k + 1, cs.lastIndex)]) ?: floatArrayOf(0f, 1f); val c = cs[k]
            Row(c[0] - r[0] * width / 2, c[1] - r[1] * width / 2, c[0] + r[0] * width / 2, c[1] + r[1] * width / 2, c[0], c[1], idx[k].toFloat())
        }
    }

    /** Road = mesh ambony terrain, miendrika trapeze: tampon'ny lalana misondrona kely (raise), ary ny sisiny (shoulder) mianjera ao anatin'ny terrain.
     *  Tsotra: carré 2x2 m. Lavaka: carré 1x1 m miaraka amin'ny lavaka. */
    fun mesh(rows: List<Row>, hf: (Float, Float) -> Float, rough: Boolean, id: Int, mat: Mat, lowFirst: Boolean = false, lowLast: Boolean = false): Part? {
        if (rows.size < 2) return null
        val cols = max(1, (if (rough) width else width / 2).roundToInt()); val cell = width / cols
        val offs = ArrayList<Float>(); offs.add(-(width / 2 + shoulder)); for (k in 0..cols) offs.add((k - cols / 2f) * cell); offs.add(width / 2 + shoulder)
        val nc = offs.size
        val pos = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>()
        for ((i, r) in rows.withIndex()) {
            val rx = r.rx - r.lx; val rz = r.rz - r.lz; val w = hypot(rx, rz).let { if (it < 1e-6f) 1f else it }
            for ((c, o) in offs.withIndex()) {
                val x = r.cx + rx / w * o; val z = r.cz + rz / w * o
                pos.add(x); pos.add(hf(x, z) + (if (c == 0 || c == nc - 1) -0.12f else raise)); pos.add(z)
                uv.add(o / width + 0.5f); uv.add(r.s / width)
            }
            if (i > 0) for (c in 0 until nc - 1) {
                val p0 = (i - 1) * nc + c; val p1 = p0 + 1; val p2 = i * nc + c; val p3 = p2 + 1
                idx.addAll(listOf(p0, p1, p3, p0, p3, p2))
            }
        }
        for (pass in 0 until 2) {   // famafana ny haavony araka ny lalana (road malama)
            val ys = FloatArray(rows.size * nc) { pos[it * 3 + 1] }
            for (i in 1 until rows.size - 1) for (c in 0 until nc) pos[(i * nc + c) * 3 + 1] = ys[(i - 1) * nc + c] * 0.25f + ys[i * nc + c] * 0.5f + ys[(i + 1) * nc + c] * 0.25f
        }
        if (rough && rows.size > 7) {
            val rnd = java.util.Random(7L + id)
            repeat(max(1, rows.size / 8)) {
                val ri = 3 + rnd.nextInt(rows.size - 6); val lo = (rnd.nextFloat() - 0.5f) * (width - 1.6f)
                val rad = 0.8f + rnd.nextFloat() * 0.8f; val dep = 0.1f + rnd.nextFloat() * 0.15f
                for (i in max(0, ri - 2)..min(rows.size - 1, ri + 2)) for (c in 1..nc - 2) {
                    val dd = hypot(offs[c] - lo, rows[i].s - rows[ri].s)
                    if (dd < rad) { val f = 1 - dd / rad; val yi = (i * nc + c) * 3 + 1; pos[yi] = pos[yi] - dep * f * f * (3 - 2 * f) }
                }
            }
            for (i in 1 until rows.size - 1) for (c in 1..nc - 2) { val yi = (i * nc + c) * 3 + 1; pos[yi] = pos[yi] + (rnd.nextFloat() - 0.5f) * 0.03f }
        }
        if (lowFirst) for (c in 0 until nc) pos[c * 3 + 1] = pos[c * 3 + 1] - 0.04f                                 // sampana: tendrony ambanin'ny lalana lehibe
        if (lowLast) for (c in 0 until nc) { val yi = ((rows.size - 1) * nc + c) * 3 + 1; pos[yi] = pos[yi] - 0.04f }
        return Part((if (rough) "roadlava_%02d" else "road_%02d").format(id), mat, pos.toFloatArray(), uv.toFloatArray(), idx.toIntArray()).also { it.smooth = true }
    }

    /** Traffic: carré 1 (quad tokana), lane iray, mifandimby tsy misy banga, manaraka ny sens an'ny road. */
    fun traffic(ctrl: List<FloatArray>, hf: (Float, Float) -> Float, pre: FloatArray?, post: FloatArray?, counter: IntArray): List<Part> {
        val out = ArrayList<Part>()
        val dn = dense(ctrl, pre, post); val t0 = resample(dn, spacing, hf)
        val tr = if (hypot(t0.last()[0] - dn.last()[0], t0.last()[1] - dn.last()[1]) > 0.05f) t0 + listOf(dn.last()) else t0
        val tm = Mat("traffic").apply { kd = floatArrayOf(1f, 0.25f, 0.25f) }
        for (i in tr.indices) {
            val c = tr[i]
            val bk = if (i == 0) c else floatArrayOf((tr[i - 1][0] + c[0]) / 2, (tr[i - 1][1] + c[1]) / 2)
            val fr = if (i == tr.lastIndex) c else floatArrayOf((tr[i + 1][0] + c[0]) / 2, (tr[i + 1][1] + c[1]) / 2)
            val r = right(bk, fr) ?: continue
            val hw = spacing / 2
            val cs = listOf(bk to -hw, bk to hw, fr to hw, fr to -hw)
            val p = ArrayList<Float>()
            for ((q, off) in cs) { val x = q[0] + r[0] * off; val z = q[1] + r[1] * off
                p.add(x); p.add(hf(x, z) + raise + 0.15f); p.add(z) }
            out.add(Part("traffic_%03d".format(counter[0]++), tm, p.toFloatArray(), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)).also { it.quad = true })
        }
        return out
    }
}
