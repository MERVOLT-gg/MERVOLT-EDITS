package com.mervolt.edits

import android.graphics.Bitmap

class Mat(val name: String) {
    var tex: String? = null
    var kd = floatArrayOf(0.8f, 0.8f, 0.8f)
    var bmp: Bitmap? = null
}

/** Objet iray = material iray (vokatry ny Separate by Material). Vertices tokana, indices triangle. */
class Part(val name: String, val mat: Mat, val pos: FloatArray, val uv: FloatArray, val idx: IntArray) { var smooth = false; var selected = false; var quad = false; var poly: IntArray? = null; var polySizes: IntArray? = null }   // poly/polySizes = polygon tany am-boalohany (quad, n-gon) ho an'ny export

private class Poly(val p: IntArray, val t: IntArray, val m: Int)

object Obj {
    private fun fix(s: String, n: Int): Int { val i = s.toInt(); return if (i > 0) i - 1 else n + i }

    fun readMtl(lines: List<String>): HashMap<String, Mat> {
        val defs = HashMap<String, Mat>(); var cur: Mat? = null
        for (l in lines) {
            val s = l.trim().split(Regex("\\s+"))
            when (s[0].lowercase()) {
                "newmtl" -> { cur = Mat(s.drop(1).joinToString(" ")); defs[cur.name] = cur }
                "kd" -> if (s.size >= 4) cur?.kd = floatArrayOf(s[1].toFloat(), s[2].toFloat(), s[3].toFloat())
                "map_kd" -> cur?.tex = s.drop(1).joinToString(" ").substringAfterLast('/').substringAfterLast('\\')
            }
        }
        return defs
    }

    /** Mamaky OBJ ary mizara ho Part isaky ny material (P > By Material). Anarana: base, base.001, base.002... */
    fun parse(obj: List<String>, mtl: (String) -> List<String>?, base: String): List<Part> {
        val P = ArrayList<Float>(); val T = ArrayList<Float>()
        var defs = HashMap<String, Mat>(); val used = ArrayList<Mat>(); val ids = HashMap<String, Int>()
        val polys = ArrayList<Poly>(); var cur = -1
        fun mi(n: String) = ids.getOrPut(n) { used.add(defs[n] ?: Mat(n)); used.size - 1 }
        for (l in obj) {
            val s = l.trim().split(Regex("\\s+"))
            when (s[0]) {
                "v" -> { P.add(s[1].toFloat()); P.add(s[2].toFloat()); P.add(s[3].toFloat()) }
                "vt" -> { T.add(s[1].toFloat()); T.add(s[2].toFloat()) }
                "mtllib" -> mtl(s.drop(1).joinToString(" "))?.let { defs = readMtl(it) }
                "usemtl" -> cur = mi(s.drop(1).joinToString(" "))
                "f" -> {
                    if (cur < 0) cur = mi("default")
                    val c = s.drop(1).map { val a = it.split("/")
                        fix(a[0], P.size / 3) to (if (a.size > 1 && a[1].isNotEmpty()) fix(a[1], T.size / 2) else -1) }
                    if (c.size >= 3) polys.add(Poly(IntArray(c.size) { c[it].first }, IntArray(c.size) { c[it].second }, cur))
                }
            }
        }
        var n = 0
        return polys.groupBy { it.m }.map { (m, pgs) ->
            val remap = HashMap<Long, Int>(); val pos = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>()
            val poly = ArrayList<Int>(); val sizes = ArrayList<Int>()
            fun vtx(p: Int, t: Int): Int = remap.getOrPut((p.toLong() shl 32) or (t + 1).toLong()) {
                pos.add(P[p * 3]); pos.add(P[p * 3 + 1]); pos.add(P[p * 3 + 2])
                if (t >= 0) { uv.add(T[t * 2]); uv.add(T[t * 2 + 1]) } else { uv.add(0f); uv.add(0f) }
                remap.size
            }
            for (pg in pgs) {
                val vs = IntArray(pg.p.size) { vtx(pg.p[it], pg.t[it]) }
                for (v in vs) poly.add(v)
                sizes.add(vs.size)
                for (k in 1 until vs.size - 1) { idx.add(vs[0]); idx.add(vs[k]); idx.add(vs[k + 1]) }   // triangle ho an'ny fampisehoana ihany
            }
            val name = if (n == 0) base else "%s.%03d".format(base, n); n++
            Part(name, used[m], pos.toFloatArray(), uv.toFloatArray(), idx.toIntArray()).also { it.poly = poly.toIntArray(); it.polySizes = sizes.toIntArray() }
        }
    }
}
