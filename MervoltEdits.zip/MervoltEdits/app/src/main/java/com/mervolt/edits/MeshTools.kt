package com.mervolt.edits

import kotlin.math.*

/** Haavony (y) eo amin'ny (x,z) araka ny triangle an'ny mesh (spatial hash 4 m). Raha mifanindry dia ny avo indrindra. */
class MeshHeight(parts: List<Part>) {
    private val tris = ArrayList<FloatArray>()
    private val cells = HashMap<Long, ArrayList<Int>>()
    private val cs = 4f
    private fun key(a: Int, b: Int) = (a.toLong() shl 32) xor (b.toLong() and 0xffffffffL)

    init {
        for (p in parts) for (t in 0 until p.idx.size / 3) {
            val a = p.idx[t * 3]; val b = p.idx[t * 3 + 1]; val c = p.idx[t * 3 + 2]
            val tr = floatArrayOf(p.pos[a * 3], p.pos[a * 3 + 2], p.pos[a * 3 + 1], p.pos[b * 3], p.pos[b * 3 + 2], p.pos[b * 3 + 1], p.pos[c * 3], p.pos[c * 3 + 2], p.pos[c * 3 + 1])
            val id = tris.size; tris.add(tr)
            val mnx = min(tr[0], min(tr[3], tr[6])); val mxx = max(tr[0], max(tr[3], tr[6])); val mnz = min(tr[1], min(tr[4], tr[7])); val mxz = max(tr[1], max(tr[4], tr[7]))
            for (gx in floor(mnx / cs).toInt()..floor(mxx / cs).toInt()) for (gz in floor(mnz / cs).toInt()..floor(mxz / cs).toInt())
                cells.getOrPut(key(gx, gz)) { ArrayList() }.add(id)
        }
    }

    fun at(x: Float, z: Float): Float? {
        val l = cells[key(floor(x / cs).toInt(), floor(z / cs).toInt())] ?: return null
        var best: Float? = null
        for (id in l) {
            val t = tris[id]
            val d = (t[4] - t[7]) * (t[0] - t[6]) + (t[6] - t[3]) * (t[1] - t[7]); if (abs(d) < 1e-9f) continue
            val a = ((t[4] - t[7]) * (x - t[6]) + (t[6] - t[3]) * (z - t[7])) / d
            val b = ((t[7] - t[1]) * (x - t[6]) + (t[0] - t[6]) * (z - t[7])) / d
            val c = 1 - a - b
            if (a >= -1e-4f && b >= -1e-4f && c >= -1e-4f) { val y = a * t[2] + b * t[5] + c * t[8]; val bb = best; if (bb == null || y > bb) best = y }
        }
        return best
    }
}

/** Mitady ny afovoan'ny lalana (centerline) avy amin'ny mesh road: elanelana geodesic + afovoan'ny tsipika mitovy elanelana. Mamerina lalana maromaro (sampana). */
object RoadPath {
    private class Q(val d: Float, val v: Int)

    fun extract(parts: List<Part>): List<List<FloatArray>> {
        val ids = HashMap<Triple<Int, Int, Int>, Int>(); val xs = ArrayList<Float>(); val zs = ArrayList<Float>(); val adj = ArrayList<ArrayList<Int>>()
        fun node(x: Float, y: Float, z: Float): Int = ids.getOrPut(Triple(Math.round(x * 100), Math.round(y * 100), Math.round(z * 100))) { xs.add(x); zs.add(z); adj.add(ArrayList()); xs.size - 1 }
        for (p in parts) for (t in 0 until p.idx.size / 3) {
            val v = IntArray(3) { k -> val i = p.idx[t * 3 + k]; node(p.pos[i * 3], p.pos[i * 3 + 1], p.pos[i * 3 + 2]) }
            for (k in 0..2) { val a = v[k]; val b = v[(k + 1) % 3]; if (a != b) { adj[a].add(b); adj[b].add(a) } }
        }
        val n = xs.size; if (n < 12 || n > 300000) return emptyList()
        val inf = Float.MAX_VALUE
        fun dij(src: Int, alive: BooleanArray): FloatArray {
            val dist = FloatArray(n) { inf }; dist[src] = 0f
            val pq = java.util.PriorityQueue<Q>(compareBy<Q> { it.d }); pq.add(Q(0f, src))
            while (pq.isNotEmpty()) {
                val q = pq.poll()!!; if (q.d > dist[q.v]) continue
                for (w in adj[q.v]) { if (!alive[w]) continue; val nd = q.d + hypot(xs[w] - xs[q.v], zs[w] - zs[q.v]); if (nd < dist[w]) { dist[w] = nd; pq.add(Q(nd, w)) } }
            }
            return dist
        }
        fun farthest(d: FloatArray): Int { var b = 0; var bd = -1f; for (v in 0 until n) if (d[v] < inf && d[v] > bd) { bd = d[v]; b = v }; return b }
        val alive = BooleanArray(n) { true }; val out = ArrayList<List<FloatArray>>()
        repeat(6) {
            val s0 = alive.indexOfFirst { it }; if (s0 < 0) return out
            val a = farthest(dij(s0, alive)); val dA = dij(a, alive); val b = farthest(dA); val len = dA[b]
            var cnt = 0; for (v in 0 until n) if (dA[v] < inf) cnt++
            if (cnt < 12 || len < 10f) { for (v in 0 until n) if (dA[v] < inf) alive[v] = false; return@repeat }
            val bl = 1.5f; val nb = (len / bl).toInt() + 1; val sx = FloatArray(nb); val sz = FloatArray(nb); val sc = IntArray(nb)
            for (v in 0 until n) if (dA[v] < inf) { val k = (dA[v] / bl).toInt().coerceIn(0, nb - 1); sx[k] += xs[v]; sz[k] += zs[v]; sc[k]++ }
            val pl = ArrayList<FloatArray>(); for (k in 0 until nb) if (sc[k] > 0) pl.add(floatArrayOf(sx[k] / sc[k], sz[k] / sc[k]))
            if (pl.size < 3) { for (v in 0 until n) if (dA[v] < inf) alive[v] = false; return@repeat }
            val sm = pl.indices.map { i -> var ax = 0f; var az = 0f; var c = 0; for (k in max(0, i - 2)..min(pl.size - 1, i + 2)) { ax += pl[k][0]; az += pl[k][1]; c++ }; floatArrayOf(ax / c, az / c) }
            val ctrl = ArrayList<FloatArray>(); ctrl.add(sm[0]); var acc = 0f
            for (i in 1 until sm.size) { acc += hypot(sm[i][0] - sm[i - 1][0], sm[i][1] - sm[i - 1][1]); if (acc >= 5f) { ctrl.add(sm[i]); acc = 0f } }
            if (ctrl.last() !== sm.last()) ctrl.add(sm.last())
            if (ctrl.size >= 2) out.add(ctrl)
            // esory ny vertices akaikin'ny lalana (hw = 90% elanelana) mba hitady ny sampana manaraka
            fun dp(x: Float, z: Float): Float { var best = inf
                for (i in 0 until sm.size - 1) { val p0 = sm[i]; val p1 = sm[i + 1]; val dx = p1[0] - p0[0]; val dz = p1[1] - p0[1]; val l2 = dx * dx + dz * dz
                    val t = if (l2 < 1e-9f) 0f else (((x - p0[0]) * dx + (z - p0[1]) * dz) / l2).coerceIn(0f, 1f); best = min(best, hypot(x - (p0[0] + dx * t), z - (p0[1] + dz * t))) }
                return best }
            val ds = ArrayList<Float>(); for (v in 0 until n) if (dA[v] < inf) ds.add(dp(xs[v], zs[v]))
            ds.sort(); val hw = ds[(ds.size * 0.9f).toInt().coerceIn(0, ds.size - 1)] * 1.15f + 0.5f
            var removed = 0
            for (v in 0 until n) if (dA[v] < inf && dp(xs[v], zs[v]) < hw) { alive[v] = false; removed++ }
            if (removed == 0) for (v in 0 until n) if (dA[v] < inf) alive[v] = false
        }
        return out
    }
}
