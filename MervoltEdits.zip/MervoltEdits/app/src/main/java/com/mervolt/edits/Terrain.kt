package com.mervolt.edits

import kotlin.math.*

/** Terrain maivana: 65x65 teboka (4225) ho an'ny 200x200 m. ox/oz = toerana eo amin'ny tontolo (azo afindra). */
class Terrain(val name: String, val n: Int = 65, val size: Float = 200f, var ox: Float = 0f, var oz: Float = 0f) {
    val h = FloatArray(n * n)
    var yaw = 0f; var sc = 1f   // fihodinana sy habe (mitsivalana) an'ny terrain
    val part: Part
    var cut: List<Part>? = null   // mesh terrain voatapaka ho road (raha misy road)
    fun cc(i: Int) = (i / (n - 1f) - 0.5f) * size
    private fun gi(v: Float) = (((v / size) + 0.5f) * (n - 1)).toInt().coerceIn(0, n - 1)

    init {
        val pos = FloatArray(n * n * 3); val uv = FloatArray(n * n * 2)
        for (j in 0 until n) for (i in 0 until n) { val k = j * n + i
            pos[k * 3] = ox + cc(i); pos[k * 3 + 2] = oz + cc(j)
            uv[k * 2] = i * size / (n - 1) / 10f; uv[k * 2 + 1] = j * size / (n - 1) / 10f }   // texture miverina isaky ny 10 m
        val idx = IntArray((n - 1) * (n - 1) * 6); var q = 0
        for (j in 0 until n - 1) for (i in 0 until n - 1) { val a = j * n + i; val b = a + 1; val c = a + n; val d = c + 1
            idx[q++] = a; idx[q++] = c; idx[q++] = b; idx[q++] = b; idx[q++] = c; idx[q++] = d }
        part = Part(name, Mat(name).also { it.kd = floatArrayOf(0.52f, 0.58f, 0.44f) }, pos, uv, idx).also { it.smooth = true }
    }

    fun refreshCutHeights() { cut?.forEach { p -> for (i in 0 until p.pos.size / 3) p.pos[i * 3 + 1] = height(p.pos[i * 3], p.pos[i * 3 + 2]) } }
    private fun toLX(x: Float, z: Float): Float { val dx = x - ox; val dz = z - oz; return (dx * cos(yaw) - dz * sin(yaw)) / sc }
    private fun toLZ(x: Float, z: Float): Float { val dx = x - ox; val dz = z - oz; return (dx * sin(yaw) + dz * cos(yaw)) / sc }
    fun wx(i: Int, j: Int): Float = ox + sc * (cc(i) * cos(yaw) + cc(j) * sin(yaw))
    fun wz(i: Int, j: Int): Float = oz + sc * (-cc(i) * sin(yaw) + cc(j) * cos(yaw))
    fun contains(x: Float, z: Float) = abs(toLX(x, z)) <= size / 2 && abs(toLZ(x, z)) <= size / 2
    fun setH(k: Int, v: Float) { h[k] = v; part.pos[k * 3 + 1] = v }
    fun rebuildPos() { for (j in 0 until n) for (i in 0 until n) { val k = j * n + i
        part.pos[k * 3] = wx(i, j); part.pos[k * 3 + 1] = h[k]; part.pos[k * 3 + 2] = wz(i, j) } }

    fun height(x: Float, z: Float): Float {
        val fx = ((toLX(x, z) / size + 0.5f) * (n - 1)).coerceIn(0f, n - 1.001f)
        val fz = ((toLZ(x, z) / size + 0.5f) * (n - 1)).coerceIn(0f, n - 1.001f)
        val i = fx.toInt(); val j = fz.toInt(); val u = fx - i; val v = fz - j
        val a = h[j * n + i]; val b = h[j * n + i + 1]; val c = h[(j + 1) * n + i]; val d = h[(j + 1) * n + i + 1]
        return if (u + v <= 1f) a + (b - a) * u + (c - a) * v else d + (c - d) * (1 - u) + (b - d) * (1 - v)
    }

    /** px,pz = tontolo. mode: 0 Raise, 1 Lower, 2 Smooth */
    fun sculpt(px: Float, pz: Float, r: Float, s: Float, mode: Int) {
        val lx = toLX(px, pz); val lz = toLZ(px, pz); val rl = r / sc
        val i0 = gi(lx - rl); val i1 = gi(lx + rl); val j0 = gi(lz - rl); val j1 = gi(lz + rl)
        for (j in j0..j1) for (i in i0..i1) {
            val d = hypot(cc(i) - lx, cc(j) - lz); if (d >= rl) continue
            val f = 1 - d / rl; val w = f * f * (3 - 2 * f); val k = j * n + i
            when (mode) {
                0 -> h[k] += s * w
                1 -> h[k] -= s * w
                else -> { val avg = (h[j * n + max(i - 1, 0)] + h[j * n + min(i + 1, n - 1)] + h[max(j - 1, 0) * n + i] + h[min(j + 1, n - 1) * n + i]) / 4f
                    h[k] += (avg - h[k]) * min(1f, w * 0.6f) }
            }
            part.pos[k * 3 + 1] = h[k]
        }
    }

    /** Mampitovy ny sisiny mifandray amin'ny terrain hafa (copy=true: raisina avy amin'ny b). */
    fun sync(b: Terrain, copy: Boolean) {
        if (yaw != 0f || sc != 1f || b.yaw != 0f || b.sc != 1f) return
        val xs = abs(oz - b.oz) < 0.01f && abs(abs(ox - b.ox) - size) < 0.01f
        val zs = abs(ox - b.ox) < 0.01f && abs(abs(oz - b.oz) - size) < 0.01f
        if (!xs && !zs) return
        for (m in 0 until n) {
            val ti = if (xs) (if (ox < b.ox) m * n + n - 1 else m * n) else (if (oz < b.oz) (n - 1) * n + m else m)
            val bi = if (xs) (if (ox < b.ox) m * n else m * n + n - 1) else (if (oz < b.oz) m else (n - 1) * n + m)
            val v = if (copy) b.h[bi] else (h[ti] + b.h[bi]) / 2
            setH(ti, v); b.setH(bi, v)
        }
    }
}
