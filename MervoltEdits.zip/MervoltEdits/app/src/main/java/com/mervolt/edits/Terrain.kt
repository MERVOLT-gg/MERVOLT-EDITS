package com.mervolt.edits

import kotlin.math.*

/** Terrain = grid heightfield (Y ambony). Vertices 129x129 < 65535 ho an'ny .3ds. */
class Terrain(val n: Int = 129, val size: Float = 100f) {
    val h = FloatArray(n * n)
    val part: Part
    private fun cc(i: Int) = (i / (n - 1f) - 0.5f) * size
    private fun gi(v: Float) = (((v / size) + 0.5f) * (n - 1)).toInt().coerceIn(0, n - 1)

    init {
        val pos = FloatArray(n * n * 3); val uv = FloatArray(n * n * 2)
        for (j in 0 until n) for (i in 0 until n) { val k = j * n + i
            pos[k * 3] = cc(i); pos[k * 3 + 2] = cc(j); uv[k * 2] = i / (n - 1f); uv[k * 2 + 1] = j / (n - 1f) }
        val idx = IntArray((n - 1) * (n - 1) * 6); var q = 0
        for (j in 0 until n - 1) for (i in 0 until n - 1) { val a = j * n + i; val b = a + 1; val c = a + n; val d = c + 1
            idx[q++] = a; idx[q++] = c; idx[q++] = b; idx[q++] = b; idx[q++] = c; idx[q++] = d }
        part = Part("terrain", Mat("terrain").also { it.kd = floatArrayOf(0.45f, 0.62f, 0.35f) }, pos, uv, idx).also { it.smooth = true }
    }

    /** Haavony mifanaraka tsara amin'ny triangle an'ny mesh (road mipetaka tsara). */
    fun height(x: Float, z: Float): Float {
        val fx = ((x / size + 0.5f) * (n - 1)).coerceIn(0f, n - 1.001f)
        val fz = ((z / size + 0.5f) * (n - 1)).coerceIn(0f, n - 1.001f)
        val i = fx.toInt(); val j = fz.toInt(); val u = fx - i; val v = fz - j
        val a = h[j * n + i]; val b = h[j * n + i + 1]; val c = h[(j + 1) * n + i]; val d = h[(j + 1) * n + i + 1]
        return if (u + v <= 1f) a + (b - a) * u + (c - a) * v else d + (c - d) * (1 - u) + (b - d) * (1 - v)
    }

    /** mode: 0 Raise, 1 Lower, 2 Smooth */
    fun sculpt(px: Float, pz: Float, r: Float, s: Float, mode: Int) {
        val i0 = gi(px - r); val i1 = gi(px + r); val j0 = gi(pz - r); val j1 = gi(pz + r)
        for (j in j0..j1) for (i in i0..i1) {
            val d = hypot(cc(i) - px, cc(j) - pz); if (d >= r) continue
            val f = 1 - d / r; val w = f * f * (3 - 2 * f); val k = j * n + i
            when (mode) {
                0 -> h[k] += s * w
                1 -> h[k] -= s * w
                else -> { val avg = (h[j * n + max(i - 1, 0)] + h[j * n + min(i + 1, n - 1)] + h[max(j - 1, 0) * n + i] + h[min(j + 1, n - 1) * n + i]) / 4f
                    h[k] += (avg - h[k]) * min(1f, w * 0.6f) }
            }
            part.pos[k * 3 + 1] = h[k]
        }
    }
}
