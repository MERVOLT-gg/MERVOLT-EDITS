package com.mervolt.edits

import android.opengl.GLES20.*
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.sqrt

class Renderer : GLSurfaceView.Renderer {
    @Volatile var parts: List<Part> = emptyList()
    var rx = 25f; var ry = -30f; var dist = 3f; var px = 0f; var py = 0f
    private var cx = 0f; private var cy = 0f; private var cz = 0f
    val mvp = FloatArray(16)
    private var vw = 1; private var vh = 1; private var prog = 0
    private val buf = HashMap<Part, Triple<FloatBuffer, FloatBuffer, FloatBuffer>>()
    private val tex = HashMap<Mat, Int>()

    fun applyParts(p: List<Part>) { parts = p; buf.keys.retainAll(p.toSet()) }
    fun invalidate(p: Part) { buf.remove(p) }
    fun dropTex(m: Mat) { tex.remove(m) }

    fun fit() {
        val p = parts; if (p.isEmpty()) return
        val mn = floatArrayOf(1e9f, 1e9f, 1e9f); val mx = floatArrayOf(-1e9f, -1e9f, -1e9f)
        for (pt in p) for (i in pt.pos.indices) { val k = i % 3; if (pt.pos[i] < mn[k]) mn[k] = pt.pos[i]; if (pt.pos[i] > mx[k]) mx[k] = pt.pos[i] }
        cx = (mn[0] + mx[0]) / 2; cy = (mn[1] + mx[1]) / 2; cz = (mn[2] + mx[2]) / 2
        dist = maxOf(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2], 0.5f) * 1.4f; px = 0f; py = 0f
    }

    fun ray(x: Float, y: Float): Pair<FloatArray, FloatArray>? {
        val inv = FloatArray(16); if (!Matrix.invertM(inv, 0, mvp, 0)) return null
        val nx = 2 * x / vw - 1; val ny = 1 - 2 * y / vh
        val a = floatArrayOf(nx, ny, -1f, 1f); val b = floatArrayOf(nx, ny, 1f, 1f)
        val oa = FloatArray(4); val ob = FloatArray(4)
        Matrix.multiplyMV(oa, 0, inv, 0, a, 0); Matrix.multiplyMV(ob, 0, inv, 0, b, 0)
        for (k in 0..2) { oa[k] /= oa[3]; ob[k] /= ob[3] }
        val d = floatArrayOf(ob[0] - oa[0], ob[1] - oa[1], ob[2] - oa[2])
        val l = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]); for (k in 0..2) d[k] /= l
        return Pair(floatArrayOf(oa[0], oa[1], oa[2]), d)
    }

    private fun fb(a: FloatArray): FloatBuffer = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(a).also { it.position(0) }
    private fun sh(t: Int, s: String) = glCreateShader(t).also { glShaderSource(it, s); glCompileShader(it) }

    /** Buffers: position + uv + normals (flat ho an'ny objet, malama ho an'ny terrain/road). */
    private fun build(p: Part): Triple<FloatBuffer, FloatBuffer, FloatBuffer> {
        val n = p.idx.size; val nv = p.pos.size / 3
        val fn = FloatArray(n); val vn = FloatArray(nv * 3)
        for (t in 0 until n / 3) {
            val ia = p.idx[t * 3]; val ib = p.idx[t * 3 + 1]; val ic = p.idx[t * 3 + 2]
            val e1x = p.pos[ib * 3] - p.pos[ia * 3]; val e1y = p.pos[ib * 3 + 1] - p.pos[ia * 3 + 1]; val e1z = p.pos[ib * 3 + 2] - p.pos[ia * 3 + 2]
            val e2x = p.pos[ic * 3] - p.pos[ia * 3]; val e2y = p.pos[ic * 3 + 1] - p.pos[ia * 3 + 1]; val e2z = p.pos[ic * 3 + 2] - p.pos[ia * 3 + 2]
            val x = e1y * e2z - e1z * e2y; val y = e1z * e2x - e1x * e2z; val z = e1x * e2y - e1y * e2x
            fn[t * 3] = x; fn[t * 3 + 1] = y; fn[t * 3 + 2] = z
            if (p.smooth) for (i in intArrayOf(ia, ib, ic)) { vn[i * 3] += x; vn[i * 3 + 1] += y; vn[i * 3 + 2] += z }
        }
        val pp = FloatArray(n * 3); val uu = FloatArray(n * 2); val nn = FloatArray(n * 3)
        for (i in 0 until n) {
            val v = p.idx[i]
            pp[i * 3] = p.pos[v * 3]; pp[i * 3 + 1] = p.pos[v * 3 + 1]; pp[i * 3 + 2] = p.pos[v * 3 + 2]
            uu[i * 2] = p.uv[v * 2]; uu[i * 2 + 1] = p.uv[v * 2 + 1]
            val x: Float; val y: Float; val z: Float
            if (p.smooth) { x = vn[v * 3]; y = vn[v * 3 + 1] * 0.6f; z = vn[v * 3 + 2] } else { val t = (i / 3) * 3; x = fn[t]; y = fn[t + 1]; z = fn[t + 2] }
            val l = sqrt(x * x + y * y + z * z).let { if (it < 1e-12f) 1f else it }
            nn[i * 3] = x / l; nn[i * 3 + 1] = y / l; nn[i * 3 + 2] = z / l
        }
        return Triple(fb(pp), fb(uu), fb(nn))
    }

    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
        glClearColor(0.12f, 0.12f, 0.14f, 1f); glEnable(GL_DEPTH_TEST)
        prog = glCreateProgram()
        glAttachShader(prog, sh(GL_VERTEX_SHADER, "uniform mat4 u;attribute vec3 a;attribute vec2 b;attribute vec3 g;varying vec2 v;varying vec3 nn;void main(){v=vec2(b.x,1.0-b.y);nn=g;gl_Position=u*vec4(a,1.0);}"))
        glAttachShader(prog, sh(GL_FRAGMENT_SHADER, "precision mediump float;uniform sampler2D s;uniform float h;uniform float hl;uniform vec3 c;uniform vec3 lm;uniform vec3 fl;uniform vec3 ev;varying vec2 v;varying vec3 nn;void main(){vec4 t=h>0.5?texture2D(s,v):vec4(c,1.0);if(t.a<0.5)discard;vec3 n=normalize(nn);if(dot(n,ev)<0.0)n=-n;float l=0.25+0.65*max(dot(n,lm),0.0)+0.25*max(dot(n,fl),0.0);gl_FragColor=vec4(min(mix(t.rgb,vec3(1.0,0.75,0.2),hl*0.4)*l,vec3(1.0)),1.0);}"))
        glLinkProgram(prog); buf.clear(); tex.clear()
    }

    override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) { glViewport(0, 0, w, h); vw = w; vh = h }

    private fun texId(m: Mat): Int = tex.getOrPut(m) {
        val b = m.bmp ?: return@getOrPut 0
        val id = IntArray(1); glGenTextures(1, id, 0); glBindTexture(GL_TEXTURE_2D, id[0])
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
        GLUtils.texImage2D(GL_TEXTURE_2D, 0, b, 0); id[0]
    }

    override fun onDrawFrame(g: GL10?) {
        glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT)
        val pm = FloatArray(16); val vm = FloatArray(16); val mm = FloatArray(16); val tv = FloatArray(16)
        val t1 = FloatArray(16); val t2 = FloatArray(16)
        Matrix.perspectiveM(pm, 0, 45f, vw.toFloat() / vh, dist / 100f, dist * 30f)
        Matrix.setLookAtM(vm, 0, 0f, 0f, dist, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.setIdentityM(mm, 0); Matrix.rotateM(mm, 0, rx, 1f, 0f, 0f); Matrix.rotateM(mm, 0, ry, 0f, 1f, 0f)
        Matrix.translateM(mm, 0, -cx, -cy, -cz)
        Matrix.setIdentityM(tv, 0); Matrix.translateM(tv, 0, px, py, 0f)
        Matrix.multiplyMM(t1, 0, vm, 0, mm, 0); Matrix.multiplyMM(t2, 0, tv, 0, t1, 0); Matrix.multiplyMM(mvp, 0, pm, 0, t2, 0)
        glUseProgram(prog)
        glUniformMatrix4fv(glGetUniformLocation(prog, "u"), 1, false, mvp, 0)
        // Lumière: avy eo ambony ankavia ny camera, voafindra amin'ny habaka-modely
        val inv = FloatArray(16); Matrix.invertM(inv, 0, mm, 0)
        fun dirM(x: Float, y: Float, z: Float, name: String) {
            val o = FloatArray(4); Matrix.multiplyMV(o, 0, inv, 0, floatArrayOf(x, y, z, 0f), 0)
            val l = sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2]).let { if (it < 1e-6f) 1f else it }
            glUniform3f(glGetUniformLocation(prog, name), o[0] / l, o[1] / l, o[2] / l)
        }
        dirM(-0.6f, 0.55f, 0.58f, "lm"); dirM(0.7f, 0.15f, 0.5f, "fl"); dirM(0f, 0f, 1f, "ev")
        val a = glGetAttribLocation(prog, "a"); val b = glGetAttribLocation(prog, "b"); val ga = glGetAttribLocation(prog, "g")
        glEnableVertexAttribArray(a); glEnableVertexAttribArray(b); glEnableVertexAttribArray(ga)
        for (p in parts) {
            val (pb, ub, nb) = buf.getOrPut(p) { build(p) }
            val id = texId(p.mat)
            glUniform1f(glGetUniformLocation(prog, "h"), if (id != 0) 1f else 0f)
            glUniform1f(glGetUniformLocation(prog, "hl"), if (p.selected) 1f else 0f)
            glUniform3fv(glGetUniformLocation(prog, "c"), 1, p.mat.kd, 0)
            if (id != 0) { glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, id) }
            glVertexAttribPointer(a, 3, GL_FLOAT, false, 0, pb); glVertexAttribPointer(b, 2, GL_FLOAT, false, 0, ub)
            glVertexAttribPointer(ga, 3, GL_FLOAT, false, 0, nb)
            glDrawArrays(GL_TRIANGLES, 0, p.idx.size)
        }
    }
}
