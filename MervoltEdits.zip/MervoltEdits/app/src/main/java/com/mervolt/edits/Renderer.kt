package com.mervolt.edits

import android.graphics.Bitmap
import android.opengl.GLES20.*
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class Renderer : GLSurfaceView.Renderer {
    var parts: List<Part> = emptyList()
    var rx = 20f; var ry = -30f; var dist = 3f
    private var cx = 0f; private var cy = 0f; private var cz = 0f
    private var prog = 0; private var aspect = 1f
    private val buf = HashMap<Part, Pair<FloatBuffer, FloatBuffer>>()
    private val tex = HashMap<Mat, Int>()

    fun load(p: List<Part>) {   // asaina amin'ny GL thread (queueEvent)
        parts = p; buf.clear(); tex.clear()
        var mn = floatArrayOf(1e9f, 1e9f, 1e9f); var mx = floatArrayOf(-1e9f, -1e9f, -1e9f)
        for (pt in p) for (i in pt.pos.indices) { val k = i % 3; mn[k] = minOf(mn[k], pt.pos[i]); mx[k] = maxOf(mx[k], pt.pos[i]) }
        if (p.isEmpty()) return
        cx = (mn[0] + mx[0]) / 2; cy = (mn[1] + mx[1]) / 2; cz = (mn[2] + mx[2]) / 2
        val r = maxOf(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 2
        dist = r * 2.8f
    }

    private fun fb(a: FloatArray): FloatBuffer = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(a).also { it.position(0) }
    private fun sh(t: Int, s: String) = glCreateShader(t).also { glShaderSource(it, s); glCompileShader(it) }

    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
        glClearColor(0.12f, 0.12f, 0.14f, 1f); glEnable(GL_DEPTH_TEST)
        prog = glCreateProgram()
        glAttachShader(prog, sh(GL_VERTEX_SHADER, "uniform mat4 u;attribute vec3 a;attribute vec2 b;varying vec2 v;void main(){v=vec2(b.x,1.0-b.y);gl_Position=u*vec4(a,1.0);}"))
        glAttachShader(prog, sh(GL_FRAGMENT_SHADER, "precision mediump float;uniform sampler2D s;uniform float h;uniform vec3 c;varying vec2 v;void main(){vec4 t=h>0.5?texture2D(s,v):vec4(c,1.0);if(t.a<0.5)discard;gl_FragColor=vec4(t.rgb,1.0);}"))
        glLinkProgram(prog); buf.clear(); tex.clear()
    }

    override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) { glViewport(0, 0, w, h); aspect = w.toFloat() / h }

    private fun texId(m: Mat): Int = tex.getOrPut(m) {
        val b: Bitmap = m.bmp ?: return@getOrPut 0
        val id = IntArray(1); glGenTextures(1, id, 0); glBindTexture(GL_TEXTURE_2D, id[0])
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
        GLUtils.texImage2D(GL_TEXTURE_2D, 0, b, 0); id[0]
    }

    override fun onDrawFrame(g: GL10?) {
        glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT)
        val pm = FloatArray(16); val vm = FloatArray(16); val mm = FloatArray(16); val t = FloatArray(16)
        Matrix.perspectiveM(pm, 0, 45f, aspect, dist / 100f, dist * 20f)
        Matrix.setLookAtM(vm, 0, 0f, 0f, dist, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.setIdentityM(mm, 0); Matrix.rotateM(mm, 0, rx, 1f, 0f, 0f); Matrix.rotateM(mm, 0, ry, 0f, 1f, 0f)
        Matrix.translateM(mm, 0, -cx, -cy, -cz)
        Matrix.multiplyMM(t, 0, vm, 0, mm, 0); Matrix.multiplyMM(t, 0, pm, 0, t, 0)
        glUseProgram(prog)
        glUniformMatrix4fv(glGetUniformLocation(prog, "u"), 1, false, t, 0)
        val a = glGetAttribLocation(prog, "a"); val b = glGetAttribLocation(prog, "b")
        glEnableVertexAttribArray(a); glEnableVertexAttribArray(b)
        for (p in parts) {
            val (pb, ub) = buf.getOrPut(p) {
                val n = p.idx.size; val pp = FloatArray(n * 3); val uu = FloatArray(n * 2)
                for (i in 0 until n) { val v = p.idx[i]
                    pp[i * 3] = p.pos[v * 3]; pp[i * 3 + 1] = p.pos[v * 3 + 1]; pp[i * 3 + 2] = p.pos[v * 3 + 2]
                    uu[i * 2] = p.uv[v * 2]; uu[i * 2 + 1] = p.uv[v * 2 + 1] }
                fb(pp) to fb(uu)
            }
            val id = texId(p.mat)
            glUniform1f(glGetUniformLocation(prog, "h"), if (id != 0) 1f else 0f)
            glUniform3fv(glGetUniformLocation(prog, "c"), 1, p.mat.kd, 0)
            if (id != 0) { glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, id) }
            glVertexAttribPointer(a, 3, GL_FLOAT, false, 0, pb); glVertexAttribPointer(b, 2, GL_FLOAT, false, 0, ub)
            glDrawArrays(GL_TRIANGLES, 0, p.idx.size)
        }
    }
}
