package com.mervolt.edits

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Writer .3ds mivantana avy amin'ny mesh anaty memoire (tsy mila .obj). */
object Writer3DS {
    private fun bb(n: Int) = ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN)
    private fun ch(id: Int, vararg b: ByteArray): ByteArray {
        val len = 6 + b.sumOf { it.size }
        val o = bb(len); o.putShort(id.toShort()); o.putInt(len); b.forEach { o.put(it) }; return o.array()
    }
    private fun str(s: String) = (s + "\u0000").toByteArray(Charsets.US_ASCII)
    private fun u16(v: Int) = bb(2).putShort(v.toShort()).array()
    private fun floats(f: FloatArray) = bb(f.size * 4).also { b -> f.forEach { b.putFloat(it) } }.array()

    fun write(parts: List<Part>): ByteArray {
        val mats = parts.map { it.mat }.distinct().map { m ->
            val rgb = byteArrayOf(*m.kd.map { (it * 255).toInt().coerceIn(0, 255).toByte() }.toByteArray())
            val tex = m.tex
            val extra = ArrayList<ByteArray>()
            if (tex != null) {
                extra.add(ch(0xA200, ch(0xA300, str(tex))))
                if (m.cut) extra.add(ch(0xA210, ch(0xA300, str(tex))))   // opacity map ho an'ny _cutout_
            }
            ch(0xAFFF, ch(0xA000, str(m.name)), ch(0xA020, ch(0x0011, rgb)), *extra.toTypedArray())
        }
        val objs = parts.map { p ->
            val nv = p.pos.size / 3; val nf = p.idx.size / 3
            require(nv <= 65535) { "${p.name}: vertices > 65535 (fetran'ny .3ds)" }
            val fb = bb(nf * 8); for (f in 0 until nf) { fb.putShort(p.idx[f * 3].toShort()); fb.putShort(p.idx[f * 3 + 1].toShort()); fb.putShort(p.idx[f * 3 + 2].toShort()); fb.putShort(0) }
            val ms = bb(nf * 2); for (f in 0 until nf) ms.putShort(f.toShort())
            ch(0x4000, str(p.name), ch(0x4100,
                ch(0x4110, u16(nv), floats(p.pos)),
                ch(0x4140, u16(nv), floats(p.uv)),
                ch(0x4120, u16(nf), fb.array(), ch(0x4130, str(p.mat.name), u16(nf), ms.array()))))
        }
        return ch(0x4D4D, ch(0x0002, bb(4).putInt(3).array()),
            ch(0x3D3D, ch(0x3D3E, bb(4).putInt(3).array()), *mats.toTypedArray(), *objs.toTypedArray()))
    }
}
