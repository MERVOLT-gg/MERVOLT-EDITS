package com.mervolt.edits

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private class RoadDef(val pts: List<FloatArray>, val rough: Boolean)
    private class Snap(val t: List<Triple<Terrain, FloatArray, FloatArray>>, val o: List<Pair<Obj3, FloatArray>>, val roads: List<RoadDef>)

    private lateinit var gl: GLSurfaceView
    private lateinit var info: TextView
    private val r = Renderer()
    private var dir: DocumentFile? = null
    private val terrains = ArrayList<Terrain>(); private val objs = ArrayList<Obj3>()
    private val roads = ArrayList<RoadDef>(); private var roadParts = listOf<Part>(); private var markers = listOf<Part>()
    private val pts = ArrayList<FloatArray>(); private var ptsRough = false
    private var mode = 0; private var tool = 0; private var radius = 12f; private var side = 0
    private var sel: Any? = null
    private var base = "model"; private var pendingExport = false; private var missing = ""; private var oid = 1; private var tid = 1
    private val undoS = ArrayList<Snap>(); private val redoS = ArrayList<Snap>()
    private val modeNames = arrayOf("Vue", "Sculpt", "Road", "Road lavaka", "Select", "Move")
    private val toolNames = arrayOf("Raise", "Lower", "Smooth"); private val sideNames = arrayOf("E", "W", "N", "S")
    private val mk = Mat("marker").apply { kd = floatArrayOf(1f, 0.6f, 0f) }
    private var lastDab: FloatArray? = null
    private var grab = FloatArray(4)

    private fun btn(t: String, f: (Button) -> Unit): Button { val b = Button(this); b.text = t; b.textSize = 12f; b.setOnClickListener { f(b) }; return b }
    private fun allParts(m: Boolean): List<Part> = terrains.map { it.part } + objs.flatMap { it.parts } + roadParts + (if (m) markers else emptyList())
    private fun hAt(x: Float, z: Float): Float = terrains.firstOrNull { it.contains(x, z) }?.height(x, z) ?: 0f
    private fun inv(p: Part) { gl.queueEvent { r.invalidate(p) }; gl.requestRender() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(2); setEGLConfigChooser(8, 8, 8, 8, 16, 0); setRenderer(r); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY }
        val root = FrameLayout(this); root.addView(gl)
        val row1 = LinearLayout(this); val row2 = LinearLayout(this)
        row1.addView(btn("OBJ") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 1) })
        row1.addView(btn("Terrain+") { addTerrain() })
        row1.addView(btn("Sisiny: E") { side = (side + 1) % 4; it.text = "Sisiny: ${sideNames[side]}"; refresh() })
        row1.addView(btn("Mode: Vue") { mode = (mode + 1) % 6; it.text = "Mode: ${modeNames[mode]}"; refresh() })
        row1.addView(btn("Brush: Raise") { tool = (tool + 1) % 3; it.text = "Brush: ${toolNames[tool]}"; refresh() })
        row1.addView(btn("R+") { radius = min(60f, radius + 3f); refresh() })
        row1.addView(btn("R-") { radius = max(3f, radius - 3f); refresh() })
        row1.addView(btn("Road vita") { buildRoad() })
        row1.addView(btn("Re-snap") { save(); rebuildRoads(); push(false) })
        row1.addView(btn("Fafao road") { save(); pts.clear(); markers = emptyList(); roadParts = emptyList(); roads.clear(); push(false) })
        row1.addView(btn("Fit") { gl.queueEvent { r.fit() }; gl.requestRender() })
        row2.addView(btn("Objet+") { addObject() })
        row2.addView(btn("Texture") { pickTexture() })
        row2.addView(btn("Rot+") { xf { it.yaw += 0.2618f } })
        row2.addView(btn("Rot-") { xf { it.yaw -= 0.2618f } })
        row2.addView(btn("Sc+") { xf { it.scale *= 1.15f } })
        row2.addView(btn("Sc-") { xf { it.scale /= 1.15f } })
        row2.addView(btn("Fafa") { delSel() })
        row2.addView(btn("Undo") { doUndo() })
        row2.addView(btn("Redo") { doRedo() })
        row2.addView(btn("Export .obj") { export() })
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.addView(HorizontalScrollView(this).also { it.addView(row1) }); col.addView(HorizontalScrollView(this).also { it.addView(row2) })
        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; setPadding(16, 16, 16, 16) }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(TextView(this).apply {   // WATERMARK
            text = "MERVOLT EDITS Claude ai"; setTextColor(Color.argb(170, 255, 255, 255)); textSize = 14f
            setShadowLayer(4f, 1f, 1f, Color.BLACK); setPadding(16, 16, 16, 16)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        setContentView(root); refresh()

        val sc = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { r.dist /= d.scaleFactor; gl.requestRender(); return true } })
        var lx = 0f; var ly = 0f; var moved = 0f; var multi = false
        gl.setOnTouchListener { _, e ->
            sc.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; moved = 0f; multi = false; lastDab = null
                    if (mode == 1) { save(); dab(e.x, e.y, true) } else if (mode == 5) beginGrab(e.x, e.y) }
                MotionEvent.ACTION_POINTER_DOWN -> { multi = true; lx = (e.getX(0) + e.getX(1)) / 2; ly = (e.getY(0) + e.getY(1)) / 2 }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {   // 2 rantsantanana = pan + zoom
                        val cx = (e.getX(0) + e.getX(1)) / 2; val cy = (e.getY(0) + e.getY(1)) / 2
                        r.px += (cx - lx) * r.dist * 0.0012f; r.py -= (cy - ly) * r.dist * 0.0012f; lx = cx; ly = cy; gl.requestRender()
                    } else if (!multi) {
                        moved += abs(e.x - lx) + abs(e.y - ly)
                        when (mode) {
                            0 -> { r.ry += (e.x - lx) * 0.4f; r.rx += (e.y - ly) * 0.4f; gl.requestRender() }
                            1 -> dab(e.x, e.y, false)
                            5 -> dragTo(e.x, e.y)
                        }
                        lx = e.x; ly = e.y
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastDab = null
                    if (!multi && moved < 20f) { if (mode == 2 || mode == 3) addPoint(e.x, e.y) else if (mode == 4) selectAt(e.x, e.y) }
                    if (mode == 5) endGrab()
                }
            }
            true
        }
    }

    // ---------- fototra ----------
    private fun push(fit: Boolean) {
        val p = allParts(true)
        gl.queueEvent { r.applyParts(p); if (fit) r.fit() }; gl.requestRender(); refresh()
    }

    private fun selName(): String = when (val s = sel) { is Obj3 -> s.name; is Terrain -> s.name; else -> "-" }

    private fun refresh() {
        info.text = "Mode: ${modeNames[mode]} | ${toolNames[tool]} R=${radius.toInt()} | Sisiny: ${sideNames[side]} | teboka: ${pts.size}\n" +
            "terrain: ${terrains.size} | objet: ${objs.size} | road+traffic: ${roadParts.size} | Safidy: ${selName()}" + missing
    }

    private fun updateSel() {
        objs.forEach { o -> o.parts.forEach { it.selected = o === sel } }
        terrains.forEach { it.part.selected = it === sel }
        gl.requestRender(); refresh()
    }

    // ---------- Undo / Redo ----------
    private fun snap() = Snap(terrains.map { Triple(it, it.h.copyOf(), floatArrayOf(it.ox, it.oz)) }, objs.map { it to it.state() }, roads.toList())
    private fun save() { undoS.add(snap()); if (undoS.size > 30) undoS.removeAt(0); redoS.clear() }
    private fun restore(s: Snap) {
        terrains.clear(); s.t.forEach { (t, hh, o) -> System.arraycopy(hh, 0, t.h, 0, hh.size); t.ox = o[0]; t.oz = o[1]; t.rebuildPos(); terrains.add(t) }
        objs.clear(); s.o.forEach { (ob, st) -> ob.restore(st); objs.add(ob) }
        roads.clear(); roads.addAll(s.roads); rebuildRoads()
        val ps = allParts(false); gl.queueEvent { ps.forEach { r.invalidate(it) } }
        sel = null; updateSel(); push(false)
    }
    private fun doUndo() { if (undoS.isEmpty()) return toast("Tsy misy Undo"); redoS.add(snap()); restore(undoS.removeAt(undoS.lastIndex)) }
    private fun doRedo() { if (redoS.isEmpty()) return toast("Tsy misy Redo"); undoS.add(snap()); restore(redoS.removeAt(redoS.lastIndex)) }

    // ---------- Picking ----------
    private fun pick(x: Float, y: Float): FloatArray? {
        if (terrains.isEmpty()) return null; val (o, d) = r.ray(x, y) ?: return null
        var s = 0f
        repeat(3000) {
            val px = o[0] + d[0] * s; val py = o[1] + d[1] * s; val pz = o[2] + d[2] * s
            val t = terrains.firstOrNull { it.contains(px, pz) }
            if (t != null && py <= t.height(px, pz)) return floatArrayOf(px, py, pz)
            s += 1f
        }
        return null
    }

    private fun planeHit(x: Float, y: Float, py: Float): FloatArray? {
        val (o, d) = r.ray(x, y) ?: return null
        if (abs(d[1]) < 1e-6f) return null
        val t = (py - o[1]) / d[1]; if (t < 0) return null
        return floatArrayOf(o[0] + d[0] * t, o[2] + d[2] * t)
    }

    private fun aabb(o: FloatArray, d: FloatArray, b: FloatArray): Float? {
        var t0 = 0f; var t1 = 1e9f
        for (k in 0..2) {
            if (abs(d[k]) < 1e-9f) { if (o[k] < b[k] || o[k] > b[k + 3]) return null }
            else { var a = (b[k] - o[k]) / d[k]; var c = (b[k + 3] - o[k]) / d[k]; if (a > c) { val t = a; a = c; c = t }
                t0 = max(t0, a); t1 = min(t1, c); if (t0 > t1) return null }
        }
        return t0
    }

    private fun selectAt(x: Float, y: Float) {
        val (o, d) = r.ray(x, y) ?: return
        var bestT = 1e9f; var best: Any? = null
        for (ob in objs) { val t = aabb(o, d, ob.bounds()); if (t != null && t < bestT) { bestT = t; best = ob } }
        val h = pick(x, y)
        if (h != null) { val t = hypot(hypot(h[0] - o[0], h[1] - o[1]), h[2] - o[2]); if (t < bestT) { bestT = t; best = terrains.firstOrNull { it.contains(h[0], h[2]) } } }
        sel = best; updateSel()
    }

    // ---------- Sculpt ----------
    private fun syncSeams() { for (i in terrains.indices) for (j in i + 1 until terrains.size) terrains[i].sync(terrains[j], false) }

    /** Dab isaky ny R*0.3 (tsy isaky ny hetsika), ka tsy midina foana. */
    private fun dab(x: Float, y: Float, force: Boolean) {
        val h = pick(x, y) ?: return
        val ld = lastDab
        if (!force && ld != null && hypot(h[0] - ld[0], h[2] - ld[1]) < radius * 0.3f) return
        lastDab = floatArrayOf(h[0], h[2])
        for (t in terrains) t.sculpt(h[0], h[2], radius, 0.1f + radius * 0.02f, tool)
        syncSeams(); terrains.forEach { inv(it.part) }
    }

    // ---------- Terrain ----------
    private fun addTerrain() {
        val b = (sel as? Terrain) ?: terrains.lastOrNull()
        val dx = if (side == 0) 1f else if (side == 1) -1f else 0f; val dz = if (side == 2) -1f else if (side == 3) 1f else 0f
        val nx = if (b == null) 0f else b.ox + dx * b.size; val nz = if (b == null) 0f else b.oz + dz * b.size
        if (terrains.any { abs(it.ox - nx) < 1f && abs(it.oz - nz) < 1f }) return toast("Efa misy terrain eo")
        save()
        val t = Terrain("terrain_${tid++}", ox = nx, oz = nz)
        if (b != null) t.sync(b, true)
        for (o in terrains) if (o !== b) t.sync(o, false)
        terrains.add(t); sel = t; updateSel(); push(terrains.size == 1)
    }

    // ---------- Move ----------
    private fun beginGrab(x: Float, y: Float) {
        val s = sel ?: return
        val py = if (s is Obj3) s.y else 0f
        val h = planeHit(x, y, py) ?: return
        save()
        grab = if (s is Obj3) floatArrayOf(h[0], h[1], s.x, s.z) else { val t = s as Terrain; floatArrayOf(h[0], h[1], t.ox, t.oz) }
    }

    private fun dragTo(x: Float, y: Float) {
        val s = sel ?: return
        val h = planeHit(x, y, if (s is Obj3) s.y else 0f) ?: return
        var nx = grab[2] + h[0] - grab[0]; var nz = grab[3] + h[1] - grab[1]
        if (s is Obj3) { s.x = nx; s.z = nz; if (s.snap) s.y = hAt(nx, nz); s.apply(); s.parts.forEach { inv(it) } }
        else if (s is Terrain) {
            for (o in terrains) if (o !== s) for (a in floatArrayOf(-s.size, s.size)) {
                if (abs(nx - (o.ox + a)) < 6f && abs(nz - o.oz) < 6f) { nx = o.ox + a; nz = o.oz }
                else if (abs(nz - (o.oz + a)) < 6f && abs(nx - o.ox) < 6f) { nz = o.oz + a; nx = o.ox }
            }
            s.ox = nx; s.oz = nz; s.rebuildPos(); inv(s.part)
        }
    }

    private fun endGrab() { if (sel is Terrain) { syncSeams(); terrains.forEach { inv(it.part) } } }

    // ---------- Objet ----------
    private fun addObject() {
        AlertDialog.Builder(this).setItems(Catalog.names) { _, i ->
            save()
            val ob = Catalog.make(i, oid++)
            val c = pick(gl.width / 2f, gl.height / 2f)
            ob.x = c?.get(0) ?: 0f; ob.z = c?.get(2) ?: 0f; ob.y = hAt(ob.x, ob.z); ob.apply()
            objs.add(ob); sel = ob; updateSel(); push(false)
        }.show()
    }

    private fun xf(f: (Obj3) -> Unit) {
        val o = sel as? Obj3 ?: return toast("Safidio aloha ny objet (Mode: Select)")
        save(); f(o); if (o.snap) o.y = hAt(o.x, o.z); o.apply(); o.parts.forEach { inv(it) }
    }

    private fun delSel() {
        val s = sel ?: return toast("Safidio aloha (Mode: Select)")
        save()
        if (s is Obj3) objs.remove(s) else if (s is Terrain) terrains.remove(s)
        sel = null; updateSel(); push(false)
    }

    // ---------- Texture ----------
    private fun pickTexture() {
        if (sel == null) return toast("Safidio aloha ny objet/terrain (Mode: Select)")
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, 3)
    }

    private fun applyTexture(u: Uri) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(u)) ?: throw Exception("sary tsy mety")
                val nm = (DocumentFile.fromSingleUri(this, u)?.name ?: "tex").substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_") + ".png"
                runOnUiThread {
                    val mats = when (val s = sel) { is Obj3 -> s.parts.map { it.mat }; is Terrain -> listOf(s.part.mat); else -> emptyList() }
                    mats.distinct().forEach { m -> m.bmp = bmp; m.tex = nm; m.kd = floatArrayOf(1f, 1f, 1f); gl.queueEvent { r.dropTex(m) } }
                    gl.requestRender(); toast("Texture napetraka: $nm")
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana texture: ${e.message}") } }
        }.start()
    }

    // ---------- Road ----------
    private fun addPoint(x: Float, y: Float) {
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha"); val h = pick(x, y) ?: return
        pts.add(floatArrayOf(h[0], h[2])); ptsRough = mode == 3
        markers = pts.mapIndexed { i, p -> val yy = hAt(p[0], p[1]) + 0.6f; val s = 1f
            Part("m$i", mk, floatArrayOf(p[0] - s, yy, p[1] - s, p[0] + s, yy, p[1] - s, p[0] + s, yy, p[1] + s, p[0] - s, yy, p[1] + s), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)) }
        push(false)
    }

    private fun rebuildRoads() {
        val c = intArrayOf(1); val hf: (Float, Float) -> Float = { x, z -> hAt(x, z) }
        roadParts = roads.flatMapIndexed { i, rd -> Road.build(rd.pts, hf, rd.rough, i + 1, c) }
    }

    /** Road vaovao: raha manomboka akaikin'ny tendron'ny road efa misy (<8 m) ary mitovy karazana dia mitohy ho road iray. */
    private fun buildRoad() {
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha")
        if (pts.size < 2) return toast("Mode Road: tsindrio teboka 2 farafahakeliny")
        save()
        val np = pts.map { it.clone() }.toMutableList()
        fun near(p: FloatArray): Pair<Int, Boolean>? {
            var bi = -1; var be = false; var bd = 8f
            roads.forEachIndexed { i, rd -> for (end in booleanArrayOf(false, true)) {
                val e = if (end) rd.pts.last() else rd.pts.first(); val dd = hypot(e[0] - p[0], e[1] - p[1])
                if (dd < bd) { bd = dd; bi = i; be = end } } }
            return if (bi >= 0) bi to be else null
        }
        var merged = false
        val a = near(np.first())
        if (a != null) {
            val rd = roads[a.first]; np[0] = (if (a.second) rd.pts.last() else rd.pts.first()).clone()
            if (rd.rough == ptsRough) {
                roads[a.first] = RoadDef(if (a.second) rd.pts + np.drop(1) else np.reversed().dropLast(1) + rd.pts, rd.rough); merged = true
            }
        }
        if (!merged) {
            val b = near(np.last()); if (b != null) { val rd = roads[b.first]; np[np.lastIndex] = (if (b.second) rd.pts.last() else rd.pts.first()).clone() }
            roads.add(RoadDef(np, ptsRough))
        }
        pts.clear(); markers = emptyList(); rebuildRoads(); push(false)
    }

    // ---------- Import / Export ----------
    private fun find(n: String) = dir?.listFiles()?.firstOrNull { it.name.equals(n, true) }
    private fun lines(f: DocumentFile) = contentResolver.openInputStream(f.uri)!!.bufferedReader().readLines()

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val u = d?.data ?: return
        if (rc == 3) { applyTexture(u); return }
        dir = DocumentFile.fromTreeUri(this, u)
        if (rc == 2) { if (pendingExport) { pendingExport = false; export() }; return }
        val objsF = dir!!.listFiles().filter { it.name?.endsWith(".obj", true) == true }
        when {
            objsF.isEmpty() -> toast("Tsy misy .obj ao amin'io lahatahiry io")
            objsF.size == 1 -> load(objsF[0])
            else -> AlertDialog.Builder(this).setItems(objsF.map { it.name }.toTypedArray()) { _, i -> load(objsF[i]) }.show()
        }
    }

    private fun load(f: DocumentFile) {
        base = f.name!!.substringBeforeLast('.')
        Thread {
            try {
                val p = Obj.parse(lines(f), { n -> find(n.substringAfterLast('/'))?.let { lines(it) } }, base)
                val miss = ArrayList<String>()
                for (pt in p) {
                    val tn = pt.mat.tex
                    if (pt.mat.bmp == null && tn != null) {
                        val tf = find(tn)
                        if (tf != null) pt.mat.bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(tf.uri)) else miss.add(tn)
                    }
                }
                runOnUiThread {
                    p.forEach { objs.add(Obj3(it.name, listOf(it), false)) }
                    missing = if (miss.isEmpty()) "" else "\n⚠ texture tsy hita: " + miss.distinct().joinToString()
                    push(true)
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana: ${e.message}") } }
        }.start()
    }

    private fun export() {
        val d = dir
        if (d == null) { pendingExport = true; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2); return }
        val ps = allParts(false); if (ps.isEmpty()) return toast("Tsy misy modely")
        val name = if (objs.isEmpty()) "terrain_road" else "${base}_edit"
        try {
            val (obj, mtl) = ObjWriter.write(ps, name)
            for ((fn, txt) in listOf("$name.obj" to obj, "$name.mtl" to mtl)) {
                find(fn)?.delete()
                val out = d.createFile("application/octet-stream", fn)!!
                contentResolver.openOutputStream(out.uri)!!.use { it.write(txt.toByteArray()) }
            }
            for (m in ps.map { it.mat }.distinct()) {   // soraty ny PNG vaovao (texture nampidirina)
                val tn = m.tex; val b = m.bmp
                if (tn != null && b != null && find(tn) == null) {
                    val tf = d.createFile("image/png", tn)!!
                    contentResolver.openOutputStream(tf.uri)!!.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
            }
            toast("Vita: $name.obj + .mtl (${ps.size} objet)")
        } catch (e: Exception) { toast("Olana export: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
