package com.mervolt.edits

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.os.Looper
import android.view.View
import java.io.*
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.ceil
import kotlin.math.acos
import kotlin.math.tan
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private class RoadDef(val pts: List<FloatArray>, val rough: Boolean)
    private class GenDef(val pts: List<FloatArray>, val profile: Int, val rise: Float)
    private class Snap(val t: List<Triple<Terrain, FloatArray, FloatArray>>, val o: List<Pair<Obj3, FloatArray>>, val roads: List<RoadDef>, val gens: List<GenDef>, val pads: List<FloatArray>, val links: List<Pair<Obj3, Obj3>>)

    private lateinit var gl: GLSurfaceView
    private lateinit var info: TextView
    private val r = Renderer()
    private var dir: DocumentFile? = null
    private val terrains = ArrayList<Terrain>(); private val objs = ArrayList<Obj3>()
    private val roads = ArrayList<RoadDef>(); private var roadParts = listOf<Part>(); private var markers = listOf<Part>()
    private val pts = ArrayList<FloatArray>(); private var ptsRough = false
    private var mode = 0; private var tool = 0; private var radius = 12f; private var side = 0
    private var sel: Any? = null
    private var base = "model"; private var pendingExport = false; private var missing = ""; private var oid = 1; private var tid = 1
    private val undoS = ArrayList<Snap>(); private val redoS = ArrayList<Snap>()
    private val modeNames = arrayOf("Vue", "Sculpt", "Road", "Road lavaka", "Select", "Move", "Generate")
    private val toolNames = arrayOf("Raise", "Lower", "Smooth"); private val sideNames = arrayOf("E", "W", "N", "S")
    private val mk = Mat("marker").apply { kd = floatArrayOf(1f, 0.6f, 0f) }
    private var lastDab: FloatArray? = null
    private class RoadSel(val rough: Boolean)
    private val roadMat = Mat("road").apply { kd = floatArrayOf(0.25f, 0.25f, 0.27f) }
    private val lavaMat = Mat("road_lava").apply { kd = floatArrayOf(0.33f, 0.27f, 0.22f) }
    private var rowsAll = listOf<Pair<List<Row>, Boolean>>()
    private var grab = FloatArray(4)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun style(b: Button, on: Boolean) { b.setBackgroundColor(if (on) Color.rgb(255, 170, 40) else Color.rgb(60, 60, 66)); b.setTextColor(if (on) Color.BLACK else Color.WHITE) }
    private fun btn(t: String, f: (Button) -> Unit): Button {
        val b = Button(this); b.text = t; b.textSize = 10.5f; b.setAllCaps(false)
        b.minHeight = 0; b.minimumHeight = 0; b.minWidth = 0; b.minimumWidth = 0; b.setPadding(dp(8), 0, dp(8), 0)
        style(b, false); b.setOnClickListener { f(b) }
        b.layoutParams = LinearLayout.LayoutParams(-2, dp(28)).also { it.setMargins(dp(2), dp(2), dp(2), dp(2)) }
        return b
    }
    private fun allParts(m: Boolean): List<Part> = terrains.flatMap { it.cut ?: listOf(it.part) } + objs.flatMap { it.parts } + roadParts + wireParts + (if (m) markers else emptyList())
    private fun hAt(x: Float, z: Float): Float = terrains.firstOrNull { it.contains(x, z) }?.height(x, z) ?: 0f
    private fun inv(p: Part) { gl.queueEvent { r.invalidate(p) }; gl.requestRender() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(2); setEGLConfigChooser(8, 8, 8, 8, 24, 0); setRenderer(r); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY }
        val root = FrameLayout(this); root.addView(gl)
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        fun scroller(vararg bs: Button): HorizontalScrollView { val l = LinearLayout(this); bs.forEach { l.addView(it) }; return HorizontalScrollView(this).also { it.addView(l) } }
        arrayOf("Vue", "Sculpt", "Road", "Lavaka", "Select", "Move", "Gen").forEachIndexed { i, n -> modeBtns.add(btn(n) { setMode(i) }) }
        col.addView(scroller(*modeBtns.toTypedArray()))
        panels.add(scroller(btn("Fit") { gl.queueEvent { r.fit() }; gl.requestRender() }))
        panels.add(scroller(btn("Brush: Raise") { tool = (tool + 1) % 3; it.text = "Brush: ${toolNames[tool]}"; refresh() },
            btn("R+") { radius = min(60f, radius + 3f); refresh() }, btn("R-") { radius = max(3f, radius - 3f); refresh() }))
        panels.add(scroller(btn("Road vita") { buildRoad() }, btn("Re-snap") { save(); resnapAll(); rebuildRoads(); push(false) }, btn("Generate traffic") { generateTraffic() }, btn("Re-snap traffic") { resnapTraffic() }, btn("Lane-") { laneShift(-0.5f) }, btn("Lane+") { laneShift(0.5f) },
            btn("Fafao road") { save(); pts.clear(); markers = emptyList(); roadParts = emptyList(); roads.clear(); push(false) }))
        panels.add(scroller(btn("Texture") { pickTexture() }, btn("Rot+") { xf { it.yaw += 0.2618f } }, btn("Rot-") { xf { it.yaw -= 0.2618f } },
            btn("Sc+") { xf { it.scale *= 1.15f } }, btn("Sc-") { xf { it.scale /= 1.15f } }, btn("Fafa") { delSel() }, btn("Terrain=Ity") { makeTerrainFromSel() }, btn("Road=Ity") { setRoadSrc() }))
        panels.add(scroller(btn("Karazana: Terrain") { genKind = (genKind + 1) % 5; it.text = "Karazana: ${genKindNames[genKind]}"; refresh() },
            btn("Generate") { generate() },
            btn("Profil: ${Gen.names[0]}") { genProfile = (genProfile + 1) % 4; it.text = "Profil: ${Gen.names[genProfile]}"; refresh() },
            btn("Rampe: Mitovy") { genDir = (genDir + 1) % 3; it.text = "Rampe: ${genDirNames[genDir]}"; refresh() },
            btn("R+") { genRise = min(30f, genRise + 1f); refresh() }, btn("R-") { genRise = max(0f, genRise - 1f); refresh() },
            btn("Fafao teboka") { pts.clear(); markers = emptyList(); push(false) }))
        panels.forEach { col.addView(it) }
        col.addView(scroller(btn("Terrain+") { addTerrain() }, btn("Sisiny: E") { side = (side + 1) % 4; it.text = "Sisiny: ${sideNames[side]}"; refresh() },
            btn("Objet+") { addObject() }, btn("Undo") { doUndo() }, btn("Redo") { doRedo() },
            btn("Import OBJ") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 1) },
            btn("Export .obj") { export() }, btn("Profil") { profileMenu() }))
        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; setPadding(16, 16, 16, 16) }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(TextView(this).apply {   // WATERMARK
            text = "MERVOLT EDITS Claude ai"; setTextColor(Color.argb(170, 255, 255, 255)); textSize = 14f
            setShadowLayer(4f, 1f, 1f, Color.BLACK); setPadding(16, 16, 16, 16)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        root.addView(TextView(this).apply {   // legend reper
            val sp = SpannableString("X   Y   Z"); sp.setSpan(ForegroundColorSpan(Color.rgb(255, 70, 70)), 0, 1, 0)
            sp.setSpan(ForegroundColorSpan(Color.rgb(70, 255, 70)), 4, 5, 0); sp.setSpan(ForegroundColorSpan(Color.rgb(90, 140, 255)), 8, 9, 0)
            text = sp; textSize = 13f; setPadding(0, 0, 0, 0)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).also { it.setMargins(0, 0, dp(12), 90 + (resources.displayMetrics.widthPixels * 0.22f).toInt() + 6) })
        setContentView(root)
        profile = prefs.getString("profile", "profil_1") ?: "profil_1"; pdir(); setMode(0); loadProfile()

        val sc = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { r.dist /= d.scaleFactor; gl.requestRender(); return true } })
        var lx = 0f; var ly = 0f; var moved = 0f; var multi = false
        gl.setOnTouchListener { _, e ->
            sc.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; moved = 0f; multi = false; lastDab = null
                    if (mode == 1) { save(); dab(e.x, e.y, true) } else if (mode == 5) beginGrab(e.x, e.y) }
                MotionEvent.ACTION_POINTER_DOWN -> { multi = true; lx = (e.getX(0) + e.getX(1)) / 2; ly = (e.getY(0) + e.getY(1)) / 2 }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {   // 2 rantsantanana = pan + zoom
                        val cx = (e.getX(0) + e.getX(1)) / 2; val cy = (e.getY(0) + e.getY(1)) / 2
                        r.px += (cx - lx) * r.dist * 0.0012f; r.py -= (cy - ly) * r.dist * 0.0012f; lx = cx; ly = cy; gl.requestRender()
                    } else if (!multi) {
                        moved += abs(e.x - lx) + abs(e.y - ly)
                        when (mode) {
                            0 -> { r.ry += (e.x - lx) * 0.4f; r.rx += (e.y - ly) * 0.4f; gl.requestRender() }
                            1 -> dab(e.x, e.y, false)
                            5 -> dragTo(e.x, e.y)
                            2, 3, 6 -> stroke(e.x, e.y, moved)
                        }
                        lx = e.x; ly = e.y
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastDab = null
                    if (mode == 1) { resnapAll(); if (roads.isNotEmpty()) rebuildRoads(); push(false) }   // averina ny road amin'ny tany vaovao
                    if (!multi && moved < 20f) { if (mode == 2 || mode == 3 || mode == 6) addPoint(e.x, e.y) else if (mode == 4) selectAt(e.x, e.y) }
                    if (mode == 5) endGrab()
                }
            }
            true
        }
    }

    // ---------- Mode / UI ----------
    private val modeBtns = ArrayList<Button>(); private val panels = ArrayList<View>()
    private fun setMode(m: Int) {
        mode = m
        modeBtns.forEachIndexed { i, b -> style(b, i == m) }
        val pi = when (m) { 0 -> 0; 1 -> 1; 2, 3 -> 2; 6 -> 4; else -> 3 }
        panels.forEachIndexed { i, p -> p.visibility = if (i == pi) View.VISIBLE else View.GONE }
        refresh()
    }

    // ---------- Profil + sauvegarde auto ----------
    private var profile = "profil_1"
    private val prefs by lazy { getSharedPreferences("mervolt", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val saver = Runnable { saveNow(true) }
    private fun pdir(n: String = profile) = File(filesDir, "profiles/$n").also { it.mkdirs() }
    private fun profiles(): List<String> = File(filesDir, "profiles").list()?.sorted() ?: emptyList()
    private fun dirty() { handler.removeCallbacks(saver); handler.postDelayed(saver, 1500) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(saver); saveNow(false) }

    private fun matOut(o: DataOutputStream, m: Mat) { o.writeUTF(m.tex ?: ""); for (v in m.kd) o.writeFloat(v) }

    private fun serialize(): ByteArray {
        val bo = ByteArrayOutputStream(); val o = DataOutputStream(bo)
        o.writeInt(0x4D455632); o.writeUTF(base); o.writeInt(oid); o.writeInt(tid)
        o.writeInt(terrains.size)
        for (t in terrains) { o.writeUTF(t.name); o.writeInt(t.n); o.writeFloat(t.size); o.writeFloat(t.ox); o.writeFloat(t.oz)
            for (v in t.h) o.writeFloat(v); matOut(o, t.part.mat) }
        matOut(o, roadMat); matOut(o, lavaMat)
        o.writeInt(objs.size)
        for (ob in objs) {
            val me = objs.indexOf(ob); val srcI = ob.src?.let { objs.indexOf(it) } ?: -1
            val ty = if (ob.cat >= 0) 0 else if (srcI in 0 until me) 2 else if (ob.parts.any { it.poly != null }) 4 else 1
            o.writeByte(ty); o.writeUTF(ob.name)
            for (v in ob.state()) o.writeFloat(v)
            o.writeInt(ob.parts.size)
            if (ty == 2) o.writeInt(srcI)
            else if (ob.cat >= 0) { o.writeInt(ob.cat); o.writeInt(ob.cid); for (p in ob.parts) matOut(o, p.mat) }
            else for ((k, p) in ob.parts.withIndex()) {
                o.writeUTF(p.name); o.writeUTF(p.mat.name); matOut(o, p.mat)
                val b = ob.base[k]; o.writeInt(b.size); for (v in b) o.writeFloat(v)
                o.writeInt(p.uv.size); for (v in p.uv) o.writeFloat(v)
                o.writeInt(p.idx.size); for (v in p.idx) o.writeInt(v)
                if (ty == 4) { val sz = p.polySizes ?: IntArray(0); val pl = p.poly ?: IntArray(0); o.writeInt(sz.size); for (v in sz) o.writeInt(v); o.writeInt(pl.size); for (v in pl) o.writeInt(v) }
            }
        }
        o.writeInt(roads.size)
        for (rd in roads) { o.writeBoolean(rd.rough); o.writeInt(rd.pts.size); for (p in rd.pts) { o.writeFloat(p[0]); o.writeFloat(p[1]) } }
        o.writeInt(gens.size)
        for (g in gens) { o.writeInt(g.profile); o.writeFloat(g.rise); o.writeInt(g.pts.size); for (p in g.pts) { o.writeFloat(p[0]); o.writeFloat(p[1]) } }
        o.writeInt(pads.size); for (p in pads) { o.writeFloat(p[0]); o.writeFloat(p[1]) }
        o.writeInt(links.size); for ((a, b) in links) { o.writeInt(objs.indexOf(a)); o.writeInt(objs.indexOf(b)) }
        o.writeInt(roadSrc?.let { objs.indexOf(it) } ?: -1)
        o.flush(); return bo.toByteArray()
    }

    @Synchronized private fun writeFiles(d: File, bytes: ByteArray, texs: List<Pair<String, Bitmap>>) {
        val td = File(d, "tex").also { it.mkdirs() }
        for ((n, b) in texs) { val f = File(td, n); if (!f.exists()) FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        val tmp = File(d, "project.tmp"); tmp.writeBytes(bytes); tmp.renameTo(File(d, "project.bin"))
    }

    private fun saveNow(bg: Boolean) {
        try {
            val bytes = serialize(); val d = pdir()
            val texs = allParts(false).map { it.mat }.distinct().filter { it.tex != null && it.bmp != null }.distinctBy { it.tex }.map { it.tex!! to it.bmp!! }
            val job = Runnable { try { writeFiles(d, bytes, texs) } catch (e: Exception) { } }
            if (bg) Thread(job).start() else job.run()
        } catch (e: Exception) { }
    }

    private fun clearState() {
        terrains.clear(); objs.clear(); roads.clear(); roadParts = emptyList(); markers = emptyList(); pts.clear()
        sel = null; undoS.clear(); redoS.clear(); oid = 1; tid = 1; missing = ""; base = "model"; gens.clear(); pads.clear(); links.clear(); wireParts = emptyList(); roadSrc = null; srcMH = null; srcPaths = emptyList(); genRise = 3f; resetMats()
    }

    private fun loadProfile() {
        val f = File(pdir(), "project.bin")
        if (!f.exists()) { push(true); return }
        try {
            val i = DataInputStream(BufferedInputStream(FileInputStream(f)))
            if (i.readInt() != 0x4D455632) throw Exception("fichier tsy mety")
            base = i.readUTF(); oid = i.readInt(); tid = i.readInt()
            val cache = HashMap<String, Bitmap?>()
            fun bmpOf(n: String): Bitmap? = cache.getOrPut(n) { val tf = File(File(pdir(), "tex"), n); if (tf.exists()) BitmapFactory.decodeFile(tf.path) else null }
            fun matIn(m: Mat) { val tn = i.readUTF(); m.kd = floatArrayOf(i.readFloat(), i.readFloat(), i.readFloat()); if (tn.isNotEmpty()) { m.tex = tn; m.bmp = bmpOf(tn) } }
            repeat(i.readInt()) {
                val nm = i.readUTF(); val n = i.readInt(); val sz = i.readFloat(); val ox = i.readFloat(); val oz = i.readFloat()
                val t = Terrain(nm, n, sz, ox, oz); for (k in t.h.indices) t.h[k] = i.readFloat()
                t.rebuildPos(); matIn(t.part.mat); terrains.add(t)
            }
            matIn(roadMat); matIn(lavaMat)
            repeat(i.readInt()) {
                val type = i.readByte().toInt(); val nm = i.readUTF(); val st = FloatArray(5) { i.readFloat() }; val np = i.readInt()
                if (type == 2) {
                    val tpl = objs[i.readInt()]; val ob = tpl.cloneAs(nm); ob.restore(st); objs.add(ob)
                } else if (type == 0) {
                    val cat = i.readInt(); val cid = i.readInt(); val ob = Catalog.make(cat, cid)
                    for (p in ob.parts) matIn(p.mat); ob.restore(st); objs.add(ob)
                } else {
                    val ps = ArrayList<Part>()
                    val mcache = HashMap<String, Mat>()
                    repeat(np) {
                        val pn = i.readUTF(); val mn = i.readUTF(); val mat = mcache.getOrPut(mn) { Mat(mn) }; matIn(mat)
                        val pos = FloatArray(i.readInt()) { i.readFloat() }; val uv = FloatArray(i.readInt()) { i.readFloat() }; val idx = IntArray(i.readInt()) { i.readInt() }
                        val psz = if (type == 4) IntArray(i.readInt()) { i.readInt() } else null
                        val pol = if (type == 4) IntArray(i.readInt()) { i.readInt() } else null
                        ps.add(Part(pn, mat, pos, uv, idx).also { if (pn.startsWith("traffic_")) it.quad = true; if (psz != null && pol != null) { it.polySizes = psz; it.poly = pol } })
                    }
                    val ob = Obj3(nm, ps, false); ob.restore(st); objs.add(ob)
                }
            }
            repeat(i.readInt()) {
                val rough = i.readBoolean(); val c = i.readInt(); val l = ArrayList<FloatArray>()
                repeat(c) { l.add(floatArrayOf(i.readFloat(), i.readFloat())) }; roads.add(RoadDef(l, rough))
            }
            if (i.available() > 0) repeat(i.readInt()) {
                val pr = i.readInt(); val rz = i.readFloat(); val c = i.readInt(); val l = ArrayList<FloatArray>()
                repeat(c) { l.add(floatArrayOf(i.readFloat(), i.readFloat())) }; gens.add(GenDef(l, pr, rz))
            }
            if (i.available() > 0) repeat(i.readInt()) { pads.add(floatArrayOf(i.readFloat(), i.readFloat())) }
            if (i.available() > 0) repeat(i.readInt()) { val a = i.readInt(); val b = i.readInt(); if (a in objs.indices && b in objs.indices) links.add(objs[a] to objs[b]) }
            if (i.available() > 0) { val ri = i.readInt(); if (ri in objs.indices) roadSrc = objs[ri] }
            i.close(); refreshRoadSrc(); rebuildRoads(); rebuildWires(); push(true)
        } catch (e: Exception) { toast("Olana famakiana profil: ${e.message}"); push(true) }
    }

    private fun switchTo(n: String) {
        if (n == profile) return
        handler.removeCallbacks(saver); saveNow(false); clearState()
        profile = n; prefs.edit().putString("profile", n).apply(); pdir(); loadProfile(); updateSel()
    }

    private fun profileMenu() {
        val names = profiles()
        val items = arrayOf("➕ Profil vaovao", "🗑 Fafao: $profile") + names.map { (if (it == profile) "● " else "") + it }
        AlertDialog.Builder(this).setTitle("Profil: $profile").setItems(items) { _, i ->
            when (i) {
                0 -> { val et = EditText(this); et.hint = "anarana (ohatra: tanàna_1)"
                    AlertDialog.Builder(this).setTitle("Profil vaovao").setView(et).setPositiveButton("Mamorona") { _, _ ->
                        val n = et.text.toString().trim().replace(Regex("[^A-Za-z0-9_-]"), "_").take(30)
                        if (n.isNotEmpty()) switchTo(n) }.setNegativeButton("Hijanona", null).show() }
                1 -> AlertDialog.Builder(this).setTitle("Fafana ve ny $profile ?").setPositiveButton("Eny, fafao") { _, _ ->
                    handler.removeCallbacks(saver); pdir().deleteRecursively(); clearState()
                    profile = profiles().firstOrNull() ?: "profil_1"; prefs.edit().putString("profile", profile).apply(); pdir(); loadProfile(); updateSel() }
                    .setNegativeButton("Tsia", null).show()
                else -> switchTo(names[i - 2])
            }
        }.show()
    }

    // ---------- fototra ----------
    private fun push(fit: Boolean) {
        val p = allParts(true)
        gl.queueEvent { r.applyParts(p); if (fit) r.fit() }; gl.requestRender(); refresh(); dirty()
    }

    /** Reper + boîte ho an'ny voafidy (rotation/expand/move). */
    private fun gizmoUpdate() {
        val s = sel
        if (s is Obj3) { val b = s.bounds(); val ext = max(b[3] - b[0], max(b[4] - b[1], b[5] - b[2]))
            r.axes = floatArrayOf(s.x, s.y, s.z, s.yaw, max(2f, ext * 0.6f)); r.box = b }
        else if (s is Terrain) { r.axes = floatArrayOf(s.ox, hAt(s.ox, s.oz) + 0.5f, s.oz, 0f, 25f); r.box = null }
        else { r.axes = null; r.box = null }
        gl.requestRender()
    }

    private fun selName(): String = when (val s = sel) { is Obj3 -> s.name; is Terrain -> s.name; is RoadSel -> if (s.rough) "road lavaka" else "road"; else -> "-" }

    private fun refresh() {
        info.text = "Profil: $profile | Mode: ${modeNames[mode]} | ${toolNames[tool]} R=${radius.toInt()} | Sisiny: ${sideNames[side]} | teboka: ${pts.size}\n" +
            "terrain: ${terrains.size} | objet: ${objs.size} | road: ${roads.count { !it.rough }} tsotra + ${roads.count { it.rough }} lavaka (${roadParts.size} Part) | Safidy: ${selName()}" +
            (if (mode == 6) "\nRampe: ${genDirNames[genDir]} ${genRise.toInt()} m/100 m | Profil: ${Gen.names[genProfile]}" else "") + missing
    }

    private fun updateSel() {
        objs.forEach { o -> o.parts.forEach { it.selected = o === sel } }
        terrains.forEach { t -> t.part.selected = t === sel; t.cut?.forEach { it.selected = t === sel } }
        gizmoUpdate(); gl.requestRender(); refresh()
    }

    // ---------- Undo / Redo ----------
    private fun snap() = Snap(terrains.map { Triple(it, it.h.copyOf(), floatArrayOf(it.ox, it.oz)) }, objs.map { it to it.state() }, roads.toList(), gens.toList(), pads.map { it.clone() }, links.toList())
    private fun save() { undoS.add(snap()); if (undoS.size > 30) undoS.removeAt(0); redoS.clear() }
    private fun restore(s: Snap) {
        terrains.clear(); s.t.forEach { (t, hh, o) -> System.arraycopy(hh, 0, t.h, 0, hh.size); t.ox = o[0]; t.oz = o[1]; t.rebuildPos(); terrains.add(t) }
        objs.clear(); s.o.forEach { (ob, st) -> ob.restore(st); objs.add(ob) }
        roads.clear(); roads.addAll(s.roads); gens.clear(); gens.addAll(s.gens); pads.clear(); pads.addAll(s.pads); links.clear(); links.addAll(s.links); rebuildRoads()
        val ps = allParts(false); gl.queueEvent { ps.forEach { r.invalidate(it) } }
        resnapAll(); sel = null; updateSel(); push(false)
    }
    private fun doUndo() { if (undoS.isEmpty()) return toast("Tsy misy Undo"); redoS.add(snap()); restore(undoS.removeAt(undoS.lastIndex)) }
    private fun doRedo() { if (redoS.isEmpty()) return toast("Tsy misy Redo"); undoS.add(snap()); restore(redoS.removeAt(redoS.lastIndex)) }

    // ---------- Picking ----------
    private fun pick(x: Float, y: Float): FloatArray? {
        if (terrains.isEmpty()) return null; val (o, d) = r.ray(x, y) ?: return null
        var s = 0f
        repeat(3000) {
            val px = o[0] + d[0] * s; val py = o[1] + d[1] * s; val pz = o[2] + d[2] * s
            val t = terrains.firstOrNull { it.contains(px, pz) }
            if (t != null && py <= t.height(px, pz)) return floatArrayOf(px, py, pz)
            s += 1f
        }
        return null
    }

    private fun planeHit(x: Float, y: Float, py: Float): FloatArray? {
        val (o, d) = r.ray(x, y) ?: return null
        if (abs(d[1]) < 1e-6f) return null
        val t = (py - o[1]) / d[1]; if (t < 0) return null
        return floatArrayOf(o[0] + d[0] * t, o[2] + d[2] * t)
    }

    private fun aabb(o: FloatArray, d: FloatArray, b: FloatArray): Float? {
        var t0 = 0f; var t1 = 1e9f
        for (k in 0..2) {
            if (abs(d[k]) < 1e-9f) { if (o[k] < b[k] || o[k] > b[k + 3]) return null }
            else { var a = (b[k] - o[k]) / d[k]; var c = (b[k + 3] - o[k]) / d[k]; if (a > c) { val t = a; a = c; c = t }
                t0 = max(t0, a); t1 = min(t1, c); if (t0 > t1) return null }
        }
        return t0
    }

    private fun selectAt(x: Float, y: Float) {
        val (o, d) = r.ray(x, y) ?: return
        var bestT = 1e9f; var best: Any? = null
        for (ob in objs) { if (isTraffic(ob)) continue; val t = rayMesh(o, d, ob); if (t != null && t < bestT) { bestT = t; best = ob } }
        val h = pick(x, y)
        if (h != null) { val t = hypot(hypot(h[0] - o[0], h[1] - o[1]), h[2] - o[2]); if (t < bestT) { bestT = t; best = objs.firstOrNull { isTraffic(it) && nearTraffic(it, h[0], h[2]) } ?: rowsAll.firstOrNull { inRoad(it.first, h[0], h[2]) }?.let { RoadSel(it.second) } ?: terrains.firstOrNull { it.contains(h[0], h[2]) } } }
        sel = best; updateSel()
    }

    // ---------- Traffic / Objet / Poto + fil ----------
    private fun isTraffic(o: Obj3) = o.name.startsWith("traffic_group")

    private fun snapTraffic(o: Obj3) { for (p in o.parts) for (i in 0 until p.pos.size / 3) p.pos[i * 3 + 1] = (srcMH?.at(p.pos[i * 3], p.pos[i * 3 + 2])?.plus(0.15f)) ?: (hAt(p.pos[i * 3], p.pos[i * 3 + 2]) + Road.raise + 0.15f) }

    private fun nearTraffic(o: Obj3, x: Float, z: Float): Boolean {
        for (p in o.parts) { val cx = (p.pos[0] + p.pos[3] + p.pos[6] + p.pos[9]) / 4; val cz = (p.pos[2] + p.pos[5] + p.pos[8] + p.pos[11]) / 4
            if (hypot(x - cx, z - cz) < 1.5f) return true }
        return false
    }

    private fun refreshParts() { val p = allParts(true); gl.queueEvent { r.applyParts(p) }; gl.requestRender() }

    private fun postXf(o: Obj3) { if (o === roadSrc) refreshRoadSrc(); if (isTraffic(o)) snapTraffic(o); if (o.cat == 4) { rebuildWires(); refreshParts() } }

    /** Manaraka ny terrain foana: objet (vegetation), poto, traffic, fil. */
    private fun resnapAll() {
        for (o in objs) { if (isTraffic(o)) snapTraffic(o) else if (o.snap) { o.y = hAt(o.x, o.z); o.apply() }; o.parts.forEach { inv(it) } }
        rebuildWires()
    }

    private fun resnapTraffic() { val t = objs.firstOrNull { isTraffic(it) } ?: return toast("Generate traffic aloha"); save(); regenTraffic(latOf(t)) }

    private var trafRef = floatArrayOf(1f, 0f)
    private fun latOf(o: Obj3) = o.name.substringAfter('@', "0").toFloatOrNull() ?: 0f

    /** Havanana (araka ny lalan'ny road) akaiky indrindra amin'ny teboka (x,z). */
    private fun nearestRight(x: Float, z: Float): FloatArray {
        var bd = 1e18f; var best = floatArrayOf(1f, 0f)
        for ((rs, _) in rowsAll) for (r in rs) {
            val d = (r.cx - x) * (r.cx - x) + (r.cz - z) * (r.cz - z)
            if (d < bd) { bd = d; val rx = r.rx - r.lx; val rz = r.rz - r.lz; val l = hypot(rx, rz).let { if (it < 1e-6f) 1f else it }; best = floatArrayOf(rx / l, rz / l) }
        }
        return best
    }

    /** Traffic: carré 1x1 m (quad tokana) manaraka ny road, lane iray; lat = fiovana amin'ny sisiny (+ havanana araka ny lalana, tsy mivadika ny elanelana). Objet iray, material "traffic". */
    private fun regenTraffic(lat: Float) {
        val hf: (Float, Float) -> Float = { x, z -> hAt(x, z) }; val c = intArrayOf(1); val ps = ArrayList<Part>()
        roads.forEachIndexed { i, rd -> ps.addAll(Road.traffic(rd.pts, hf, lastPres.getOrNull(i), lastPosts.getOrNull(i), c, lat)) }
        for (pd in pads) {   // carrefour: lalan'ny traffic mamaky ny afovoany (isaky ny tendrony roa, sens iray)
            val ends = ArrayList<FloatArray>()
            for (rd in roads) for (e in listOf(rd.pts.first(), rd.pts.last())) if (abs(hypot(e[0] - pd[0], e[1] - pd[1]) - Road.padR) < 1f) ends.add(e)
            for (a in 0 until ends.size) for (b in a + 1 until ends.size) {
                val A = ends[a]; val B = ends[b]
                val ctrl = listOf(A, floatArrayOf(pd[0] + (A[0] - pd[0]) * 0.35f, pd[1] + (A[1] - pd[1]) * 0.35f), floatArrayOf(pd[0] + (B[0] - pd[0]) * 0.35f, pd[1] + (B[1] - pd[1]) * 0.35f), B)
                ps.addAll(Road.traffic(ctrl, hf, null, null, c, lat))
            }
        }
        val src = roadSrc
        if (src != null) {   // lalana avy amin'ny mesh road (Blender): traffic eo ambonin'ny mesh
            val hs: (Float, Float) -> Float = { x, z -> (srcMH?.at(x, z) ?: hAt(x, z)) - Road.raise }
            for (path in srcPaths) ps.addAll(Road.traffic(path, hs, null, null, c, lat))
        }
        if (ps.isEmpty()) return
        val ob = Obj3("traffic_group@$lat", ps, false); ob.recenter(); snapTraffic(ob)
        val old = objs.indexOfFirst { isTraffic(it) }; val wasSel = old < 0 || sel === objs[old]
        if (old >= 0) objs[old] = ob else objs.add(ob)
        if (wasSel) sel = ob
        updateSel(); refreshParts(); dirty()
    }

    private fun generateTraffic() {
        if (roads.isEmpty() && roadSrc == null) return toast("Manaova road na safidio ny mesh road (Select > Road=Ity)")
        if (roadSrc != null) refreshRoadSrc()
        save(); regenTraffic(0f)
    }

    private fun laneShift(d: Float) {
        val t = objs.firstOrNull { isTraffic(it) } ?: return toast("Generate traffic aloha")
        save(); regenTraffic((latOf(t) + d).coerceIn(-6f, 6f))
    }

    /** Generate objet: clone an'ny objet nampidirina (voafidy na ny farany) isaky ny teboka, mipetaka sy manaraka ny terrain. */
    private fun generateObjects() {
        if (pts.isEmpty()) return toast("Apetaho aloha ny teboka (mode Gen)")
        val tpl = (sel as? Obj3)?.let { it.src ?: it }?.takeIf { it.cat == -1 && !isTraffic(it) }
            ?: objs.lastOrNull { it.cat == -1 && it.src == null && !isTraffic(it) } ?: return toast("Import OBJ aloha (na safidio ny objet amin'ny Select)")
        save(); val rnd = java.util.Random(); var last: Obj3? = null
        for (p in pts) {
            val ob = tpl.cloneAs("${tpl.name}_v${oid++}")
            ob.x = p[0]; ob.z = p[1]; ob.y = hAt(p[0], p[1]); ob.yaw = rnd.nextFloat() * 6.2831855f; ob.scale = tpl.scale * (0.85f + rnd.nextFloat() * 0.3f)
            ob.apply(); objs.add(ob); last = ob
        }
        pts.clear(); markers = emptyList(); sel = last; updateSel(); push(false)
    }

    /** Generate poto: poto isaky ny teboka; ny poto manaraka dia mifandray ho azy amin'ny teo aloha amin'ny fil roa. */
    private fun generatePoles() {
        if (pts.isEmpty()) return toast("Apetaho aloha ny teboka (mode Gen)")
        save()
        val prev = objs.lastOrNull { it.cat == 4 }
        val created = ArrayList<Obj3>()
        for (p in pts) { val ob = Catalog.make(4, oid++); ob.x = p[0]; ob.z = p[1]; ob.y = hAt(p[0], p[1]); objs.add(ob); created.add(ob) }
        val chain = ArrayList<Obj3>()
        if (prev != null && hypot(prev.x - created[0].x, prev.z - created[0].z) < 120f) chain.add(prev)
        chain.addAll(created)
        for (k in 0 until chain.size - 1) links.add(chain[k] to chain[k + 1])
        if (chain.size >= 2) for (k in chain.indices) {
            val a = if (k + 1 < chain.size) chain[k] else chain[k - 1]; val b = if (k + 1 < chain.size) chain[k + 1] else chain[k]
            if (k == 0 && chain[0] === prev && links.any { it.second === prev }) continue
            chain[k].yaw = atan2(b.x - a.x, b.z - a.z)
        }
        created.forEach { it.apply() }; prev?.apply()
        pts.clear(); markers = emptyList(); rebuildWires(); sel = created.last(); updateSel(); push(false)
    }

    private fun tips(o: Obj3): List<FloatArray> {
        val c = cos(o.yaw); val s = sin(o.yaw); val ty = 7.6f * o.scale
        return listOf(-0.9f, 0.9f).map { bx -> val x = bx * o.scale; floatArrayOf(o.x + x * c, o.y + ty, o.z - x * s) }
    }

    private fun rebuildWires() {
        val out = ArrayList<Part>(); var n = 1
        for ((a, b) in links) {
            if (a !in objs || b !in objs) continue
            val ta = tips(a); val tb = tips(b)
            out.add(wirePart("fil_%03d".format(n++), listOf(ta[0] to tb[0], ta[1] to tb[1])))
        }
        wireParts = out
    }

    /** Fil: tube 4 sisiny madinika miaraka amin'ny fihenan'ny afovoany (sag). */
    private fun wirePart(name: String, ws: List<Pair<FloatArray, FloatArray>>): Part {
        val pos = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>(); val seg = 12; val w = 0.04f
        for ((p0, p1) in ws) {
            val len = sqrt((p1[0] - p0[0]) * (p1[0] - p0[0]) + (p1[1] - p0[1]) * (p1[1] - p0[1]) + (p1[2] - p0[2]) * (p1[2] - p0[2])); val sag = 0.025f * len
            val base = pos.size / 3
            val pt = Array(seg + 1) { i -> val t = i / seg.toFloat(); floatArrayOf(p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t - 4 * sag * t * (1 - t), p0[2] + (p1[2] - p0[2]) * t) }
            for (i in 0..seg) {
                val a = pt[max(i - 1, 0)]; val b = pt[min(i + 1, seg)]
                var tx = b[0] - a[0]; var tyy = b[1] - a[1]; var tz = b[2] - a[2]
                val tl = sqrt(tx * tx + tyy * tyy + tz * tz).let { if (it < 1e-6f) 1f else it }; tx /= tl; tyy /= tl; tz /= tl
                var sx = -tz; var sz = tx; val sl = hypot(sx, sz).let { if (it < 1e-6f) 1f else it }; sx /= sl; sz /= sl
                val ux = -sz * tyy; val uy = sz * tx - sx * tz; val uz = sx * tyy
                for (cn in arrayOf(floatArrayOf(1f, 1f), floatArrayOf(-1f, 1f), floatArrayOf(-1f, -1f), floatArrayOf(1f, -1f))) {
                    pos.add(pt[i][0] + (sx * cn[0] + ux * cn[1]) * w); pos.add(pt[i][1] + uy * cn[1] * w); pos.add(pt[i][2] + (sz * cn[0] + uz * cn[1]) * w)
                    uv.add(cn[0] * 0.5f + 0.5f); uv.add(i / seg.toFloat())
                }
            }
            for (i in 0 until seg) for (e in 0..3) {
                val a0 = base + i * 4 + e; val a1 = base + i * 4 + (e + 1) % 4; val b0 = base + (i + 1) * 4 + e; val b1 = base + (i + 1) * 4 + (e + 1) % 4
                idx.addAll(listOf(a0, a1, b1, a0, b1, b0))
            }
        }
        return Part(name, wireMat, pos.toFloatArray(), uv.toFloatArray(), idx.toIntArray())
    }

    // ---------- Mesh avy amin'ny Blender: terrain / road ----------
    private fun rayMesh(o: FloatArray, d: FloatArray, ob: Obj3): Float? {
        aabb(o, d, ob.bounds()) ?: return null
        var best = 1e18f; var hit = false
        for (p in ob.parts) {
            val ix = p.idx; val ps = p.pos; var k = 0
            while (k + 2 < ix.size) {
                val a = ix[k] * 3; val b = ix[k + 1] * 3; val c = ix[k + 2] * 3; k += 3
                val e1x = ps[b] - ps[a]; val e1y = ps[b + 1] - ps[a + 1]; val e1z = ps[b + 2] - ps[a + 2]
                val e2x = ps[c] - ps[a]; val e2y = ps[c + 1] - ps[a + 1]; val e2z = ps[c + 2] - ps[a + 2]
                val px = d[1] * e2z - d[2] * e2y; val py = d[2] * e2x - d[0] * e2z; val pz = d[0] * e2y - d[1] * e2x
                val det = e1x * px + e1y * py + e1z * pz; if (abs(det) < 1e-9f) continue
                val iv = 1f / det; val tx = o[0] - ps[a]; val ty = o[1] - ps[a + 1]; val tz = o[2] - ps[a + 2]
                val u = (tx * px + ty * py + tz * pz) * iv; if (u < 0f || u > 1f) continue
                val qx = ty * e1z - tz * e1y; val qy = tz * e1x - tx * e1z; val qz = tx * e1y - ty * e1x
                val v = (d[0] * qx + d[1] * qy + d[2] * qz) * iv; if (v < 0f || u + v > 1f) continue
                val t = (e2x * qx + e2y * qy + e2z * qz) * iv; if (t > 0f && t < best) { best = t; hit = true }
            }
        }
        return if (hit) best else null
    }

    private fun refreshRoadSrc() {
        val s = roadSrc
        if (s == null) { srcMH = null; srcPaths = emptyList(); return }
        srcMH = MeshHeight(s.parts); srcPaths = RoadPath.extract(s.parts)
    }

    /** Road=Ity: ny mesh voafidy (material road avy amin'ny Blender) no loharanon'ny lalan'ny traffic. */
    private fun setRoadSrc() {
        val ob = sel as? Obj3 ?: return toast("Safidio aloha ny mesh road (mode Select)")
        if (ob.cat != -1 || isTraffic(ob)) return toast("Mesh nampidirina ihany no azo ho road")
        roadSrc = ob; refreshRoadSrc(); dirty()
        toast("Mesh road: lalana ${srcPaths.size} hita (${srcPaths.sumOf { it.size }} teboka). Tsindrio Generate traffic.")
    }

    /** Terrain=Ity: ny mesh voafidy dia lasa terrain azo sculpt/Gen (grid 65x65 isaky ny 200 m, haavony avy amin'ny mesh). */
    private fun makeTerrainFromSel() {
        val ob = sel as? Obj3 ?: return toast("Safidio aloha ny mesh terrain (mode Select)")
        if (ob.cat != -1 || isTraffic(ob) || ob === roadSrc) return toast("Mesh nampidirina ihany (tsy road) no azo ho terrain")
        val b = ob.bounds(); val mh = MeshHeight(ob.parts)
        val tx = ceil((b[3] - b[0]) / 200f).toInt().coerceIn(1, 8); val tz = ceil((b[5] - b[2]) / 200f).toInt().coerceIn(1, 8)
        save(); val m0 = ob.parts.first().mat; var made = 0
        for (iz in 0 until tz) for (ix in 0 until tx) {
            val cx = b[0] + 100f + 200f * ix; val cz = b[2] + 100f + 200f * iz
            if (terrains.any { abs(it.ox - cx) < 1f && abs(it.oz - cz) < 1f }) continue
            val t = Terrain("terrain_${tid++}", ox = cx, oz = cz); val n = t.n
            val hv = FloatArray(n * n) { Float.NaN }
            for (j in 0 until n) for (i in 0 until n) mh.at(t.ox + t.cc(i), t.oz + t.cc(j))?.let { hv[j * n + i] = it }
            if (hv.all { it.isNaN() }) continue
            repeat(30) {   // fenoy ny banga amin'ny alalan'ny mpifanolo
                val cp = hv.copyOf(); var left = 0
                for (j in 0 until n) for (i in 0 until n) { val k = j * n + i
                    if (cp[k].isNaN()) { var sm = 0f; var c = 0
                        for ((di, dj) in listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)) { val ii = i + di; val jj = j + dj; if (ii in 0 until n && jj in 0 until n && !cp[jj * n + ii].isNaN()) { sm += cp[jj * n + ii]; c++ } }
                        if (c > 0) hv[k] = sm / c else left++ } }
                if (left == 0) return@repeat
            }
            for (k in hv.indices) t.setH(k, if (hv[k].isNaN()) b[1] else hv[k])
            t.part.mat.kd = m0.kd.clone(); t.part.mat.tex = m0.tex; t.part.mat.bmp = m0.bmp
            terrains.add(t); made++
        }
        if (made == 0) return toast("Tsy nahazo haavony avy amin'ny mesh")
        objs.remove(ob); syncSeams(); sel = terrains.last(); updateSel()
        if (roads.isNotEmpty()) rebuildRoads()
        resnapAll(); push(true); toast("Terrain ${made}: azo sculpt/Gen izao")
    }

    // ---------- Sculpt ----------
    private fun syncSeams() { for (i in terrains.indices) for (j in i + 1 until terrains.size) terrains[i].sync(terrains[j], false) }

    /** Dab isaky ny R*0.3 (tsy isaky ny hetsika), ka tsy midina foana. */
    private fun dab(x: Float, y: Float, force: Boolean) {
        val h = pick(x, y) ?: return
        val ld = lastDab
        if (!force && ld != null && hypot(h[0] - ld[0], h[2] - ld[1]) < radius * 0.3f) return
        lastDab = floatArrayOf(h[0], h[2])
        for (t in terrains) t.sculpt(h[0], h[2], radius, 0.1f + radius * 0.02f, tool)
        syncSeams(); terrains.forEach { t -> t.refreshCutHeights(); inv(t.part); t.cut?.forEach { inv(it) } }; dirty()
    }

    // ---------- Terrain ----------
    private fun addTerrain() {
        val b = (sel as? Terrain) ?: terrains.lastOrNull()
        val dx = if (side == 0) 1f else if (side == 1) -1f else 0f; val dz = if (side == 2) -1f else if (side == 3) 1f else 0f
        val nx = if (b == null) 0f else b.ox + dx * b.size; val nz = if (b == null) 0f else b.oz + dz * b.size
        if (terrains.any { abs(it.ox - nx) < 1f && abs(it.oz - nz) < 1f }) return toast("Efa misy terrain eo")
        save()
        val t = Terrain("terrain_${tid++}", ox = nx, oz = nz)
        if (b != null) t.sync(b, true)
        for (o in terrains) if (o !== b) t.sync(o, false)
        terrains.add(t); sel = t; updateSel(); push(terrains.size == 1)
        if (roads.isNotEmpty()) { rebuildRoads(); push(false) }
    }

    // ---------- Move ----------
    private fun beginGrab(x: Float, y: Float) {
        val s = sel ?: return
        val py = if (s is Obj3) s.y else 0f
        val h = planeHit(x, y, py) ?: return
        save()
        if (s is Obj3 && isTraffic(s)) { trafRef = nearestRight(h[0], h[1]); grab = floatArrayOf(h[0], h[1], latOf(s), 0f); return }
        grab = if (s is Obj3) floatArrayOf(h[0], h[1], s.x, s.z) else { val t = s as Terrain; floatArrayOf(h[0], h[1], t.ox, t.oz) }
    }

    private fun dragTo(x: Float, y: Float) {
        val s = sel ?: return
        val h = planeHit(x, y, if (s is Obj3) s.y else 0f) ?: return
        dirty()
        if (s is Obj3 && isTraffic(s)) { val dl = (h[0] - grab[0]) * trafRef[0] + (h[1] - grab[1]) * trafRef[1]; regenTraffic((grab[2] + dl).coerceIn(-6f, 6f)); return }
        var nx = grab[2] + h[0] - grab[0]; var nz = grab[3] + h[1] - grab[1]
        if (s is Obj3) { s.x = nx; s.z = nz; if (s.snap) s.y = hAt(nx, nz); s.apply(); postXf(s); s.parts.forEach { inv(it) }; gizmoUpdate() }
        else if (s is Terrain) {
            for (o in terrains) if (o !== s) for (a in floatArrayOf(-s.size, s.size)) {
                if (abs(nx - (o.ox + a)) < 6f && abs(nz - o.oz) < 6f) { nx = o.ox + a; nz = o.oz }
                else if (abs(nz - (o.oz + a)) < 6f && abs(nx - o.ox) < 6f) { nz = o.oz + a; nx = o.ox }
            }
            s.ox = nx; s.oz = nz; s.rebuildPos(); inv(s.part); gizmoUpdate()
        }
    }

    private fun endGrab() { if (sel is Terrain) { syncSeams(); terrains.forEach { inv(it.part) }; resnapAll(); if (roads.isNotEmpty()) rebuildRoads(); push(false) } }

    // ---------- Objet ----------
    private fun addObject() {
        AlertDialog.Builder(this).setItems(Catalog.names) { _, i ->
            save()
            val ob = Catalog.make(i, oid++)
            val c = pick(gl.width / 2f, gl.height / 2f)
            ob.x = c?.get(0) ?: 0f; ob.z = c?.get(2) ?: 0f; ob.y = hAt(ob.x, ob.z); ob.apply()
            objs.add(ob); sel = ob; updateSel(); push(false)
        }.show()
    }

    private fun xf(f: (Obj3) -> Unit) {
        val o = sel as? Obj3 ?: return toast("Safidio aloha ny objet (Mode: Select)")
        if (isTraffic(o)) return toast("Ny traffic dia mifindra amin'ny sisiny: Move (misintona) na Lane- / Lane+"); save(); f(o); if (o.snap) o.y = hAt(o.x, o.z); o.apply(); postXf(o); o.parts.forEach { inv(it) }; dirty(); gizmoUpdate()
    }

    private fun delSel() {
        val s = sel ?: return toast("Safidio aloha (Mode: Select)")
        save()
        if (s is Obj3) { objs.remove(s); if (s === roadSrc) { roadSrc = null; refreshRoadSrc() }; links.removeAll { it.first === s || it.second === s }; rebuildWires() } else if (s is Terrain) terrains.remove(s)
        sel = null; updateSel(); push(false)
    }

    // ---------- Texture ----------
    private fun pickTexture() {
        if (sel == null) return toast("Safidio aloha ny objet/terrain (Mode: Select)")
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, 3)
    }

    private fun applyTexture(u: Uri) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(u)) ?: throw Exception("sary tsy mety")
                val nm = (DocumentFile.fromSingleUri(this, u)?.name ?: "tex").substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_") + ".png"
                runOnUiThread {
                    File(File(pdir(), "tex"), nm).delete()
                    val mats = when (val s = sel) { is Obj3 -> s.parts.map { it.mat }; is Terrain -> listOf(s.part.mat); is RoadSel -> listOf(if (s.rough) lavaMat else roadMat); else -> emptyList() }
                    mats.distinct().forEach { m -> m.bmp = bmp; m.tex = nm; m.kd = floatArrayOf(1f, 1f, 1f); gl.queueEvent { r.dropTex(m) } }
                    gl.requestRender(); dirty(); toast("Texture napetraka: $nm")
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana texture: ${e.message}") } }
        }.start()
    }

    // ---------- Road ----------
    private fun addPoint(x: Float, y: Float) {
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha"); val h = pick(x, y) ?: return
        pts.add(floatArrayOf(h[0], h[2])); ptsRough = mode == 3
        markers = pts.mapIndexed { i, p -> val yy = hAt(p[0], p[1]) + 0.6f; val s = 1f
            Part("m$i", mk, floatArrayOf(p[0] - s, yy, p[1] - s, p[0] + s, yy, p[1] - s, p[0] + s, yy, p[1] + s, p[0] - s, yy, p[1] + s), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)) }
        push(false)
    }

    private val gens = ArrayList<GenDef>(); private var genProfile = 0; private var genDir = 0; private var genRise = 3f
    private val genDirNames = arrayOf("Mitovy", "Fiakarana", "Fidinana")
    private var genKind = 0; private val genKindNames = arrayOf("Terrain", "Carrefour", "Rond-point", "Objet", "Poto")
    private val pads = ArrayList<FloatArray>()
    private var roadSrc: Obj3? = null; private var srcMH: MeshHeight? = null; private var srcPaths: List<List<FloatArray>> = emptyList()
    private val links = ArrayList<Pair<Obj3, Obj3>>(); private var wireParts = listOf<Part>()
    private val wireMat = Mat("fil").apply { kd = floatArrayOf(0.08f, 0.08f, 0.08f) }
    private var lastPres: Array<FloatArray?> = arrayOfNulls(0); private var lastPosts: Array<FloatArray?> = arrayOfNulls(0)

    private fun segInter(ax: Float, az: Float, bx: Float, bz: Float, cx: Float, cz: Float, dx: Float, dz: Float): FloatArray? {
        val r1 = bx - ax; val r2 = bz - az; val s1 = dx - cx; val s2 = dz - cz
        val den = r1 * s2 - r2 * s1; if (abs(den) < 1e-6f) return null
        val t = ((cx - ax) * s2 - (cz - az) * s1) / den; val u = ((cx - ax) * r2 - (cz - az) * r1) / den
        return if (t in 0f..1f && u in 0f..1f) floatArrayOf(ax + r1 * t, az + r2 * t) else null
    }

    /** Tendron'ny road iray ve miankina eo afovoan'ny road hafa (sampana)? Raha eny dia tsy ampiarahina (merge). */
    private fun isJunctionEnd(ri: Int, atEnd: Boolean): Boolean {
        val rd = roads[ri]; val p = if (atEnd) rd.pts.last() else rd.pts.first()
        for ((k, pr) in rowsAll.withIndex()) {
            if (k == ri) continue; val rs = pr.first; if (rs.size < 6) continue
            if (distToPoly(rs, p[0], p[1]) < 0.6f && hypot(p[0] - rs.first().cx, p[1] - rs.first().cz) > 3f && hypot(p[0] - rs.last().cx, p[1] - rs.last().cz) > 3f) return true
        }
        return false
    }

    /** Raha mamaky road hafa ny road vaovao (croisement) dia tapahina eo amin'ny fampitahana: lasa sampana roa (T) misy fillet. */
    private fun splitCrossings(np: List<FloatArray>): List<List<FloatArray>> {
        if (rowsAll.isEmpty()) return listOf(np)
        val hf: (Float, Float) -> Float = { x, z -> hAt(x, z) }
        val rs = Road.rows(np, hf, 1f, null, null); if (rs.size < 8) return listOf(np)
        val cuts = ArrayList<Pair<Int, FloatArray>>()
        for ((ex, _) in rowsAll) {
            if (ex.size < 6) continue
            for (i in 0 until rs.size - 1) for (j in 0 until ex.size - 1) {
                val p = segInter(rs[i].cx, rs[i].cz, rs[i + 1].cx, rs[i + 1].cz, ex[j].cx, ex[j].cz, ex[j + 1].cx, ex[j + 1].cz) ?: continue
                if (hypot(p[0] - ex.first().cx, p[1] - ex.first().cz) < 3f || hypot(p[0] - ex.last().cx, p[1] - ex.last().cz) < 3f) continue
                if (hypot(p[0] - rs.first().cx, p[1] - rs.first().cz) < 3f || hypot(p[0] - rs.last().cx, p[1] - rs.last().cz) < 3f) continue
                if (cuts.none { abs(it.first - i) < 6 }) cuts.add(i to p)
            }
        }
        if (cuts.isEmpty()) return listOf(np)
        cuts.sortBy { it.first }
        val ci = np.map { q -> var bi = 0; var bd = 1e18f
            for ((k, r0) in rs.withIndex()) { val d = (r0.cx - q[0]) * (r0.cx - q[0]) + (r0.cz - q[1]) * (r0.cz - q[1]); if (d < bd) { bd = d; bi = k } }; bi }
        fun partOf(ra: Int, pa: FloatArray?, rb: Int, pb: FloatArray?): List<FloatArray> {
            val l = ArrayList<FloatArray>(); if (pa != null) l.add(pa)
            for (k in np.indices) {
                val q = np[k]; val c = ci[k]
                val farA = pa == null || hypot(q[0] - pa[0], q[1] - pa[1]) > 5f; val farB = pb == null || hypot(q[0] - pb[0], q[1] - pb[1]) > 5f
                if ((c > ra && c < rb && farA && farB) || (k == 0 && pa == null) || (k == np.lastIndex && pb == null)) l.add(q)
            }
            if (pb != null) l.add(pb); return l
        }
        val out = ArrayList<List<FloatArray>>(); var ra = -1; var pa: FloatArray? = null
        for ((rb, pb) in cuts) { out.add(partOf(ra, pa, rb, pb)); ra = rb; pa = pb }
        out.add(partOf(ra, pa, Int.MAX_VALUE, null))
        return out.filter { it.size >= 2 }
    }

    private fun distToPoly(rs: List<Row>, x: Float, z: Float): Float {
        var best = 1e9f
        for (q in 0 until rs.size - 1) { val a = rs[q]; val b = rs[q + 1]; val dx = b.cx - a.cx; val dz = b.cz - a.cz; val l2 = dx * dx + dz * dz
            val t = if (l2 < 1e-9f) 0f else (((x - a.cx) * dx + (z - a.cz) * dz) / l2).coerceIn(0f, 1f)
            best = min(best, hypot(x - (a.cx + dx * t), z - (a.cz + dz * t))) }
        return best
    }

    /** Sampana: ny tendron'ny road vaovao dia mipetaka amin'ny afovoan'ny road efa misy (<8 m, tsy akaikin'ny tendrony). */
    private fun centerSnap(np: MutableList<FloatArray>, k: Int) {
        val p = np[k]; var bd = 8f; var bx = 0f; var bz = 0f; var found = false
        for ((rs, _) in rowsAll) {
            if (rs.size < 6) continue
            for (j in 0 until rs.size - 1) { val a = rs[j]; val b = rs[j + 1]; val dx = b.cx - a.cx; val dz = b.cz - a.cz; val l2 = dx * dx + dz * dz
                if (l2 < 1e-9f) continue
                val t = (((p[0] - a.cx) * dx + (p[1] - a.cz) * dz) / l2).coerceIn(0f, 1f); val qx = a.cx + dx * t; val qz = a.cz + dz * t
                val d = hypot(p[0] - qx, p[1] - qz)
                if (d < bd && min(hypot(qx - rs.first().cx, qz - rs.first().cz), hypot(qx - rs.last().cx, qz - rs.last().cz)) > 4f) { bd = d; bx = qx; bz = qz; found = true } }
        }
        if (found) np[k] = floatArrayOf(bx, bz)
    }

    /** Sampana: ny tendrony dia mifarana mifanaraka amin'ny sisin'ny lalana lehibe (sisiny = tsipika), ary asiana fillet (arc boribory) eo amin'ny zoro roa.
     *  E = teboka eo amin'ny sisiny, n = havatra mankany ivelany (mankany amin'ny sampana). Miverina Part ho an'ny fillet. */
    private fun trimFillet(rs: MutableList<Row>, atStart: Boolean, E: FloatArray, n: FloatArray, hf: (Float, Float) -> Float, rf: Float, id: Int): Part? {
        if (rs.size < 4) return null
        val list = if (atStart) rs.reversed().toMutableList() else rs
        fun dep(x: Float, z: Float) = (x - E[0]) * n[0] + (z - E[1]) * n[1]
        var removed = false
        while (list.size > 3 && dep(list.last().cx, list.last().cz) < 0.6f) { list.removeAt(list.lastIndex); removed = true }
        if (!removed) return null
        val k = list.last(); val pv = list[list.size - 2]
        fun unit(x: Float, z: Float): FloatArray { val l = hypot(x, z).let { if (it < 1e-6f) 1f else it }; return floatArrayOf(x / l, z / l) }
        val dL = unit(k.lx - pv.lx, k.lz - pv.lz); val dR = unit(k.rx - pv.rx, k.rz - pv.rz)
        fun hit(px: Float, pz: Float, d: FloatArray, depth: Float): FloatArray? {
            val den = d[0] * n[0] + d[1] * n[1]; if (abs(den) < 1e-3f) return null
            val sv = (depth - dep(px, pz)) / den; return floatArrayOf(px + d[0] * sv, pz + d[1] * sv)
        }
        val eL = hit(k.lx, k.lz, dL, -0.3f) ?: return null; val eR = hit(k.rx, k.rz, dR, -0.3f) ?: return null
        val cx = (eL[0] + eR[0]) / 2; val cz = (eL[1] + eR[1]) / 2
        list.add(Row(eL[0], eL[1], eR[0], eR[1], cx, cz, k.s + hypot(cx - k.cx, cz - k.cz)))   // andalana farany mifanaraka amin'ny sisiny
        if (atStart) { rs.clear(); rs.addAll(list.reversed()) }
        val m = floatArrayOf(-n[1], n[0]); val lv = unit(k.lx - k.rx, k.lz - k.rz)
        val pos = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>()
        fun vtx(x: Float, z: Float, low: Boolean): Int { pos.add(x); pos.add(hf(x, z) + (if (low) -0.12f else Road.raise)); pos.add(z); uv.add(x / Road.width); uv.add(z / Road.width); return pos.size / 3 - 1 }
        for (side in 0..1) {
            val u = if (side == 0) dL else dR
            val X = hit(if (side == 0) k.lx else k.rx, if (side == 0) k.lz else k.rz, u, 0f) ?: continue
            val sv = if (side == 0) lv else floatArrayOf(-lv[0], -lv[1])
            val sg = if (m[0] * sv[0] + m[1] * sv[1] >= 0) 1f else -1f; val d2 = floatArrayOf(m[0] * sg, m[1] * sg)
            val th = acos((-(u[0] * d2[0] + u[1] * d2[1])).coerceIn(-1f, 1f)); if (th < 0.6f || th > 2.7f) continue
            val tt = min(rf / tan(th / 2), 8f); val rad = tt * tan(th / 2)
            val bx = -u[0] + d2[0]; val bz = -u[1] + d2[1]; val bl = hypot(bx, bz).let { if (it < 1e-6f) 1f else it }
            val ox = X[0] + bx / bl * (rad / sin(th / 2)); val oz = X[1] + bz / bl * (rad / sin(th / 2))
            val t1x = X[0] - u[0] * tt; val t1z = X[1] - u[1] * tt; val t2x = X[0] + d2[0] * tt; val t2z = X[1] + d2[1] * tt
            val a1 = atan2(t1z - oz, t1x - ox); var da = atan2(t2z - oz, t2x - ox) - a1
            while (da > 3.1415927f) da -= 6.2831855f
            while (da < -3.1415927f) da += 6.2831855f
            val steps = 8; val xi = vtx(X[0], X[1], false); val arc = IntArray(steps + 1); val sh = IntArray(steps + 1)
            for (q in 0..steps) {
                val ang = a1 + da * q / steps; val ax = ox + cos(ang) * rad; val az = oz + sin(ang) * rad
                arc[q] = vtx(ax, az, false); sh[q] = vtx(ax + (ox - ax) / rad * Road.shoulder, az + (oz - az) / rad * Road.shoulder, true)
            }
            for (q in 0 until steps) { idx.addAll(listOf(xi, arc[q], arc[q + 1])); idx.addAll(listOf(arc[q], sh[q], sh[q + 1], arc[q], sh[q + 1], arc[q + 1])) }
        }
        if (idx.isEmpty()) return null
        return Part("fillet_%02d".format(id), roadMat, pos.toFloatArray(), uv.toFloatArray(), idx.toIntArray()).also { it.smooth = true }
    }

    /** Andalana eo amin'ny fihaonana: toerana sy fironana mitovy ho an'ny road roa (tsy misy banga na zoro). */
    private fun joinRow(o: Row, cx: Float, cz: Float, rc: FloatArray): Row {
        var rx = o.rx - o.lx; var rz = o.rz - o.lz; val l = hypot(rx, rz).let { if (it < 1e-6f) 1f else it }; rx /= l; rz /= l
        val sg = if (rx * rc[0] + rz * rc[1] >= 0) 1f else -1f; val vx = rc[0] * sg; val vz = rc[1] * sg; val h = Road.width / 2
        return Row(cx - vx * h, cz - vz * h, cx + vx * h, cz + vz * h, cx, cz, o.s)
    }

    /** Road = mesh vaovao ambony terrain (trapeze), tsotra carré 2 m, lavaka carré 1 m. Mitambatra tsara eo amin'ny fihaonana. */
    private fun rebuildRoads() {
        val c = intArrayOf(1); val hf: (Float, Float) -> Float = { x, z -> hAt(x, z) }
        val n = roads.size
        val pres = arrayOfNulls<FloatArray>(n); val posts = arrayOfNulls<FloatArray>(n)
        val rows0 = roads.map { Road.rows(it.pts, hf, 2f, null, null) }
        fun onMain(i: Int, p: FloatArray): Boolean {
            for (k in 0 until n) { if (k == i) continue; val rk = rows0[k]; if (rk.size < 6) continue
                if (distToPoly(rk, p[0], p[1]) < 0.6f && hypot(p[0] - rk.first().cx, p[1] - rk.first().cz) > 3f && hypot(p[0] - rk.last().cx, p[1] - rk.last().cz) > 3f) return true }
            return false
        }
        roads.forEachIndexed { i, rd ->
            val f = rd.pts.first(); val l = rd.pts.last()
            roads.forEachIndexed { j, o -> if (j != i && o.pts.size >= 2) {
                if (hypot(o.pts.last()[0] - f[0], o.pts.last()[1] - f[1]) < 0.5f && !onMain(i, f)) pres[i] = o.pts[o.pts.size - 2]
                if (hypot(o.pts.first()[0] - l[0], o.pts.first()[1] - l[1]) < 0.5f && !onMain(i, l)) posts[i] = o.pts[1]
            } }
        }
        roads.forEachIndexed { i, rd -> val p = rd.pts   // peratra (rond-point): mifatotra ny tangent
            if (p.size >= 4 && hypot(p.first()[0] - p.last()[0], p.first()[1] - p.last()[1]) < 0.5f) { pres[i] = p[p.size - 2]; posts[i] = p[1] } }
        val rws = roads.mapIndexed { i, rd -> Road.rows(rd.pts, hf, if (rd.rough) 1f else 2f, pres[i], posts[i]).toMutableList() }
        for (a in 0 until n) for (b in a until n) for (ea in booleanArrayOf(false, true)) for (eb in booleanArrayOf(false, true)) {
            if (a == b && !(!ea && eb)) continue
            val pa = if (ea) roads[a].pts.last() else roads[a].pts.first(); val pb = if (eb) roads[b].pts.last() else roads[b].pts.first()
            if (hypot(pa[0] - pb[0], pa[1] - pb[1]) > 0.5f) continue
            val ra = rws[a]; val rb = rws[b]; if (ra.size < 2 || rb.size < 2) continue
            val ia = if (ea) ra.lastIndex else 0; val ib = if (eb) rb.lastIndex else 0
            val oa = if (ea) ra[ia - 1] else ra[1]; val ob = if (eb) rb[ib - 1] else rb[1]
            val ca = ra[ia]; val cb = rb[ib]
            var dx = (ob.cx - cb.cx) - (oa.cx - ca.cx); var dz = (ob.cz - cb.cz) - (oa.cz - ca.cz)
            val l = hypot(dx, dz); if (l < 1e-4f) continue
            dx /= l; dz /= l
            val rc = floatArrayOf(-dz, dx); val mx = (ca.cx + cb.cx) / 2; val mz = (ca.cz + cb.cz) / 2
            ra[ia] = joinRow(ca, mx, mz, rc); rb[ib] = joinRow(cb, mx, mz, rc)
        }
        val lowF = BooleanArray(n); val lowL = BooleanArray(n); val fillets = ArrayList<Part>()
        for (i in 0 until n) for (atStart in booleanArrayOf(true, false)) {
            if (rws[i].size < 4) continue
            val p = if (atStart) roads[i].pts.first() else roads[i].pts.last()
            val probe = rws[i][if (atStart) min(5, rws[i].lastIndex) else max(rws[i].size - 6, 0)]
            var done = false
            for (j in 0 until n) {
                if (j == i || rws[j].size < 6) continue
                val rj = rws[j]
                if (distToPoly(rj, p[0], p[1]) > 0.6f) continue
                if (hypot(p[0] - rj.first().cx, p[1] - rj.first().cz) < 3f || hypot(p[0] - rj.last().cx, p[1] - rj.last().cz) < 3f) continue
                var bd = 1e18f; var jx = 0f; var jz = 0f; var mx = 1f; var mz = 0f
                for (q in 0 until rj.size - 1) {
                    val a0 = rj[q]; val b0 = rj[q + 1]; val dx = b0.cx - a0.cx; val dz = b0.cz - a0.cz; val l2 = dx * dx + dz * dz
                    if (l2 < 1e-9f) continue
                    val t = (((p[0] - a0.cx) * dx + (p[1] - a0.cz) * dz) / l2).coerceIn(0f, 1f); val qx = a0.cx + dx * t; val qz = a0.cz + dz * t
                    val d2 = (p[0] - qx) * (p[0] - qx) + (p[1] - qz) * (p[1] - qz)
                    if (d2 < bd) { bd = d2; jx = qx; jz = qz; val l = sqrt(l2); mx = dx / l; mz = dz / l }
                }
                var nx = -mz; var nz = mx
                if ((probe.cx - jx) * nx + (probe.cz - jz) * nz < 0) { nx = -nx; nz = -nz }
                val hw = Road.width / 2
                val ringMain = roads[j].pts.size >= 4 && hypot(roads[j].pts.first()[0] - roads[j].pts.last()[0], roads[j].pts.first()[1] - roads[j].pts.last()[1]) < 0.5f
                trimFillet(rws[i], atStart, floatArrayOf(jx + nx * hw, jz + nz * hw), floatArrayOf(nx, nz), hf, if (ringMain) 3f else 5f, fillets.size + 1)?.let { fillets.add(it) }
                if (atStart) lowF[i] = true else lowL[i] = true
                done = true; break
            }
            if (done) continue
            for (pd in pads) {
                val dd = hypot(p[0] - pd[0], p[1] - pd[1])
                if (abs(dd - Road.padR) > 1f) continue
                val nx = (p[0] - pd[0]) / (if (dd < 1e-4f) 1f else dd); val nz = (p[1] - pd[1]) / (if (dd < 1e-4f) 1f else dd)
                trimFillet(rws[i], atStart, floatArrayOf(pd[0] + nx * Road.padR, pd[1] + nz * Road.padR), floatArrayOf(nx, nz), hf, 3f, fillets.size + 1)?.let { fillets.add(it) }
                if (atStart) lowF[i] = true else lowL[i] = true
                break
            }
        }
        val meshes = ArrayList<Part>(); val traffic = ArrayList<Part>()
        roads.forEachIndexed { i, rd ->
            Road.mesh(rws[i], hf, rd.rough, i + 1, if (rd.rough) lavaMat else roadMat, lowF[i], lowL[i])?.let { meshes.add(it) }
        }
        meshes.addAll(fillets)
        pads.forEachIndexed { i, pd -> meshes.add(Road.pad(pd[0], pd[1], hf, i + 1, roadMat)) }
        lastPres = pres; lastPosts = posts
        rowsAll = rws.mapIndexed { i, r -> r.toList() to roads[i].rough }; terrains.forEach { it.cut = null }
        roadParts = meshes + traffic
    }

    /** Carrefour / Rond-point: apetraho ny teboka eo afovoan'ny sampana (mode Gen) ary Generate. Ny road akaiky dia mifandray amin'ny peratra (R=10 m) na ny toerana boribory (R=9 m). */
    private fun generateJunction(roundabout: Boolean) {
        val c = pts.lastOrNull() ?: return toast("Apetaho aloha ny teboka eo afovoan'ny sampana (mode Gen)")
        if (terrains.isEmpty() || roads.isEmpty()) return toast("Mila road misy aloha")
        save()
        val cx = c[0]; val cz = c[1]; val R = if (roundabout) Road.ringR else Road.padR; val cutR = R + 10f
        fun ringPt(q: FloatArray): FloatArray { val dx = q[0] - cx; val dz = q[1] - cz; val l = hypot(dx, dz).let { if (it < 1e-4f) 1f else it }; return floatArrayOf(cx + dx / l * R, cz + dz / l * R) }
        fun leadPt(q: FloatArray): FloatArray { val dx = q[0] - cx; val dz = q[1] - cz; val l = hypot(dx, dz).let { if (it < 1e-4f) 1f else it }; return floatArrayOf(cx + dx / l * (R + 5f), cz + dz / l * (R + 5f)) }
        fun segNear(a: FloatArray, b: FloatArray): Boolean {
            val dx = b[0] - a[0]; val dz = b[1] - a[1]; val l2 = dx * dx + dz * dz
            val t = if (l2 < 1e-9f) 0f else (((cx - a[0]) * dx + (cz - a[1]) * dz) / l2).coerceIn(0f, 1f)
            return hypot(cx - (a[0] + dx * t), cz - (a[1] + dz * t)) < cutR
        }
        val out = ArrayList<RoadDef>(); val angs = ArrayList<Float>()
        fun note(q: FloatArray) { angs.add(atan2(q[1] - cz, q[0] - cx)) }
        for (rd in roads) {
            val p = rd.pts; var touched = false; var startCut = false
            var run = ArrayList<FloatArray>(); val runs = ArrayList<Pair<ArrayList<FloatArray>, BooleanArray>>()
            for (i in p.indices) {
                val q = p[i]
                if (hypot(q[0] - cx, q[1] - cz) < cutR) {
                    touched = true; if (run.isNotEmpty()) { runs.add(run to booleanArrayOf(startCut, true)); run = ArrayList() }; startCut = true; continue
                }
                if (i > 0 && segNear(p[i - 1], q)) { touched = true; if (run.isNotEmpty()) { runs.add(run to booleanArrayOf(startCut, true)); run = ArrayList() }; startCut = true }
                run.add(q)
            }
            if (run.isNotEmpty()) runs.add(run to booleanArrayOf(startCut, false))
            if (!touched) {
                val np = p.map { it.clone() }.toMutableList()
                if (hypot(p.first()[0] - cx, p.first()[1] - cz) < 35f) { note(p.first()); if (hypot(p.first()[0] - cx, p.first()[1] - cz) > R + 8f) np.add(0, leadPt(p.first())); np.add(0, ringPt(p.first())) }
                if (hypot(p.last()[0] - cx, p.last()[1] - cz) < 35f) { note(p.last()); if (hypot(p.last()[0] - cx, p.last()[1] - cz) > R + 8f) np.add(leadPt(p.last())); np.add(ringPt(p.last())) }
                out.add(RoadDef(np, rd.rough)); continue
            }
            for ((rn, fl) in runs) {
                val l = ArrayList<FloatArray>()
                if (fl[0]) { note(rn.first()); l.add(ringPt(rn.first())); l.add(leadPt(rn.first())) }
                l.addAll(rn)
                if (fl[1]) { note(rn.last()); l.add(leadPt(rn.last())); l.add(ringPt(rn.last())) }
                if (l.size >= 2) out.add(RoadDef(l, rd.rough))
            }
        }
        roads.clear(); roads.addAll(out)
        if (roundabout) {
            val s = angs.sorted(); var best = 0f; var a0 = 0f
            for (i in s.indices) { val a = s[i]; val b = if (i + 1 < s.size) s[i + 1] else s[0] + 6.2831855f; if (b - a > best) { best = b - a; a0 = a + (b - a) / 2 } }
            val ring = ArrayList<FloatArray>()
            for (k in 0..16) { val a = a0 + k * 6.2831855f / 16; ring.add(floatArrayOf(cx + cos(a) * R, cz + sin(a) * R)) }
            roads.add(RoadDef(ring, false))
        } else pads.add(floatArrayOf(cx, cz))
        pts.clear(); markers = emptyList(); rebuildRoads(); push(false)
    }

    /** Famafana kely ny teboka soratana amin'ny tanana (tsy mitoto ny lalana): ny tendrony tsy mihetsika. */
    private fun smoothPts(p: List<FloatArray>): List<FloatArray> {
        var c = p.map { it.clone() }
        repeat(2) { val q = c.map { it.clone() }
            for (i in 1 until c.size - 1) { c[i][0] = q[i - 1][0] * 0.25f + q[i][0] * 0.5f + q[i + 1][0] * 0.25f; c[i][1] = q[i - 1][1] * 0.25f + q[i][1] * 0.5f + q[i + 1][1] * 0.25f } }
        return c
    }

    /** Generate: mamorona ny endriky ny terrain manodidina ny toerana voasoratra (mode Generate) na ny road rehetra. Mitohy amin'ny generate teo aloha (tsy manoratra ambony). */
    private fun generate() {
        if (genKind == 1 || genKind == 2) return generateJunction(genKind == 2)
        if (genKind == 3) return generateObjects()
        if (genKind == 4) return generatePoles()
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha")
        val hf: (Float, Float) -> Float = { x, z -> hAt(x, z) }
        val srcs: List<List<FloatArray>> = if (pts.size >= 2) listOf(smoothPts(pts)) else roads.map { it.pts }
        if (srcs.isEmpty()) return toast("Soraty aloha ny toerana (mode Generate) na manaova road aloha")
        save()
        for (src in srcs) {
            val np = src.map { it.clone() }.toMutableList()
            val e = gens.flatMap { listOf(it.pts.first(), it.pts.last()) }.minByOrNull { hypot(it[0] - np[0][0], it[1] - np[0][1]) }
            var startH: Float? = null; var join = false
            if (e != null && hypot(e[0] - np[0][0], e[1] - np[0][1]) < 10f) { np[0] = e.clone(); startH = hf(e[0], e[1]); join = true }   // mitohy: manomboka amin'ny haavon'ny farany teo aloha
            val others = gens.map { Road.rows(it.pts, hf, 1f, null, null) }
            Gen.apply(terrains, Road.rows(np, hf, 1f, null, null), genProfile, genDir, genRise, hf, others, startH, join)
            gens.add(GenDef(np, genProfile, genRise))
        }
        syncSeams(); resnapAll(); pts.clear(); markers = emptyList()
        if (roads.isNotEmpty()) rebuildRoads()
        terrains.forEach { inv(it.part) }; push(false)
    }

    private fun inRoad(rs: List<Row>, x: Float, z: Float): Boolean {
        for (j in 0 until rs.size - 1) { val a = rs[j]; val b = rs[j + 1]; val dx = b.cx - a.cx; val dz = b.cz - a.cz; val l2 = dx * dx + dz * dz
            val t = if (l2 < 1e-9f) 0f else (((x - a.cx) * dx + (z - a.cz) * dz) / l2).coerceIn(0f, 1f)
            if (hypot(x - (a.cx + dx * t), z - (a.cz + dz * t)) <= Road.width / 2 + 0.3f) return true }
        return false
    }

    private fun resetMats() {
        for (m in listOf(roadMat, lavaMat)) { m.tex = null; m.bmp = null; gl.queueEvent { r.dropTex(m) } }
        roadMat.kd = floatArrayOf(0.25f, 0.25f, 0.27f); lavaMat.kd = floatArrayOf(0.33f, 0.27f, 0.22f)
    }

    private fun markerList(): List<Part> = pts.mapIndexed { i, p -> val yy = hAt(p[0], p[1]) + 0.6f; val s = 1f
        Part("m$i", mk, floatArrayOf(p[0] - s, yy, p[1] - s, p[0] + s, yy, p[1] - s, p[0] + s, yy, p[1] + s, p[0] - s, yy, p[1] + s), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)) }

    /** Soritana amin'ny tanana: teboka vaovao isaky ny 4 m raha mihetsika ny rantsantanana (mode Road/Lavaka). */
    private fun stroke(x: Float, y: Float, moved: Float) {
        if (moved < 12f || terrains.isEmpty()) return
        val h = pick(x, y) ?: return; val l = pts.lastOrNull()
        if (l != null && hypot(h[0] - l[0], h[2] - l[1]) < 4f) return
        pts.add(floatArrayOf(h[0], h[2])); ptsRough = mode == 3; markers = markerList(); push(false)
    }

    /** Road vaovao: raha manomboka akaikin'ny tendron'ny road efa misy (<8 m) ary mitovy karazana dia mitohy ho road iray. */
    private fun buildRoad() {
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha")
        if (pts.size < 2) return toast("Mode Road: tsindrio teboka 2 farafahakeliny")
        save()
        val rough = mode == 3
        val np = smoothPts(pts).toMutableList()
        fun near(p: FloatArray): Pair<Int, Boolean>? {
            var bi = -1; var be = false; var bd = 8f
            roads.forEachIndexed { i, rd -> for (end in booleanArrayOf(false, true)) {
                val e = if (end) rd.pts.last() else rd.pts.first(); val dd = hypot(e[0] - p[0], e[1] - p[1])
                val eff = dd - (if (i == roads.lastIndex) 7f else 0f); if (eff < bd) { bd = eff; bi = i; be = end } } }
            return if (bi >= 0) bi to be else null
        }
        val firstFree = near(np.first()) == null; val lastFree = near(np.last()) == null
        if (firstFree) centerSnap(np, 0)
        if (lastFree) centerSnap(np, np.lastIndex)
        var merged = false
        val a = near(np.first())
        if (a != null) {
            val rd = roads[a.first]; np[0] = (if (a.second) rd.pts.last() else rd.pts.first()).clone()
            if (rd.rough == rough && !isJunctionEnd(a.first, a.second)) {
                roads[a.first] = RoadDef(if (a.second) rd.pts + np.drop(1) else np.reversed().dropLast(1) + rd.pts, rd.rough); merged = true
            }
        }
        if (!merged) {
            val plen = np.zipWithNext { a1, b1 -> hypot(b1[0] - a1[0], b1[1] - a1[1]) }.sum()
            if (np.size >= 4 && plen > 30f && hypot(np.last()[0] - np.first()[0], np.last()[1] - np.first()[1]) < 10f) np[np.lastIndex] = np[0].clone()   // vodiny: mitambatra amin'ny tendron'ny voalohany
            else { val b = near(np.last()); if (b != null) { val rd = roads[b.first]; np[np.lastIndex] = (if (b.second) rd.pts.last() else rd.pts.first()).clone() } }
            val closed = np.size >= 4 && hypot(np.last()[0] - np.first()[0], np.last()[1] - np.first()[1]) < 0.5f
            if (closed) roads.add(RoadDef(np, rough)) else splitCrossings(np).forEach { roads.add(RoadDef(it, rough)) }
        }
        pts.clear(); markers = emptyList(); rebuildRoads(); push(false)
    }

    // ---------- Import / Export ----------
    private fun find(n: String) = dir?.listFiles()?.firstOrNull { it.name.equals(n, true) }
    private fun lines(f: DocumentFile) = contentResolver.openInputStream(f.uri)!!.bufferedReader().readLines()

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val u = d?.data ?: return
        if (rc == 3) { applyTexture(u); return }
        dir = DocumentFile.fromTreeUri(this, u)
        if (rc == 2) { if (pendingExport) { pendingExport = false; export() }; return }
        val objsF = dir!!.listFiles().filter { it.name?.endsWith(".obj", true) == true }
        when {
            objsF.isEmpty() -> toast("Tsy misy .obj ao amin'io lahatahiry io")
            objsF.size == 1 -> load(objsF[0])
            else -> AlertDialog.Builder(this).setItems(objsF.map { it.name }.toTypedArray()) { _, i -> load(objsF[i]) }.show()
        }
    }

    private fun load(f: DocumentFile) {
        base = f.name!!.substringBeforeLast('.')
        Thread {
            try {
                val p = Obj.parse(lines(f), { n -> find(n.substringAfterLast('/'))?.let { lines(it) } }, base)
                val miss = ArrayList<String>()
                for (pt in p) {
                    val tn = pt.mat.tex
                    if (pt.mat.bmp == null && tn != null) {
                        val tf = find(tn)
                        if (tf != null) pt.mat.bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(tf.uri)) else miss.add(tn)
                    }
                }
                runOnUiThread {
                    p.forEach { val ob = Obj3(it.name, listOf(it), false); ob.recenter(); objs.add(ob) }
                    missing = if (miss.isEmpty()) "" else "\n⚠ texture tsy hita: " + miss.distinct().joinToString()
                    push(true)
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana: ${e.message}") } }
        }.start()
    }

    private fun export() {
        val d = dir
        if (d == null) { pendingExport = true; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2); return }
        val ps = allParts(false); if (ps.isEmpty()) return toast("Tsy misy modely")
        val name = if (objs.isEmpty()) "terrain_road" else "${base}_edit"
        try {
            val (obj, mtl) = ObjWriter.write(ps, name)
            for ((fn, txt) in listOf("$name.obj" to obj, "$name.mtl" to mtl)) {
                find(fn)?.delete()
                val out = d.createFile("application/octet-stream", fn)!!
                contentResolver.openOutputStream(out.uri)!!.use { it.write(txt.toByteArray()) }
            }
            for (m in ps.map { it.mat }.distinct()) {   // soraty ny PNG vaovao (texture nampidirina)
                val tn = m.tex; val b = m.bmp
                if (tn != null && b != null && find(tn) == null) {
                    val tf = d.createFile("image/png", tn)!!
                    contentResolver.openOutputStream(tf.uri)!!.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
            }
            toast("Vita: $name.obj + .mtl (${ps.size} objet)")
        } catch (e: Exception) { toast("Olana export: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
