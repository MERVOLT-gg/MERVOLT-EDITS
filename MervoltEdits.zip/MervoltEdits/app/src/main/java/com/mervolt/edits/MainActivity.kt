package com.mervolt.edits

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import kotlin.math.abs
import kotlin.math.hypot

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private lateinit var info: TextView
    private val r = Renderer()
    private var dir: DocumentFile? = null
    private var model = listOf<Part>()
    private var terrain: Terrain? = null
    private var roadParts = listOf<Part>()
    private var markers = listOf<Part>()
    private val pts = ArrayList<FloatArray>()
    private class RoadDef(val pts: List<FloatArray>, val rough: Boolean)
    private val roads = ArrayList<RoadDef>()
    private var ptsRough = false
    private var mode = 0; private var tool = 0; private var radius = 8f
    private var base = "model"; private var pendingExport = false; private var missing = ""
    private val modeNames = arrayOf("Vue", "Sculpt", "Road", "Road lavaka"); private val toolNames = arrayOf("Raise", "Lower", "Smooth")
    private val mk = Mat("marker").apply { kd = floatArrayOf(1f, 0.6f, 0f) }

    private fun btn(t: String, f: (Button) -> Unit): Button { val b = Button(this); b.text = t; b.setOnClickListener { f(b) }; return b }
    private fun allParts(m: Boolean): List<Part> = model + listOfNotNull(terrain?.part) + roadParts + (if (m) markers else emptyList())

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(2); setEGLConfigChooser(8, 8, 8, 8, 16, 0); setRenderer(r); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY }
        val root = FrameLayout(this); root.addView(gl)
        val bar = LinearLayout(this)
        bar.addView(btn("OBJ") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 1) })
        bar.addView(btn("Terrain vaovao") { terrain = Terrain(); push(true) })
        bar.addView(btn("Mode: Vue") { mode = (mode + 1) % 4; it.text = "Mode: ${modeNames[mode]}"; refresh() })
        bar.addView(btn("Brush: Raise") { tool = (tool + 1) % 3; it.text = "Brush: ${toolNames[tool]}"; refresh() })
        bar.addView(btn("R+") { radius = minOf(40f, radius + 2f); refresh() })
        bar.addView(btn("R-") { radius = maxOf(2f, radius - 2f); refresh() })
        bar.addView(btn("Road vita") { buildRoad() })
        bar.addView(btn("Re-snap") { rebuildRoads(); push(false) })
        bar.addView(btn("Fafao road") { pts.clear(); markers = emptyList(); roadParts = emptyList(); roads.clear(); push(false) })
        bar.addView(btn("Fit") { gl.queueEvent { r.fit() }; gl.requestRender() })
        bar.addView(btn("Export .obj") { export() })
        val sv = HorizontalScrollView(this); sv.addView(bar)
        root.addView(sv, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; setPadding(16, 16, 16, 16) }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(TextView(this).apply {   // WATERMARK
            text = "MERVOLT EDITS Claude ai"; setTextColor(Color.argb(170, 255, 255, 255)); textSize = 14f
            setShadowLayer(4f, 1f, 1f, Color.BLACK); setPadding(16, 16, 16, 16)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        setContentView(root)

        val sc = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { r.dist /= d.scaleFactor; gl.requestRender(); return true } })
        var lx = 0f; var ly = 0f; var moved = 0f; var multi = false
        gl.setOnTouchListener { _, e ->
            sc.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; moved = 0f; multi = false; lastDab = null; if (mode == 1) dab(e.x, e.y, true) }
                MotionEvent.ACTION_POINTER_DOWN -> { multi = true; lx = (e.getX(0) + e.getX(1)) / 2; ly = (e.getY(0) + e.getY(1)) / 2 }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {   // 2 rantsantanana = pan + zoom
                        val cx = (e.getX(0) + e.getX(1)) / 2; val cy = (e.getY(0) + e.getY(1)) / 2
                        r.px += (cx - lx) * r.dist * 0.0012f; r.py -= (cy - ly) * r.dist * 0.0012f; lx = cx; ly = cy; gl.requestRender()
                    } else if (!multi) {
                        moved += abs(e.x - lx) + abs(e.y - ly)
                        if (mode == 0) { r.ry += (e.x - lx) * 0.4f; r.rx += (e.y - ly) * 0.4f; gl.requestRender() }
                        else if (mode == 1) dab(e.x, e.y, false)
                        lx = e.x; ly = e.y
                    }
                }
                MotionEvent.ACTION_UP -> { lastDab = null; if (mode >= 2 && !multi && moved < 20f) addPoint(e.x, e.y) }
            }
            true
        }
    }

    private fun push(fit: Boolean) {
        val p = allParts(true)
        gl.queueEvent { r.applyParts(p); if (fit) r.fit() }; gl.requestRender(); refresh()
    }

    private fun refresh() {
        val t = terrain
        info.text = "Mode: ${modeNames[mode]} | ${toolNames[tool]} R=${radius.toInt()} | teboka road: ${pts.size}\n" +
            "objet: ${model.size}" +  (if (t != null) " | terrain" else "") + " | road+traffic: ${roadParts.size}\n" +
            "Vue: 1 rantsantanana=mihodina | Sculpt: misintona eo amin'ny terrain | Road: tsindrio ny teboka | 2 rantsantanana=pan/zoom" + missing
    }

    private fun pick(x: Float, y: Float): FloatArray? {
        val t = terrain ?: return null; val (o, d) = r.ray(x, y) ?: return null
        val step = t.size / 300f; var s = 0f; val half = t.size / 2
        repeat(4000) {
            val px = o[0] + d[0] * s; val py = o[1] + d[1] * s; val pz = o[2] + d[2] * s
            if (abs(px) <= half && abs(pz) <= half && py <= t.height(px, pz)) return floatArrayOf(px, py, pz)
            s += step
        }
        return null
    }

    private var lastDab: FloatArray? = null
    /** Sculpt araka ny elanelana: dab vaovao isaky ny R*0.3 fa tsy isaky ny hetsika (tsy midina foana intsony). */
    private fun dab(x: Float, y: Float, force: Boolean) {
        val t = terrain ?: return; val h = pick(x, y) ?: return
        val ld = lastDab
        if (!force && ld != null && hypot(h[0] - ld[0], h[2] - ld[1]) < radius * 0.3f) return
        lastDab = floatArrayOf(h[0], h[2])
        t.sculpt(h[0], h[2], radius, 0.05f + radius * 0.01f, tool)
        gl.queueEvent { r.invalidate(t.part) }; gl.requestRender()
    }

    private fun addPoint(x: Float, y: Float) {
        val t = terrain ?: return toast("Mamoròna terrain aloha"); val h = pick(x, y) ?: return
        pts.add(floatArrayOf(h[0], h[2])); ptsRough = mode == 3
        markers = pts.mapIndexed { i, p -> val yy = t.height(p[0], p[1]) + 0.4f; val s = 0.8f
            Part("m$i", mk, floatArrayOf(p[0] - s, yy, p[1] - s, p[0] + s, yy, p[1] - s, p[0] + s, yy, p[1] + s, p[0] - s, yy, p[1] + s), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)) }
        push(false)
    }

    private fun rebuildRoads() {
        val t = terrain ?: return; val c = intArrayOf(1)
        roadParts = roads.flatMapIndexed { i, rd -> Road.build(rd.pts, t, rd.rough, i + 1, c) }
    }

    private fun buildRoad() {
        if (terrain == null) return toast("Mamoròna terrain aloha")
        if (pts.size < 2) return toast("Mode Road: tsindrio teboka 2 farafahakeliny")
        val ends = roads.flatMap { listOf(it.pts.first(), it.pts.last()) }
        val np = pts.map { it.clone() }.toMutableList()
        for (i in intArrayOf(0, np.lastIndex)) {   // snap amin'ny tendron'ny road efa misy (mifampitohy)
            val e = ends.minByOrNull { hypot(it[0] - np[i][0], it[1] - np[i][1]) }
            if (e != null && hypot(e[0] - np[i][0], e[1] - np[i][1]) < 5f) np[i] = e.clone()
        }
        roads.add(RoadDef(np, ptsRough)); pts.clear(); markers = emptyList()
        rebuildRoads(); push(false)
    }

    private fun find(n: String) = dir?.listFiles()?.firstOrNull { it.name.equals(n, true) }
    private fun lines(f: DocumentFile) = contentResolver.openInputStream(f.uri)!!.bufferedReader().readLines()

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val u = d?.data ?: return
        dir = DocumentFile.fromTreeUri(this, u)
        if (rc == 2) { if (pendingExport) { pendingExport = false; export() }; return }
        val objs = dir!!.listFiles().filter { it.name?.endsWith(".obj", true) == true }
        when {
            objs.isEmpty() -> toast("Tsy misy .obj ao amin'io lahatahiry io")
            objs.size == 1 -> load(objs[0])
            else -> AlertDialog.Builder(this).setItems(objs.map { it.name }.toTypedArray()) { _, i -> load(objs[i]) }.show()
        }
    }

    private fun load(f: DocumentFile) {
        base = f.name!!.substringBeforeLast('.')
        Thread {
            try {
                val p = Obj.parse(lines(f), { n -> find(n.substringAfterLast('/'))?.let { lines(it) } }, base)
                val miss = ArrayList<String>()
                for (pt in p) {
                    val tn = pt.mat.tex
                    if (pt.mat.bmp == null && tn != null) {
                        val tf = find(tn)
                        if (tf != null) pt.mat.bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(tf.uri)) else miss.add(tn)
                    }
                }
                runOnUiThread {
                    model = p; missing = if (miss.isEmpty()) "" else "\n⚠ texture tsy hita: " + miss.distinct().joinToString()
                    push(true)
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana: ${e.message}") } }
        }.start()
    }

    private fun export() {
        val d = dir
        if (d == null) { pendingExport = true; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2); return }
        val ps = allParts(false); if (ps.isEmpty()) return toast("Tsy misy modely")
        val name = if (model.isEmpty()) "terrain_road" else "${base}_edit"
        try {
            val (obj, mtl) = ObjWriter.write(ps, name)
            for ((fn, txt) in listOf("$name.obj" to obj, "$name.mtl" to mtl)) {
                find(fn)?.delete()
                val out = d.createFile("application/octet-stream", fn)!!
                contentResolver.openOutputStream(out.uri)!!.use { it.write(txt.toByteArray()) }
            }
            toast("Vita: $name.obj + .mtl (${ps.size} objet)")
        } catch (e: Exception) { toast("Olana export: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
