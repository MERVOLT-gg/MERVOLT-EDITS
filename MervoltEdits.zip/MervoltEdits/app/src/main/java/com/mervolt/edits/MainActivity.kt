package com.mervolt.edits

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.*
import androidx.documentfile.provider.DocumentFile

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private lateinit var info: TextView
    private val r = Renderer()
    private var dir: DocumentFile? = null
    private var parts = listOf<Part>()
    private var base = "model"

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(2); setEGLConfigChooser(8, 8, 8, 8, 16, 0); setRenderer(r); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY }
        val root = FrameLayout(this); root.addView(gl)
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(Button(this).apply { text = "Sokafy OBJ (lahatahiry)"; setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 1) } })
        bar.addView(Button(this).apply { text = "Export .3ds"; setOnClickListener { export() } })
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP))
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; setPadding(16, 16, 16, 16) }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(TextView(this).apply {   // WATERMARK
            text = "MERVOLT EDITS Claude ai"; setTextColor(Color.argb(170, 255, 255, 255)); textSize = 14f
            setShadowLayer(4f, 1f, 1f, Color.BLACK); setPadding(16, 16, 16, 16)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        setContentView(root)

        val sc = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { r.dist /= d.scaleFactor; gl.requestRender(); return true } })
        var lx = 0f; var ly = 0f
        gl.setOnTouchListener { _, e ->
            sc.onTouchEvent(e)
            if (e.pointerCount == 1 && !sc.isInProgress) {
                if (e.action == MotionEvent.ACTION_MOVE) { r.ry += (e.x - lx) * 0.4f; r.rx += (e.y - ly) * 0.4f; gl.requestRender() }
                lx = e.x; ly = e.y
            }
            true
        }
    }

    private fun find(n: String) = dir?.listFiles()?.firstOrNull { it.name.equals(n, true) }
    private fun lines(f: DocumentFile) = contentResolver.openInputStream(f.uri)!!.bufferedReader().readLines()

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val u = d?.data ?: return
        dir = DocumentFile.fromTreeUri(this, u)
        val objs = dir!!.listFiles().filter { it.name?.endsWith(".obj", true) == true }
        when {
            objs.isEmpty() -> toast("Tsy misy .obj ao amin'io lahatahiry io")
            objs.size == 1 -> load(objs[0])
            else -> AlertDialog.Builder(this).setItems(objs.map { it.name }.toTypedArray()) { _, i -> load(objs[i]) }.show()
        }
    }

    private fun load(f: DocumentFile) {
        base = f.name!!.substringBeforeLast('.')
        Thread {
            try {
                val p = Obj.parse(lines(f), { n -> find(n.substringAfterLast('/'))?.let { lines(it) } }, base)
                for (pt in p) {
                    pt.mat.cut = base.contains("cutout", true) || pt.mat.name.contains("cutout", true)
                    if (pt.mat.bmp == null) pt.mat.tex?.let { t -> find(t)?.let { pt.mat.bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(it.uri)) } }
                }
                parts = p
                runOnUiThread {
                    gl.queueEvent { r.load(p) }; gl.requestRender()
                    info.text = p.joinToString("\n") { "${it.name}  [${it.mat.name}]  v=${it.pos.size / 3} f=${it.idx.size / 3}" +
                        (if (it.pos.size / 3 > 65535) "  ⚠ >65535" else "") }
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana: ${e.message}") } }
        }.start()
    }

    private fun export() {
        val d = dir ?: return toast("Sokafy OBJ aloha")
        if (parts.isEmpty()) return toast("Tsy misy modely")
        try {
            val bytes = Writer3DS.write(parts)
            find("$base.3ds")?.delete()
            val out = d.createFile("application/octet-stream", "$base.3ds")!!
            contentResolver.openOutputStream(out.uri)!!.use { it.write(bytes) }
            toast("Vita: $base.3ds (miaraka amin'ny PNG ao amin'ny lahatahiry iray ihany)")
        } catch (e: Exception) { toast("Olana export: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
