package com.mervolt.edits

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.os.Looper
import android.view.View
import java.io.*
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private class RoadDef(val pts: List<FloatArray>, val rough: Boolean)
    private class GenDef(val pts: List<FloatArray>, val profile: Int, val rise: Float)
    private class Snap(val t: List<Triple<Terrain, FloatArray, FloatArray>>, val o: List<Pair<Obj3, FloatArray>>, val roads: List<RoadDef>, val gens: List<GenDef>)

    private lateinit var gl: GLSurfaceView
    private lateinit var info: TextView
    private val r = Renderer()
    private var dir: DocumentFile? = null
    private val terrains = ArrayList<Terrain>(); private val objs = ArrayList<Obj3>()
    private val roads = ArrayList<RoadDef>(); private var roadParts = listOf<Part>(); private var markers = listOf<Part>()
    private val pts = ArrayList<FloatArray>(); private var ptsRough = false
    private var mode = 0; private var tool = 0; private var radius = 12f; private var side = 0
    private var sel: Any? = null
    private var base = "model"; private var pendingExport = false; private var missing = ""; private var oid = 1; private var tid = 1
    private val undoS = ArrayList<Snap>(); private val redoS = ArrayList<Snap>()
    private val modeNames = arrayOf("Vue", "Sculpt", "Road", "Road lavaka", "Select", "Move", "Generate")
    private val toolNames = arrayOf("Raise", "Lower", "Smooth"); private val sideNames = arrayOf("E", "W", "N", "S")
    private val mk = Mat("marker").apply { kd = floatArrayOf(1f, 0.6f, 0f) }
    private var lastDab: FloatArray? = null
    private class RoadSel(val rough: Boolean)
    private val roadMat = Mat("road").apply { kd = floatArrayOf(0.25f, 0.25f, 0.27f) }
    private val lavaMat = Mat("road_lava").apply { kd = floatArrayOf(0.33f, 0.27f, 0.22f) }
    private var rowsAll = listOf<Pair<List<Row>, Boolean>>()
    private var grab = FloatArray(4)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun style(b: Button, on: Boolean) { b.setBackgroundColor(if (on) Color.rgb(255, 170, 40) else Color.rgb(60, 60, 66)); b.setTextColor(if (on) Color.BLACK else Color.WHITE) }
    private fun btn(t: String, f: (Button) -> Unit): Button {
        val b = Button(this); b.text = t; b.textSize = 10.5f; b.setAllCaps(false)
        b.minHeight = 0; b.minimumHeight = 0; b.minWidth = 0; b.minimumWidth = 0; b.setPadding(dp(8), 0, dp(8), 0)
        style(b, false); b.setOnClickListener { f(b) }
        b.layoutParams = LinearLayout.LayoutParams(-2, dp(28)).also { it.setMargins(dp(2), dp(2), dp(2), dp(2)) }
        return b
    }
    private fun allParts(m: Boolean): List<Part> = terrains.flatMap { it.cut ?: listOf(it.part) } + objs.flatMap { it.parts } + roadParts + (if (m) markers else emptyList())
    private fun hAt(x: Float, z: Float): Float = terrains.firstOrNull { it.contains(x, z) }?.height(x, z) ?: 0f
    private fun inv(p: Part) { gl.queueEvent { r.invalidate(p) }; gl.requestRender() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(2); setEGLConfigChooser(8, 8, 8, 8, 16, 0); setRenderer(r); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY }
        val root = FrameLayout(this); root.addView(gl)
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        fun scroller(vararg bs: Button): HorizontalScrollView { val l = LinearLayout(this); bs.forEach { l.addView(it) }; return HorizontalScrollView(this).also { it.addView(l) } }
        arrayOf("Vue", "Sculpt", "Road", "Lavaka", "Select", "Move", "Gen").forEachIndexed { i, n -> modeBtns.add(btn(n) { setMode(i) }) }
        col.addView(scroller(*modeBtns.toTypedArray()))
        panels.add(scroller(btn("Fit") { gl.queueEvent { r.fit() }; gl.requestRender() }))
        panels.add(scroller(btn("Brush: Raise") { tool = (tool + 1) % 3; it.text = "Brush: ${toolNames[tool]}"; refresh() },
            btn("R+") { radius = min(60f, radius + 3f); refresh() }, btn("R-") { radius = max(3f, radius - 3f); refresh() }))
        panels.add(scroller(btn("Road vita") { buildRoad() }, btn("Re-snap") { save(); rebuildRoads(); push(false) },
            btn("Fafao road") { save(); pts.clear(); markers = emptyList(); roadParts = emptyList(); roads.clear(); push(false) }))
        panels.add(scroller(btn("Texture") { pickTexture() }, btn("Rot+") { xf { it.yaw += 0.2618f } }, btn("Rot-") { xf { it.yaw -= 0.2618f } },
            btn("Sc+") { xf { it.scale *= 1.15f } }, btn("Sc-") { xf { it.scale /= 1.15f } }, btn("Fafa") { delSel() }))
        panels.add(scroller(btn("Generate") { generate() },
            btn("Profil: ${Gen.names[0]}") { genProfile = (genProfile + 1) % 4; it.text = "Profil: ${Gen.names[genProfile]}"; refresh() },
            btn("Rampe: Mitovy") { genDir = (genDir + 1) % 3; it.text = "Rampe: ${genDirNames[genDir]}"; refresh() },
            btn("R+") { genRise = min(30f, genRise + 1f); refresh() }, btn("R-") { genRise = max(0f, genRise - 1f); refresh() },
            btn("Fafao teboka") { pts.clear(); markers = emptyList(); push(false) }))
        panels.forEach { col.addView(it) }
        col.addView(scroller(btn("Terrain+") { addTerrain() }, btn("Sisiny: E") { side = (side + 1) % 4; it.text = "Sisiny: ${sideNames[side]}"; refresh() },
            btn("Objet+") { addObject() }, btn("Undo") { doUndo() }, btn("Redo") { doRedo() },
            btn("Import OBJ") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 1) },
            btn("Export .obj") { export() }, btn("Profil") { profileMenu() }))
        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; setPadding(16, 16, 16, 16) }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(TextView(this).apply {   // WATERMARK
            text = "MERVOLT EDITS Claude ai"; setTextColor(Color.argb(170, 255, 255, 255)); textSize = 14f
            setShadowLayer(4f, 1f, 1f, Color.BLACK); setPadding(16, 16, 16, 16)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
        root.addView(TextView(this).apply {   // legend reper
            val sp = SpannableString("X   Y   Z"); sp.setSpan(ForegroundColorSpan(Color.rgb(255, 70, 70)), 0, 1, 0)
            sp.setSpan(ForegroundColorSpan(Color.rgb(70, 255, 70)), 4, 5, 0); sp.setSpan(ForegroundColorSpan(Color.rgb(90, 140, 255)), 8, 9, 0)
            text = sp; textSize = 13f; setPadding(0, 0, 0, 0)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).also { it.setMargins(0, 0, dp(12), 90 + (resources.displayMetrics.widthPixels * 0.22f).toInt() + 6) })
        setContentView(root)
        profile = prefs.getString("profile", "profil_1") ?: "profil_1"; pdir(); setMode(0); loadProfile()

        val sc = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { r.dist /= d.scaleFactor; gl.requestRender(); return true } })
        var lx = 0f; var ly = 0f; var moved = 0f; var multi = false
        gl.setOnTouchListener { _, e ->
            sc.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; moved = 0f; multi = false; lastDab = null
                    if (mode == 1) { save(); dab(e.x, e.y, true) } else if (mode == 5) beginGrab(e.x, e.y) }
                MotionEvent.ACTION_POINTER_DOWN -> { multi = true; lx = (e.getX(0) + e.getX(1)) / 2; ly = (e.getY(0) + e.getY(1)) / 2 }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {   // 2 rantsantanana = pan + zoom
                        val cx = (e.getX(0) + e.getX(1)) / 2; val cy = (e.getY(0) + e.getY(1)) / 2
                        r.px += (cx - lx) * r.dist * 0.0012f; r.py -= (cy - ly) * r.dist * 0.0012f; lx = cx; ly = cy; gl.requestRender()
                    } else if (!multi) {
                        moved += abs(e.x - lx) + abs(e.y - ly)
                        when (mode) {
                            0 -> { r.ry += (e.x - lx) * 0.4f; r.rx += (e.y - ly) * 0.4f; gl.requestRender() }
                            1 -> dab(e.x, e.y, false)
                            5 -> dragTo(e.x, e.y)
                            2, 3, 6 -> stroke(e.x, e.y, moved)
                        }
                        lx = e.x; ly = e.y
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastDab = null
                    if (mode == 1 && roads.isNotEmpty()) { rebuildRoads(); push(false) }   // averina ny road amin'ny tany vaovao
                    if (!multi && moved < 20f) { if (mode == 2 || mode == 3 || mode == 6) addPoint(e.x, e.y) else if (mode == 4) selectAt(e.x, e.y) }
                    if (mode == 5) endGrab()
                }
            }
            true
        }
    }

    // ---------- Mode / UI ----------
    private val modeBtns = ArrayList<Button>(); private val panels = ArrayList<View>()
    private fun setMode(m: Int) {
        mode = m
        modeBtns.forEachIndexed { i, b -> style(b, i == m) }
        val pi = when (m) { 0 -> 0; 1 -> 1; 2, 3 -> 2; 6 -> 4; else -> 3 }
        panels.forEachIndexed { i, p -> p.visibility = if (i == pi) View.VISIBLE else View.GONE }
        refresh()
    }

    // ---------- Profil + sauvegarde auto ----------
    private var profile = "profil_1"
    private val prefs by lazy { getSharedPreferences("mervolt", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val saver = Runnable { saveNow(true) }
    private fun pdir(n: String = profile) = File(filesDir, "profiles/$n").also { it.mkdirs() }
    private fun profiles(): List<String> = File(filesDir, "profiles").list()?.sorted() ?: emptyList()
    private fun dirty() { handler.removeCallbacks(saver); handler.postDelayed(saver, 1500) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(saver); saveNow(false) }

    private fun matOut(o: DataOutputStream, m: Mat) { o.writeUTF(m.tex ?: ""); for (v in m.kd) o.writeFloat(v) }

    private fun serialize(): ByteArray {
        val bo = ByteArrayOutputStream(); val o = DataOutputStream(bo)
        o.writeInt(0x4D455632); o.writeUTF(base); o.writeInt(oid); o.writeInt(tid)
        o.writeInt(terrains.size)
        for (t in terrains) { o.writeUTF(t.name); o.writeInt(t.n); o.writeFloat(t.size); o.writeFloat(t.ox); o.writeFloat(t.oz)
            for (v in t.h) o.writeFloat(v); matOut(o, t.part.mat) }
        matOut(o, roadMat); matOut(o, lavaMat)
        o.writeInt(objs.size)
        for (ob in objs) {
            o.writeByte(if (ob.cat >= 0) 0 else 1); o.writeUTF(ob.name)
            for (v in ob.state()) o.writeFloat(v)
            o.writeInt(ob.parts.size)
            if (ob.cat >= 0) { o.writeInt(ob.cat); o.writeInt(ob.cid); for (p in ob.parts) matOut(o, p.mat) }
            else for ((k, p) in ob.parts.withIndex()) {
                o.writeUTF(p.name); o.writeUTF(p.mat.name); matOut(o, p.mat)
                val b = ob.base[k]; o.writeInt(b.size); for (v in b) o.writeFloat(v)
                o.writeInt(p.uv.size); for (v in p.uv) o.writeFloat(v)
                o.writeInt(p.idx.size); for (v in p.idx) o.writeInt(v)
            }
        }
        o.writeInt(roads.size)
        for (rd in roads) { o.writeBoolean(rd.rough); o.writeInt(rd.pts.size); for (p in rd.pts) { o.writeFloat(p[0]); o.writeFloat(p[1]) } }
        o.writeInt(gens.size)
        for (g in gens) { o.writeInt(g.profile); o.writeFloat(g.rise); o.writeInt(g.pts.size); for (p in g.pts) { o.writeFloat(p[0]); o.writeFloat(p[1]) } }
        o.flush(); return bo.toByteArray()
    }

    @Synchronized private fun writeFiles(d: File, bytes: ByteArray, texs: List<Pair<String, Bitmap>>) {
        val td = File(d, "tex").also { it.mkdirs() }
        for ((n, b) in texs) { val f = File(td, n); if (!f.exists()) FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        val tmp = File(d, "project.tmp"); tmp.writeBytes(bytes); tmp.renameTo(File(d, "project.bin"))
    }

    private fun saveNow(bg: Boolean) {
        try {
            val bytes = serialize(); val d = pdir()
            val texs = allParts(false).map { it.mat }.distinct().filter { it.tex != null && it.bmp != null }.distinctBy { it.tex }.map { it.tex!! to it.bmp!! }
            val job = Runnable { try { writeFiles(d, bytes, texs) } catch (e: Exception) { } }
            if (bg) Thread(job).start() else job.run()
        } catch (e: Exception) { }
    }

    private fun clearState() {
        terrains.clear(); objs.clear(); roads.clear(); roadParts = emptyList(); markers = emptyList(); pts.clear()
        sel = null; undoS.clear(); redoS.clear(); oid = 1; tid = 1; missing = ""; base = "model"; gens.clear(); genRise = 3f; resetMats()
    }

    private fun loadProfile() {
        val f = File(pdir(), "project.bin")
        if (!f.exists()) { push(true); return }
        try {
            val i = DataInputStream(BufferedInputStream(FileInputStream(f)))
            if (i.readInt() != 0x4D455632) throw Exception("fichier tsy mety")
            base = i.readUTF(); oid = i.readInt(); tid = i.readInt()
            val cache = HashMap<String, Bitmap?>()
            fun bmpOf(n: String): Bitmap? = cache.getOrPut(n) { val tf = File(File(pdir(), "tex"), n); if (tf.exists()) BitmapFactory.decodeFile(tf.path) else null }
            fun matIn(m: Mat) { val tn = i.readUTF(); m.kd = floatArrayOf(i.readFloat(), i.readFloat(), i.readFloat()); if (tn.isNotEmpty()) { m.tex = tn; m.bmp = bmpOf(tn) } }
            repeat(i.readInt()) {
                val nm = i.readUTF(); val n = i.readInt(); val sz = i.readFloat(); val ox = i.readFloat(); val oz = i.readFloat()
                val t = Terrain(nm, n, sz, ox, oz); for (k in t.h.indices) t.h[k] = i.readFloat()
                t.rebuildPos(); matIn(t.part.mat); terrains.add(t)
            }
            matIn(roadMat); matIn(lavaMat)
            repeat(i.readInt()) {
                val type = i.readByte().toInt(); val nm = i.readUTF(); val st = FloatArray(5) { i.readFloat() }; val np = i.readInt()
                if (type == 0) {
                    val cat = i.readInt(); val cid = i.readInt(); val ob = Catalog.make(cat, cid)
                    for (p in ob.parts) matIn(p.mat); ob.restore(st); objs.add(ob)
                } else {
                    val ps = ArrayList<Part>()
                    repeat(np) {
                        val pn = i.readUTF(); val mat = Mat(i.readUTF()); matIn(mat)
                        val pos = FloatArray(i.readInt()) { i.readFloat() }; val uv = FloatArray(i.readInt()) { i.readFloat() }; val idx = IntArray(i.readInt()) { i.readInt() }
                        ps.add(Part(pn, mat, pos, uv, idx))
                    }
                    val ob = Obj3(nm, ps, false); ob.restore(st); objs.add(ob)
                }
            }
            repeat(i.readInt()) {
                val rough = i.readBoolean(); val c = i.readInt(); val l = ArrayList<FloatArray>()
                repeat(c) { l.add(floatArrayOf(i.readFloat(), i.readFloat())) }; roads.add(RoadDef(l, rough))
            }
            if (i.available() > 0) repeat(i.readInt()) {
                val pr = i.readInt(); val rz = i.readFloat(); val c = i.readInt(); val l = ArrayList<FloatArray>()
                repeat(c) { l.add(floatArrayOf(i.readFloat(), i.readFloat())) }; gens.add(GenDef(l, pr, rz))
            }
            i.close(); rebuildRoads(); push(true)
        } catch (e: Exception) { toast("Olana famakiana profil: ${e.message}"); push(true) }
    }

    private fun switchTo(n: String) {
        if (n == profile) return
        handler.removeCallbacks(saver); saveNow(false); clearState()
        profile = n; prefs.edit().putString("profile", n).apply(); pdir(); loadProfile(); updateSel()
    }

    private fun profileMenu() {
        val names = profiles()
        val items = arrayOf("➕ Profil vaovao", "🗑 Fafao: $profile") + names.map { (if (it == profile) "● " else "") + it }
        AlertDialog.Builder(this).setTitle("Profil: $profile").setItems(items) { _, i ->
            when (i) {
                0 -> { val et = EditText(this); et.hint = "anarana (ohatra: tanàna_1)"
                    AlertDialog.Builder(this).setTitle("Profil vaovao").setView(et).setPositiveButton("Mamorona") { _, _ ->
                        val n = et.text.toString().trim().replace(Regex("[^A-Za-z0-9_-]"), "_").take(30)
                        if (n.isNotEmpty()) switchTo(n) }.setNegativeButton("Hijanona", null).show() }
                1 -> AlertDialog.Builder(this).setTitle("Fafana ve ny $profile ?").setPositiveButton("Eny, fafao") { _, _ ->
                    handler.removeCallbacks(saver); pdir().deleteRecursively(); clearState()
                    profile = profiles().firstOrNull() ?: "profil_1"; prefs.edit().putString("profile", profile).apply(); pdir(); loadProfile(); updateSel() }
                    .setNegativeButton("Tsia", null).show()
                else -> switchTo(names[i - 2])
            }
        }.show()
    }

    // ---------- fototra ----------
    private fun push(fit: Boolean) {
        val p = allParts(true)
        gl.queueEvent { r.applyParts(p); if (fit) r.fit() }; gl.requestRender(); refresh(); dirty()
    }

    /** Reper + boîte ho an'ny voafidy (rotation/expand/move). */
    private fun gizmoUpdate() {
        val s = sel
        if (s is Obj3) { val b = s.bounds(); val ext = max(b[3] - b[0], max(b[4] - b[1], b[5] - b[2]))
            r.axes = floatArrayOf(s.x, s.y, s.z, s.yaw, max(2f, ext * 0.6f)); r.box = b }
        else if (s is Terrain) { r.axes = floatArrayOf(s.ox, hAt(s.ox, s.oz) + 0.5f, s.oz, 0f, 25f); r.box = null }
        else { r.axes = null; r.box = null }
        gl.requestRender()
    }

    private fun selName(): String = when (val s = sel) { is Obj3 -> s.name; is Terrain -> s.name; is RoadSel -> if (s.rough) "road lavaka" else "road"; else -> "-" }

    private fun refresh() {
        info.text = "Profil: $profile | Mode: ${modeNames[mode]} | ${toolNames[tool]} R=${radius.toInt()} | Sisiny: ${sideNames[side]} | teboka: ${pts.size}\n" +
            "terrain: ${terrains.size} | objet: ${objs.size} | road: ${roads.count { !it.rough }} tsotra + ${roads.count { it.rough }} lavaka (${roadParts.size} Part) | Safidy: ${selName()}" +
            (if (mode == 6) "\nRampe: ${genDirNames[genDir]} ${genRise.toInt()} m/100 m | Profil: ${Gen.names[genProfile]}" else "") + missing
    }

    private fun updateSel() {
        objs.forEach { o -> o.parts.forEach { it.selected = o === sel } }
        terrains.forEach { t -> t.part.selected = t === sel; t.cut?.forEach { it.selected = t === sel } }
        gizmoUpdate(); gl.requestRender(); refresh()
    }

    // ---------- Undo / Redo ----------
    private fun snap() = Snap(terrains.map { Triple(it, it.h.copyOf(), floatArrayOf(it.ox, it.oz)) }, objs.map { it to it.state() }, roads.toList(), gens.toList())
    private fun save() { undoS.add(snap()); if (undoS.size > 30) undoS.removeAt(0); redoS.clear() }
    private fun restore(s: Snap) {
        terrains.clear(); s.t.forEach { (t, hh, o) -> System.arraycopy(hh, 0, t.h, 0, hh.size); t.ox = o[0]; t.oz = o[1]; t.rebuildPos(); terrains.add(t) }
        objs.clear(); s.o.forEach { (ob, st) -> ob.restore(st); objs.add(ob) }
        roads.clear(); roads.addAll(s.roads); gens.clear(); gens.addAll(s.gens); rebuildRoads()
        val ps = allParts(false); gl.queueEvent { ps.forEach { r.invalidate(it) } }
        sel = null; updateSel(); push(false)
    }
    private fun doUndo() { if (undoS.isEmpty()) return toast("Tsy misy Undo"); redoS.add(snap()); restore(undoS.removeAt(undoS.lastIndex)) }
    private fun doRedo() { if (redoS.isEmpty()) return toast("Tsy misy Redo"); undoS.add(snap()); restore(redoS.removeAt(redoS.lastIndex)) }

    // ---------- Picking ----------
    private fun pick(x: Float, y: Float): FloatArray? {
        if (terrains.isEmpty()) return null; val (o, d) = r.ray(x, y) ?: return null
        var s = 0f
        repeat(3000) {
            val px = o[0] + d[0] * s; val py = o[1] + d[1] * s; val pz = o[2] + d[2] * s
            val t = terrains.firstOrNull { it.contains(px, pz) }
            if (t != null && py <= t.height(px, pz)) return floatArrayOf(px, py, pz)
            s += 1f
        }
        return null
    }

    private fun planeHit(x: Float, y: Float, py: Float): FloatArray? {
        val (o, d) = r.ray(x, y) ?: return null
        if (abs(d[1]) < 1e-6f) return null
        val t = (py - o[1]) / d[1]; if (t < 0) return null
        return floatArrayOf(o[0] + d[0] * t, o[2] + d[2] * t)
    }

    private fun aabb(o: FloatArray, d: FloatArray, b: FloatArray): Float? {
        var t0 = 0f; var t1 = 1e9f
        for (k in 0..2) {
            if (abs(d[k]) < 1e-9f) { if (o[k] < b[k] || o[k] > b[k + 3]) return null }
            else { var a = (b[k] - o[k]) / d[k]; var c = (b[k + 3] - o[k]) / d[k]; if (a > c) { val t = a; a = c; c = t }
                t0 = max(t0, a); t1 = min(t1, c); if (t0 > t1) return null }
        }
        return t0
    }

    private fun selectAt(x: Float, y: Float) {
        val (o, d) = r.ray(x, y) ?: return
        var bestT = 1e9f; var best: Any? = null
        for (ob in objs) { val t = aabb(o, d, ob.bounds()); if (t != null && t < bestT) { bestT = t; best = ob } }
        val h = pick(x, y)
        if (h != null) { val t = hypot(hypot(h[0] - o[0], h[1] - o[1]), h[2] - o[2]); if (t < bestT) { bestT = t; best = rowsAll.firstOrNull { inRoad(it.first, h[0], h[2]) }?.let { RoadSel(it.second) } ?: terrains.firstOrNull { it.contains(h[0], h[2]) } } }
        sel = best; updateSel()
    }

    // ---------- Sculpt ----------
    private fun syncSeams() { for (i in terrains.indices) for (j in i + 1 until terrains.size) terrains[i].sync(terrains[j], false) }

    /** Dab isaky ny R*0.3 (tsy isaky ny hetsika), ka tsy midina foana. */
    private fun dab(x: Float, y: Float, force: Boolean) {
        val h = pick(x, y) ?: return
        val ld = lastDab
        if (!force && ld != null && hypot(h[0] - ld[0], h[2] - ld[1]) < radius * 0.3f) return
        lastDab = floatArrayOf(h[0], h[2])
        for (t in terrains) t.sculpt(h[0], h[2], radius, 0.1f + radius * 0.02f, tool)
        syncSeams(); terrains.forEach { t -> t.refreshCutHeights(); inv(t.part); t.cut?.forEach { inv(it) } }; dirty()
    }

    // ---------- Terrain ----------
    private fun addTerrain() {
        val b = (sel as? Terrain) ?: terrains.lastOrNull()
        val dx = if (side == 0) 1f else if (side == 1) -1f else 0f; val dz = if (side == 2) -1f else if (side == 3) 1f else 0f
        val nx = if (b == null) 0f else b.ox + dx * b.size; val nz = if (b == null) 0f else b.oz + dz * b.size
        if (terrains.any { abs(it.ox - nx) < 1f && abs(it.oz - nz) < 1f }) return toast("Efa misy terrain eo")
        save()
        val t = Terrain("terrain_${tid++}", ox = nx, oz = nz)
        if (b != null) t.sync(b, true)
        for (o in terrains) if (o !== b) t.sync(o, false)
        terrains.add(t); sel = t; updateSel(); push(terrains.size == 1)
        if (roads.isNotEmpty()) { rebuildRoads(); push(false) }
    }

    // ---------- Move ----------
    private fun beginGrab(x: Float, y: Float) {
        val s = sel ?: return
        val py = if (s is Obj3) s.y else 0f
        val h = planeHit(x, y, py) ?: return
        save()
        grab = if (s is Obj3) floatArrayOf(h[0], h[1], s.x, s.z) else { val t = s as Terrain; floatArrayOf(h[0], h[1], t.ox, t.oz) }
    }

    private fun dragTo(x: Float, y: Float) {
        val s = sel ?: return
        val h = planeHit(x, y, if (s is Obj3) s.y else 0f) ?: return
        dirty()
        var nx = grab[2] + h[0] - grab[0]; var nz = grab[3] + h[1] - grab[1]
        if (s is Obj3) { s.x = nx; s.z = nz; if (s.snap) s.y = hAt(nx, nz); s.apply(); s.parts.forEach { inv(it) }; gizmoUpdate() }
        else if (s is Terrain) {
            for (o in terrains) if (o !== s) for (a in floatArrayOf(-s.size, s.size)) {
                if (abs(nx - (o.ox + a)) < 6f && abs(nz - o.oz) < 6f) { nx = o.ox + a; nz = o.oz }
                else if (abs(nz - (o.oz + a)) < 6f && abs(nx - o.ox) < 6f) { nz = o.oz + a; nx = o.ox }
            }
            s.ox = nx; s.oz = nz; s.rebuildPos(); inv(s.part); gizmoUpdate()
        }
    }

    private fun endGrab() { if (sel is Terrain) { syncSeams(); terrains.forEach { inv(it.part) }; if (roads.isNotEmpty()) { rebuildRoads(); push(false) } } }

    // ---------- Objet ----------
    private fun addObject() {
        AlertDialog.Builder(this).setItems(Catalog.names) { _, i ->
            save()
            val ob = Catalog.make(i, oid++)
            val c = pick(gl.width / 2f, gl.height / 2f)
            ob.x = c?.get(0) ?: 0f; ob.z = c?.get(2) ?: 0f; ob.y = hAt(ob.x, ob.z); ob.apply()
            objs.add(ob); sel = ob; updateSel(); push(false)
        }.show()
    }

    private fun xf(f: (Obj3) -> Unit) {
        val o = sel as? Obj3 ?: return toast("Safidio aloha ny objet (Mode: Select)")
        save(); f(o); if (o.snap) o.y = hAt(o.x, o.z); o.apply(); o.parts.forEach { inv(it) }; dirty(); gizmoUpdate()
    }

    private fun delSel() {
        val s = sel ?: return toast("Safidio aloha (Mode: Select)")
        save()
        if (s is Obj3) objs.remove(s) else if (s is Terrain) terrains.remove(s)
        sel = null; updateSel(); push(false)
    }

    // ---------- Texture ----------
    private fun pickTexture() {
        if (sel == null) return toast("Safidio aloha ny objet/terrain (Mode: Select)")
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, 3)
    }

    private fun applyTexture(u: Uri) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(u)) ?: throw Exception("sary tsy mety")
                val nm = (DocumentFile.fromSingleUri(this, u)?.name ?: "tex").substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_") + ".png"
                runOnUiThread {
                    File(File(pdir(), "tex"), nm).delete()
                    val mats = when (val s = sel) { is Obj3 -> s.parts.map { it.mat }; is Terrain -> listOf(s.part.mat); is RoadSel -> listOf(if (s.rough) lavaMat else roadMat); else -> emptyList() }
                    mats.distinct().forEach { m -> m.bmp = bmp; m.tex = nm; m.kd = floatArrayOf(1f, 1f, 1f); gl.queueEvent { r.dropTex(m) } }
                    gl.requestRender(); dirty(); toast("Texture napetraka: $nm")
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana texture: ${e.message}") } }
        }.start()
    }

    // ---------- Road ----------
    private fun addPoint(x: Float, y: Float) {
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha"); val h = pick(x, y) ?: return
        pts.add(floatArrayOf(h[0], h[2])); ptsRough = mode == 3
        markers = pts.mapIndexed { i, p -> val yy = hAt(p[0], p[1]) + 0.6f; val s = 1f
            Part("m$i", mk, floatArrayOf(p[0] - s, yy, p[1] - s, p[0] + s, yy, p[1] - s, p[0] + s, yy, p[1] + s, p[0] - s, yy, p[1] + s), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)) }
        push(false)
    }

    private val gens = ArrayList<GenDef>(); private var genProfile = 0; private var genDir = 0; private var genRise = 3f
    private val genDirNames = arrayOf("Mitovy", "Fiakarana", "Fidinana")

    /** Road = mesh vaovao ambony terrain (trapeze), tsotra carré 2 m, lavaka carré 1 m. */
    private fun rebuildRoads() {
        val c = intArrayOf(1); val hf: (Float, Float) -> Float = { x, z -> hAt(x, z) }
        val meshes = ArrayList<Part>(); val traffic = ArrayList<Part>(); val rws = ArrayList<List<Row>>(); val rgh = ArrayList<Boolean>()
        roads.forEachIndexed { i, rd ->
            val f = rd.pts.first(); val l = rd.pts.last()
            var pre: FloatArray? = null; var post: FloatArray? = null
            roads.forEachIndexed { j, o -> if (j != i && o.pts.size >= 2) {
                if (hypot(o.pts.last()[0] - f[0], o.pts.last()[1] - f[1]) < 0.5f) pre = o.pts[o.pts.size - 2]
                if (hypot(o.pts.first()[0] - l[0], o.pts.first()[1] - l[1]) < 0.5f) post = o.pts[1]
            } }
            val rr = Road.rows(rd.pts, hf, if (rd.rough) 1f else 2f, pre, post); rws.add(rr); rgh.add(rd.rough)
            Road.mesh(rr, hf, rd.rough, i + 1, if (rd.rough) lavaMat else roadMat)?.let { meshes.add(it) }
            traffic.addAll(Road.traffic(rd.pts, hf, pre, post, c))
        }
        rowsAll = rws.zip(rgh); terrains.forEach { it.cut = null }
        roadParts = meshes + traffic
    }

    /** Famafana kely ny teboka soratana amin'ny tanana (tsy mitoto ny lalana): ny tendrony tsy mihetsika. */
    private fun smoothPts(p: List<FloatArray>): List<FloatArray> {
        var c = p.map { it.clone() }
        repeat(2) { val q = c.map { it.clone() }
            for (i in 1 until c.size - 1) { c[i][0] = q[i - 1][0] * 0.25f + q[i][0] * 0.5f + q[i + 1][0] * 0.25f; c[i][1] = q[i - 1][1] * 0.25f + q[i][1] * 0.5f + q[i + 1][1] * 0.25f } }
        return c
    }

    /** Generate: mamorona ny endriky ny terrain manodidina ny toerana voasoratra (mode Generate) na ny road rehetra. Mitohy amin'ny generate teo aloha (tsy manoratra ambony). */
    private fun generate() {
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha")
        val hf: (Float, Float) -> Float = { x, z -> hAt(x, z) }
        val srcs: List<List<FloatArray>> = if (pts.size >= 2) listOf(smoothPts(pts)) else roads.map { it.pts }
        if (srcs.isEmpty()) return toast("Soraty aloha ny toerana (mode Generate) na manaova road aloha")
        save()
        for (src in srcs) {
            val np = src.map { it.clone() }.toMutableList()
            val e = gens.flatMap { listOf(it.pts.first(), it.pts.last()) }.minByOrNull { hypot(it[0] - np[0][0], it[1] - np[0][1]) }
            var startH: Float? = null; var join = false
            if (e != null && hypot(e[0] - np[0][0], e[1] - np[0][1]) < 10f) { np[0] = e.clone(); startH = hf(e[0], e[1]); join = true }   // mitohy: manomboka amin'ny haavon'ny farany teo aloha
            val others = gens.map { Road.rows(it.pts, hf, 1f, null, null) }
            Gen.apply(terrains, Road.rows(np, hf, 1f, null, null), genProfile, genDir, genRise, hf, others, startH, join)
            gens.add(GenDef(np, genProfile, genRise))
        }
        syncSeams(); pts.clear(); markers = emptyList()
        if (roads.isNotEmpty()) rebuildRoads()
        terrains.forEach { inv(it.part) }; push(false)
    }

    private fun inRoad(rs: List<Row>, x: Float, z: Float): Boolean {
        for (j in 0 until rs.size - 1) { val a = rs[j]; val b = rs[j + 1]; val dx = b.cx - a.cx; val dz = b.cz - a.cz; val l2 = dx * dx + dz * dz
            val t = if (l2 < 1e-9f) 0f else (((x - a.cx) * dx + (z - a.cz) * dz) / l2).coerceIn(0f, 1f)
            if (hypot(x - (a.cx + dx * t), z - (a.cz + dz * t)) <= Road.width / 2 + 0.3f) return true }
        return false
    }

    private fun resetMats() {
        for (m in listOf(roadMat, lavaMat)) { m.tex = null; m.bmp = null; gl.queueEvent { r.dropTex(m) } }
        roadMat.kd = floatArrayOf(0.25f, 0.25f, 0.27f); lavaMat.kd = floatArrayOf(0.33f, 0.27f, 0.22f)
    }

    private fun markerList(): List<Part> = pts.mapIndexed { i, p -> val yy = hAt(p[0], p[1]) + 0.6f; val s = 1f
        Part("m$i", mk, floatArrayOf(p[0] - s, yy, p[1] - s, p[0] + s, yy, p[1] - s, p[0] + s, yy, p[1] + s, p[0] - s, yy, p[1] + s), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)) }

    /** Soritana amin'ny tanana: teboka vaovao isaky ny 4 m raha mihetsika ny rantsantanana (mode Road/Lavaka). */
    private fun stroke(x: Float, y: Float, moved: Float) {
        if (moved < 12f || terrains.isEmpty()) return
        val h = pick(x, y) ?: return; val l = pts.lastOrNull()
        if (l != null && hypot(h[0] - l[0], h[2] - l[1]) < 4f) return
        pts.add(floatArrayOf(h[0], h[2])); ptsRough = mode == 3; markers = markerList(); push(false)
    }

    /** Road vaovao: raha manomboka akaikin'ny tendron'ny road efa misy (<8 m) ary mitovy karazana dia mitohy ho road iray. */
    private fun buildRoad() {
        if (terrains.isEmpty()) return toast("Mamoròna terrain aloha")
        if (pts.size < 2) return toast("Mode Road: tsindrio teboka 2 farafahakeliny")
        save()
        val rough = mode == 3
        val np = smoothPts(pts).toMutableList()
        fun near(p: FloatArray): Pair<Int, Boolean>? {
            var bi = -1; var be = false; var bd = 8f
            roads.forEachIndexed { i, rd -> for (end in booleanArrayOf(false, true)) {
                val e = if (end) rd.pts.last() else rd.pts.first(); val dd = hypot(e[0] - p[0], e[1] - p[1])
                val eff = dd - (if (i == roads.lastIndex) 7f else 0f); if (eff < bd) { bd = eff; bi = i; be = end } } }
            return if (bi >= 0) bi to be else null
        }
        var merged = false
        val a = near(np.first())
        if (a != null) {
            val rd = roads[a.first]; np[0] = (if (a.second) rd.pts.last() else rd.pts.first()).clone()
            if (rd.rough == rough) {
                roads[a.first] = RoadDef(if (a.second) rd.pts + np.drop(1) else np.reversed().dropLast(1) + rd.pts, rd.rough); merged = true
            }
        }
        if (!merged) {
            val b = near(np.last()); if (b != null) { val rd = roads[b.first]; np[np.lastIndex] = (if (b.second) rd.pts.last() else rd.pts.first()).clone() }
            roads.add(RoadDef(np, rough))
        }
        pts.clear(); markers = emptyList(); rebuildRoads(); push(false)
    }

    // ---------- Import / Export ----------
    private fun find(n: String) = dir?.listFiles()?.firstOrNull { it.name.equals(n, true) }
    private fun lines(f: DocumentFile) = contentResolver.openInputStream(f.uri)!!.bufferedReader().readLines()

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val u = d?.data ?: return
        if (rc == 3) { applyTexture(u); return }
        dir = DocumentFile.fromTreeUri(this, u)
        if (rc == 2) { if (pendingExport) { pendingExport = false; export() }; return }
        val objsF = dir!!.listFiles().filter { it.name?.endsWith(".obj", true) == true }
        when {
            objsF.isEmpty() -> toast("Tsy misy .obj ao amin'io lahatahiry io")
            objsF.size == 1 -> load(objsF[0])
            else -> AlertDialog.Builder(this).setItems(objsF.map { it.name }.toTypedArray()) { _, i -> load(objsF[i]) }.show()
        }
    }

    private fun load(f: DocumentFile) {
        base = f.name!!.substringBeforeLast('.')
        Thread {
            try {
                val p = Obj.parse(lines(f), { n -> find(n.substringAfterLast('/'))?.let { lines(it) } }, base)
                val miss = ArrayList<String>()
                for (pt in p) {
                    val tn = pt.mat.tex
                    if (pt.mat.bmp == null && tn != null) {
                        val tf = find(tn)
                        if (tf != null) pt.mat.bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(tf.uri)) else miss.add(tn)
                    }
                }
                runOnUiThread {
                    p.forEach { val ob = Obj3(it.name, listOf(it), false); ob.recenter(); objs.add(ob) }
                    missing = if (miss.isEmpty()) "" else "\n⚠ texture tsy hita: " + miss.distinct().joinToString()
                    push(true)
                }
            } catch (e: Exception) { runOnUiThread { toast("Olana: ${e.message}") } }
        }.start()
    }

    private fun export() {
        val d = dir
        if (d == null) { pendingExport = true; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2); return }
        val ps = allParts(false); if (ps.isEmpty()) return toast("Tsy misy modely")
        val name = if (objs.isEmpty()) "terrain_road" else "${base}_edit"
        try {
            val (obj, mtl) = ObjWriter.write(ps, name)
            for ((fn, txt) in listOf("$name.obj" to obj, "$name.mtl" to mtl)) {
                find(fn)?.delete()
                val out = d.createFile("application/octet-stream", fn)!!
                contentResolver.openOutputStream(out.uri)!!.use { it.write(txt.toByteArray()) }
            }
            for (m in ps.map { it.mat }.distinct()) {   // soraty ny PNG vaovao (texture nampidirina)
                val tn = m.tex; val b = m.bmp
                if (tn != null && b != null && find(tn) == null) {
                    val tf = d.createFile("image/png", tn)!!
                    contentResolver.openOutputStream(tf.uri)!!.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
            }
            toast("Vita: $name.obj + .mtl (${ps.size} objet)")
        } catch (e: Exception) { toast("Olana export: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
