package com.mervolt.edits

import kotlin.math.*

/** Mamorona ny endriky ny terrain manodidina ny lalana: plate 5 m, avy eo profil (havoana / mianjera) amin'ny sisiny roa, ary rampe (Fiakarana / Fidinana). */
object Gen {
    var flat = 5f
    val names = arrayOf("Havoana havanana", "Havoana havia", "Midina roa tonta", "Miakatra roa tonta")

    private class Nr(val d: Float, val lat: Float, val i: Int, val u: Float, val beyS: Float, val beyE: Float)
    private fun sm(x: Float) = x * x * (3 - 2 * x)

    private fun nearest(rs: List<Row>, x: Float, z: Float): Nr {
        var bd = 1e18f; var bi = 0; var bu = 0f; var lat = 0f; var bt = 0f; var bl = 1f
        for (q in 0 until rs.size - 1) {
            val a = rs[q]; val b = rs[q + 1]; val dx = b.cx - a.cx; val dz = b.cz - a.cz; val l2 = dx * dx + dz * dz
            if (l2 < 1e-9f) continue
            val t = ((x - a.cx) * dx + (z - a.cz) * dz) / l2; val u = t.coerceIn(0f, 1f)
            val px = a.cx + dx * u; val pz = a.cz + dz * u
            val d2 = (x - px) * (x - px) + (z - pz) * (z - pz)
            if (d2 < bd) { bd = d2; bi = q; bu = u; bt = t; bl = sqrt(l2); lat = ((x - px) * -dz + (z - pz) * dx) / bl }
        }
        val beyS = if (bi == 0 && bt < 0) -bt * bl else 0f
        val beyE = if (bi == rs.size - 2 && bt > 1) (bt - 1) * bl else 0f
        return Nr(sqrt(bd), lat, bi, bu, beyS, beyE)
    }

    /** rs = lalana (andalana 1 m). dir: 0 Mitovy, 1 Fiakarana, 2 Fidinana. grade = m isaky ny 100 m.
     *  startH != null = mitohy amin'ny generate teo aloha (manomboka amin'ny haavony farany, tsy milatsaka). others = generate teo aloha (tsy simbana). */
    fun apply(ts: List<Terrain>, rs: List<Row>, profile: Int, dir: Int, grade: Float, hf: (Float, Float) -> Float, others: List<List<Row>>, startH: Float?, joinStart: Boolean) =
        applyS(ts.map { TerrainSurf(it) }, rs, profile, dir, grade, hf, others, startH, joinStart)

    /** Mitovy amin'ny apply fa miasa amin'ny Surf (Terrain na mesh nampidirina). */
    fun applyS(ts: List<Surf>, rs: List<Row>, profile: Int, dir: Int, grade: Float, hf: (Float, Float) -> Float, others: List<List<Row>>, startH: Float?, joinStart: Boolean) {
        val n = rs.size; if (n < 2) return
        val slope = (when (dir) { 1 -> 1f; 2 -> -1f; else -> 0f }) * grade / 100f
        val base = FloatArray(n) { hf(rs[it].cx, rs[it].cz) }
        val sm8 = FloatArray(n) { i -> var s = 0f; var c = 0; for (k in max(0, i - 8)..min(n - 1, i + 8)) { s += base[k]; c++ }; s / c }
        val hc = FloatArray(n) { (startH ?: sm8[it]) + slope * rs[it].s }
        val half = Road.width / 2 + flat; val reach = 60f; val tw = half + 12f
        val minx = rs.minOf { it.cx } - reach; val maxx = rs.maxOf { it.cx } + reach; val minz = rs.minOf { it.cz } - reach; val maxz = rs.maxOf { it.cz } + reach
        val aff = HashMap<Surf, ArrayList<Pair<Int, Float>>>()
        for (t in ts) for (k in 0 until t.count) {
            val x = t.x(k); val z = t.z(k)
            if (x < minx || x > maxx || z < minz || z > maxz) continue
            val nr = nearest(rs, x, z); val a = nr.d; if (a > reach) continue
            var skip = false
            for (o in others) if (o.size >= 2 && nearest(o, x, z).d + 0.5f < a) { skip = true; break }
            if (skip) continue
            val hcAt = hc[nr.i] + (hc[nr.i + 1] - hc[nr.i]) * nr.u
            val m = max(0f, a - half)
            val e = m - 6f * (1 - exp(-m / 6f))                              // fanombohana malama
            val sf = tanh(nr.lat / 2.5f)                                      // sisiny malama (tsy misy fiovan'ny sisiny tampoka)
            val hw = when (profile) { 0 -> (1 + sf) / 2; 1 -> (1 - sf) / 2; 2 -> 0f; else -> 1f }
            val off = hw * 14f * tanh(0.55f * e / 14f) - (1 - hw) * 10f * tanh(0.45f * e / 10f)
            val noise = (sin(x * 0.13f) * cos(z * 0.17f) + 0.5f * sin(x * 0.31f + z * 0.23f)) * min(1f, m / 15f) * 1.2f
            val w0 = if (a <= 30f) 1f else { val u = ((a - 30f) / (reach - 30f)).coerceIn(0f, 1f); 1 - sm(u) }
            val bey = max(if (joinStart) 0f else nr.beyS, nr.beyE)
            val w = w0 * (1 - sm((bey / tw).coerceIn(0f, 1f)))                // ny tendrony: miverina malemy amin'ny tany (tsy milentika)
            t.set(k, t.h(k) * (1 - w) + (hcAt + off + noise) * w)
            aff.getOrPut(t) { ArrayList() }.add(k to a)
        }
        repeat(2) {   // famafana ivelan'ny lalana
            for ((t, l) in aff) {
                val upd = ArrayList<Pair<Int, Float>>()   // kajy aloha (avy amin'ny haavo taloha) vao soratana: tsy misy triatra eo amin'ny vertex mitovy toerana
                for ((k, a) in l) { if (a <= half) continue; upd.add(k to (t.h(k) * 0.5f + t.avg(k) * 0.5f)) }
                for ((k, v) in upd) t.set(k, v)
            }
        }
    }
}
