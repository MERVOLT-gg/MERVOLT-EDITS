package com.mervolt.edits

import kotlin.math.*

/** Grid 2D (x,z) ho an'ny triangle rehetra: mamerina ny haavon'ny tampon'ny mesh (ambony indrindra) amin'ny (x,z) haingana.
 *  Mitazona ny array an'ny Part (tsy mandika) ka manaraka ny sculpt. Averina atsangana raha mihetsika/mihodina/miova habe ny objet. */
class HeightGrid(val parts: List<Part>) {
    private val x0: Float; private val z0: Float; private val cell: Float; private val nx: Int; private val nz: Int
    private val start: IntArray; private val refP: IntArray; private val refT: IntArray
    /** halavan'ny sisiny antonony (x,z) - ampiasaina amin'ny Smooth */
    val edge: Float

    init {
        var mnx = 1e18f; var mnz = 1e18f; var mxx = -1e18f; var mxz = -1e18f; var nt = 0
        for (p in parts) {
            for (i in 0 until p.pos.size / 3) { val x = p.pos[i * 3]; val z = p.pos[i * 3 + 2]
                if (x < mnx) mnx = x; if (x > mxx) mxx = x; if (z < mnz) mnz = z; if (z > mxz) mxz = z }
            nt += p.idx.size / 3
        }
        if (nt == 0) { mnx = 0f; mnz = 0f; mxx = 1f; mxz = 1f }
        x0 = mnx; z0 = mnz
        val sx = max(mxx - mnx, 1e-3f); val sz = max(mxz - mnz, 1e-3f)
        var c = (sqrt(sx * sz / max(nt, 1)) * 2f).coerceIn(0.5f, 30f)
        while ((sx / c + 1) * (sz / c + 1) > 4e6f) c *= 1.5f
        var gx: Int; var gz: Int; var st: IntArray
        while (true) {
            gx = (sx / c).toInt() + 1; gz = (sz / c).toInt() + 1
            st = IntArray(gx * gz + 1)
            var tot = 0L
            for (p in parts) for (t in 0 until p.idx.size / 3) {
                val r = range(p, t, c, gx, gz)
                for (j in r[1]..r[3]) for (i in r[0]..r[2]) { st[j * gx + i + 1]++; tot++ }
            }
            if (tot > 12_000_000L) c *= 2f else break
        }
        cell = c; nx = gx; nz = gz
        for (k in 1 until st.size) st[k] += st[k - 1]
        start = st
        refP = IntArray(st[st.size - 1]); refT = IntArray(st[st.size - 1])
        val fill = IntArray(gx * gz)
        for ((pi, p) in parts.withIndex()) for (t in 0 until p.idx.size / 3) {
            val r = range(p, t, c, gx, gz)
            for (j in r[1]..r[3]) for (i in r[0]..r[2]) { val cc = j * gx + i; val q = st[cc] + fill[cc]++; refP[q] = pi; refT[q] = t }
        }
        var sum = 0f; var cnt = 0
        val step = max(1, nt / 2000)
        var tt = 0
        for (p in parts) { var t = 0
            while (t < p.idx.size / 3) { if (tt % step == 0) {
                val a = p.idx[t * 3] * 3; val b = p.idx[t * 3 + 1] * 3; val d = p.idx[t * 3 + 2] * 3
                sum += hypot(p.pos[b] - p.pos[a], p.pos[b + 2] - p.pos[a + 2]) + hypot(p.pos[d] - p.pos[b], p.pos[d + 2] - p.pos[b + 2]) + hypot(p.pos[a] - p.pos[d], p.pos[a + 2] - p.pos[d + 2]); cnt += 3 }
                tt++; t++ } }
        edge = if (cnt > 0) (sum / cnt).coerceIn(0.25f, 15f) else 1f
    }

    private fun range(p: Part, t: Int, c: Float, gx: Int, gz: Int): IntArray {
        val a = p.idx[t * 3] * 3; val b = p.idx[t * 3 + 1] * 3; val d = p.idx[t * 3 + 2] * 3
        val lx = min(p.pos[a], min(p.pos[b], p.pos[d])); val hx = max(p.pos[a], max(p.pos[b], p.pos[d]))
        val lz = min(p.pos[a + 2], min(p.pos[b + 2], p.pos[d + 2])); val hz = max(p.pos[a + 2], max(p.pos[b + 2], p.pos[d + 2]))
        return intArrayOf(((lx - x0) / c).toInt().coerceIn(0, gx - 1), ((lz - z0) / c).toInt().coerceIn(0, gz - 1),
            ((hx - x0) / c).toInt().coerceIn(0, gx - 1), ((hz - z0) / c).toInt().coerceIn(0, gz - 1))
    }

    /** Haavon'ny tampon'ny mesh ambony indrindra amin'ny (x,z); null raha tsy misy mesh eo. */
    fun top(x: Float, z: Float): Float? {
        if (x < x0 || z < z0) return null
        val ix = ((x - x0) / cell).toInt(); val iz = ((z - z0) / cell).toInt()
        if (ix >= nx || iz >= nz) return null
        val c = iz * nx + ix; var best = -1e18f; var hit = false
        for (q in start[c] until start[c + 1]) {
            val p = parts[refP[q]]; val t = refT[q] * 3
            val a = p.idx[t] * 3; val b = p.idx[t + 1] * 3; val d = p.idx[t + 2] * 3
            val ax = p.pos[a]; val az = p.pos[a + 2]
            val v0x = p.pos[b] - ax; val v0z = p.pos[b + 2] - az; val v1x = p.pos[d] - ax; val v1z = p.pos[d + 2] - az
            val den = v0x * v1z - v1x * v0z; if (abs(den) < 1e-12f) continue
            val v2x = x - ax; val v2z = z - az
            val u = (v2x * v1z - v1x * v2z) / den; val v = (v0x * v2z - v2x * v0z) / den
            if (u >= -1e-4f && v >= -1e-4f && u + v <= 1f + 1e-4f) {
                val y = p.pos[a + 1] + u * (p.pos[b + 1] - p.pos[a + 1]) + v * (p.pos[d + 1] - p.pos[a + 1])
                if (y > best) { best = y; hit = true }
            }
        }
        return if (hit) best else null
    }
}

/** Cache an'ny HeightGrid ho an'ny lisitry ny objet (averina atsangana raha misy fiovana: mihetsika, mihodina, habe, na invalidate()). */
class GridCache(private val src: () -> List<Obj3>) {
    private var list: List<Obj3>? = null; private var g: HeightGrid? = null; private var sg = 0L
    fun invalidate() { list = null }
    fun objs(): List<Obj3> { var l = list; if (l == null) { l = src(); list = l; g = null }; return l }
    fun grid(): HeightGrid? {
        val l = objs(); if (l.isEmpty()) return null
        var s = 17L
        for (o in l) { s = s * 31 + System.identityHashCode(o); s = s * 31 + o.x.toBits(); s = s * 31 + o.y.toBits(); s = s * 31 + o.z.toBits()
            s = s * 31 + o.yaw.toBits(); s = s * 31 + o.scale.toBits(); s = s * 31 + o.parts.size }
        if (g == null || s != sg) { g = HeightGrid(l.flatMap { it.parts }); sg = s }
        return g
    }
}

/** Fisakafoana ho an'ny mesh (terrain): Gen.applyS miasa amin'ny Surf, na Terrain na mesh nampidirina. */
interface Surf {
    val count: Int
    fun x(k: Int): Float
    fun z(k: Int): Float
    fun h(k: Int): Float
    fun set(k: Int, v: Float)
    /** salanan'ny haavon'ny mpifanolo (tsy manoratra) */
    fun avg(k: Int): Float
}

class TerrainSurf(val t: Terrain) : Surf {
    override val count get() = t.n * t.n
    override fun x(k: Int) = t.ox + t.cc(k % t.n)
    override fun z(k: Int) = t.oz + t.cc(k / t.n)
    override fun h(k: Int) = t.h[k]
    override fun set(k: Int, v: Float) = t.setH(k, v)
    override fun avg(k: Int): Float {
        val n = t.n; val i = k % n; val j = k / n; val h = t.h
        return (h[j * n + max(i - 1, 0)] + h[j * n + min(i + 1, n - 1)] + h[max(j - 1, 0) * n + i] + h[min(j + 1, n - 1) * n + i]) / 4f
    }
}

/** Mesh nampidirina (terrain): ny vertex rehetra amin'ny objet voafidy. set() manova ny world (pos) sy ny base (tahirin-kevitra) miaraka. */
class MeshSurf(val obs: List<Obj3>, val g: HeightGrid) : Surf {
    private val ps = obs.flatMap { ob -> ob.parts.indices.map { ob to it } }
    private val off = IntArray(ps.size + 1).also { for (i in ps.indices) it[i + 1] = it[i] + ps[i].first.parts[ps[i].second].pos.size / 3 }
    override val count get() = off[ps.size]
    private fun loc(k: Int): Int { var lo = 0; var hi = ps.size - 1
        while (lo < hi) { val m = (lo + hi + 1) / 2; if (off[m] <= k) lo = m else hi = m - 1 }; return lo }
    override fun x(k: Int): Float { val i = loc(k); return ps[i].first.parts[ps[i].second].pos[(k - off[i]) * 3] }
    override fun z(k: Int): Float { val i = loc(k); return ps[i].first.parts[ps[i].second].pos[(k - off[i]) * 3 + 2] }
    override fun h(k: Int): Float { val i = loc(k); return ps[i].first.parts[ps[i].second].pos[(k - off[i]) * 3 + 1] }
    override fun set(k: Int, v: Float) {
        val i = loc(k); val (ob, pi) = ps[i]; val q = (k - off[i]) * 3 + 1
        val pos = ob.parts[pi].pos; val old = pos[q]; pos[q] = v; ob.base[pi][q] += (v - old) / ob.scale
    }
    override fun avg(k: Int): Float {
        val x = x(k); val z = z(k); val y = h(k); val e = g.edge
        return ((g.top(x + e, z) ?: y) + (g.top(x - e, z) ?: y) + (g.top(x, z + e) ?: y) + (g.top(x, z - e) ?: y)) / 4f
    }
}

object MeshOps {
    private class Hit(val ob: Obj3, val pi: Int, val ks: IntArray, val ys: FloatArray, val n: Int)

    /** Sculpt amin'ny mesh nampidirina (terrain). mode: 0 Raise, 1 Lower, 2 Smooth. Mamerina ny Part niova (hanavaozana ny GL).
     *  Ny fiovana dia ny y ihany ary fiasan'ny (x,z) ihany ka tsy misy triatra eo amin'ny vertex mitovy toerana. */
    fun sculpt(obs: List<Obj3>, g: HeightGrid, px: Float, pz: Float, r: Float, s: Float, mode: Int): List<Part> {
        val hits = ArrayList<Hit>(); val e = g.edge
        for (ob in obs) for ((pi, p) in ob.parts.withIndex()) {
            val pos = p.pos; var ks = IntArray(64); var ys = FloatArray(64); var n = 0
            for (k in 0 until pos.size / 3) {
                val x = pos[k * 3]; val z = pos[k * 3 + 2]
                if (x - px > r || px - x > r || z - pz > r || pz - z > r) continue
                val d = hypot(x - px, z - pz); if (d >= r) continue
                val f = 1 - d / r; val w = f * f * (3 - 2 * f); val y = pos[k * 3 + 1]
                val ny = when (mode) {
                    0 -> y + s * w
                    1 -> y - s * w
                    else -> { val avg = ((g.top(x + e, z) ?: y) + (g.top(x - e, z) ?: y) + (g.top(x, z + e) ?: y) + (g.top(x, z - e) ?: y)) / 4f
                        y + (avg - y) * min(1f, w * 0.6f) }
                }
                if (n == ks.size) { ks = ks.copyOf(n * 2); ys = ys.copyOf(n * 2) }
                ks[n] = k; ys[n] = ny; n++
            }
            if (n > 0) hits.add(Hit(ob, pi, ks, ys, n))
        }
        val out = ArrayList<Part>()
        for (h in hits) {
            val p = h.ob.parts[h.pi]; val b = h.ob.base[h.pi]; val inv = 1f / h.ob.scale
            for (q in 0 until h.n) { val k = h.ks[q]; val old = p.pos[k * 3 + 1]; p.pos[k * 3 + 1] = h.ys[q]; b[k * 3 + 1] += (h.ys[q] - old) * inv }
            out.add(p)
        }
        return out
    }

    /** Ray (o,d) amin'ny triangle rehetra (miandalana roa): halavirana akaiky indrindra na null. */
    fun ray(o: FloatArray, d: FloatArray, parts: List<Part>): Float? {
        var best = 1e18f
        for (p in parts) for (t in 0 until p.idx.size / 3) {
            val a = p.idx[t * 3] * 3; val b = p.idx[t * 3 + 1] * 3; val c = p.idx[t * 3 + 2] * 3
            val ax = p.pos[a]; val ay = p.pos[a + 1]; val az = p.pos[a + 2]
            val e1x = p.pos[b] - ax; val e1y = p.pos[b + 1] - ay; val e1z = p.pos[b + 2] - az
            val e2x = p.pos[c] - ax; val e2y = p.pos[c + 1] - ay; val e2z = p.pos[c + 2] - az
            val hx = d[1] * e2z - d[2] * e2y; val hy = d[2] * e2x - d[0] * e2z; val hz = d[0] * e2y - d[1] * e2x
            val det = e1x * hx + e1y * hy + e1z * hz; if (abs(det) < 1e-12f) continue
            val iv = 1f / det; val sx = o[0] - ax; val sy = o[1] - ay; val sz = o[2] - az
            val u = (sx * hx + sy * hy + sz * hz) * iv; if (u < 0f || u > 1f) continue
            val qx = sy * e1z - sz * e1y; val qy = sz * e1x - sx * e1z; val qz = sx * e1y - sy * e1x
            val v = (d[0] * qx + d[1] * qy + d[2] * qz) * iv; if (v < 0f || u + v > 1f) continue
            val tt = (e2x * qx + e2y * qy + e2z * qz) * iv
            if (tt > 1e-4f && tt < best) best = tt
        }
        return if (best < 1e17f) best else null
    }

    // ---------- Afovoan'ny road avy amin'ny mesh ----------
    private val DX = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)
    private val DZ = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)

    /** Mitady ny tsipika afovoany (x,z) an'ny road avy amin'ny triangle: raster -> famenoana lavaka kely -> skeleton (Zhang-Suen) -> lalana.
     *  Ny lalana dia voaravaka ary voasokajy (~2 m isaky ny teboka), mifanaraka amin'ny Road.traffic. */
    fun centerlines(parts: List<Part>): List<List<FloatArray>> {
        var x0 = 1e18f; var z0 = 1e18f; var x1 = -1e18f; var z1 = -1e18f; var nt = 0
        for (p in parts) {
            for (i in 0 until p.pos.size / 3) { val x = p.pos[i * 3]; val z = p.pos[i * 3 + 2]
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (z < z0) z0 = z; if (z > z1) z1 = z }
            nt += p.idx.size / 3
        }
        if (nt == 0) return emptyList()
        val ext = max(x1 - x0, z1 - z0); var c = 0.5f; if (ext / c > 2200f) c = ext / 2200f
        val pad = 3
        val w = ((x1 - x0) / c).toInt() + 1 + 2 * pad; val h = ((z1 - z0) / c).toInt() + 1 + 2 * pad
        val m = ByteArray(w * h)

        // 1) raster
        for (p in parts) for (t in 0 until p.idx.size / 3) {
            val a = p.idx[t * 3] * 3; val b = p.idx[t * 3 + 1] * 3; val d = p.idx[t * 3 + 2] * 3
            val ax = (p.pos[a] - x0) / c + pad; val az = (p.pos[a + 2] - z0) / c + pad
            val bx = (p.pos[b] - x0) / c + pad; val bz = (p.pos[b + 2] - z0) / c + pad
            val cx = (p.pos[d] - x0) / c + pad; val cz = (p.pos[d + 2] - z0) / c + pad
            val lx = floor(min(ax, min(bx, cx))).toInt().coerceIn(1, w - 2); val hx = floor(max(ax, max(bx, cx))).toInt().coerceIn(1, w - 2)
            val lz = floor(min(az, min(bz, cz))).toInt().coerceIn(1, h - 2); val hz = floor(max(az, max(bz, cz))).toInt().coerceIn(1, h - 2)
            val den = (bx - ax) * (cz - az) - (cx - ax) * (bz - az)
            var any = false
            if (abs(den) > 1e-9f) for (j in lz..hz) for (i in lx..hx) {
                val qx = i + 0.5f; val qz = j + 0.5f
                val u = ((qx - ax) * (cz - az) - (cx - ax) * (qz - az)) / den; val v = ((bx - ax) * (qz - az) - (qx - ax) * (bz - az)) / den
                if (u >= -0.02f && v >= -0.02f && u + v <= 1.02f) { m[j * w + i] = 1; any = true }
            }
            if (!any) { val gi = ((ax + bx + cx) / 3).toInt().coerceIn(1, w - 2); val gj = ((az + bz + cz) / 3).toInt().coerceIn(1, h - 2); m[gj * w + gi] = 1 }
        }

        // 2) famenoana lavaka kely (< ~4 m2) ao anaty road
        val q = IntArray(w * h); val seen = ByteArray(w * h); val holeMax = max(8, (4f / (c * c)).toInt())
        for (s in 0 until w * h) if (m[s].toInt() == 0 && seen[s].toInt() == 0) {
            var hd = 0; var tl = 0; q[tl++] = s; seen[s] = 1; var border = false
            while (hd < tl) {
                val v = q[hd++]; val vx = v % w; val vz = v / w
                if (vx == 0 || vz == 0 || vx == w - 1 || vz == h - 1) border = true
                if (vx > 0 && m[v - 1].toInt() == 0 && seen[v - 1].toInt() == 0) { seen[v - 1] = 1; q[tl++] = v - 1 }
                if (vx < w - 1 && m[v + 1].toInt() == 0 && seen[v + 1].toInt() == 0) { seen[v + 1] = 1; q[tl++] = v + 1 }
                if (vz > 0 && m[v - w].toInt() == 0 && seen[v - w].toInt() == 0) { seen[v - w] = 1; q[tl++] = v - w }
                if (vz < h - 1 && m[v + w].toInt() == 0 && seen[v + w].toInt() == 0) { seen[v + w] = 1; q[tl++] = v + w }
            }
            if (!border && tl <= holeMax) for (e in 0 until tl) m[q[e]] = 1
        }
        val mask = m.copyOf(); var fg = 0; for (v in m) if (v.toInt() != 0) fg++
        if (fg == 0) return emptyList()

        // 3) skeleton
        val sk = thin(m, w)
        if (sk.isEmpty()) return emptyList()

        // 4) lalana
        class P(val px: IntArray, val d0: Int, val d1: Int, val closed: Boolean)
        val deg = ByteArray(w * h); val tmp = IntArray(8); val tmp2 = IntArray(8)
        fun nb(i: Int, out: IntArray): Int { var n = 0; for (d in 0..7) { val j = i + DZ[d] * w + DX[d]; if (m[j].toInt() != 0) out[n++] = j }; return n }
        for (i in sk) deg[i] = nb(i, tmp).toByte()
        val vis = ByteArray(w * h); val paths = ArrayList<P>()
        fun walk(s: Int, first: Int): P {
            val l = ArrayList<Int>(); l.add(s); l.add(first); vis[first] = 1; var prev = s; var cur = first
            while (deg[cur].toInt() == 2) {
                val cn = nb(cur, tmp2); var nxt = -1
                for (z in 0 until cn) { val cand = tmp2[z]; if (cand == prev) continue; if (deg[cand].toInt() != 2 || vis[cand].toInt() == 0) { nxt = cand; break } }
                if (nxt < 0) break
                l.add(nxt); if (deg[nxt].toInt() != 2) break
                vis[nxt] = 1; prev = cur; cur = nxt
            }
            return P(l.toIntArray(), deg[s].toInt(), deg[l[l.size - 1]].toInt(), false)
        }
        for (s in sk) if (deg[s].toInt() != 2 && deg[s].toInt() != 0) {
            val cn = nb(s, tmp)
            for (k in 0 until cn) { val f = tmp[k]; if (deg[f].toInt() != 2 || vis[f].toInt() != 0) continue; paths.add(walk(s, f)) }
        }
        for (s in sk) if (deg[s].toInt() == 2 && vis[s].toInt() == 0) {   // peratra tsy misy fihaonana
            val l = ArrayList<Int>(); l.add(s); vis[s] = 1; var cur = s
            while (true) {
                val cn = nb(cur, tmp2); var nxt = -1
                for (z in 0 until cn) if (vis[tmp2[z]].toInt() == 0 && deg[tmp2[z]].toInt() == 2) { nxt = tmp2[z]; break }
                if (nxt < 0) break
                l.add(nxt); vis[nxt] = 1; cur = nxt
            }
            if (l.size > 6) { l.add(s); paths.add(P(l.toIntArray(), 2, 2, true)) }
        }
        if (paths.isEmpty()) return emptyList()

        fun plen(px: IntArray): Float { var s = 0f; for (k in 1 until px.size) { val dx = px[k] % w - px[k - 1] % w; val dz = px[k] / w - px[k - 1] / w; s += if (dx != 0 && dz != 0) 1.4142135f else 1f }; return s * c }
        val total = paths.sumOf { plen(it.px).toDouble() }.toFloat()
        val wEst = if (total > 0f) fg * c * c / total else 4f
        val spur = max(2f, wEst * 0.9f)

        val out = ArrayList<List<FloatArray>>()
        for (pa in paths) {
            val len = plen(pa.px)
            val spurEnd = (pa.d0 == 1) != (pa.d1 == 1) && (pa.d0 >= 3 || pa.d1 >= 3)
            if (spurEnd && len < spur) continue
            if (pa.d0 == 1 && pa.d1 == 1 && len < max(3f, wEst)) continue
            var pts = pa.px.map { floatArrayOf(x0 + (it % w - pad + 0.5f) * c, z0 + (it / w - pad + 0.5f) * c) }
            repeat(2) {   // famafana (tendrony tsy mihetsika)
                val a = pts; val n = a.size
                pts = List(n) { i -> if (i == 0 || i == n - 1) a[i] else { val r = min(2, min(i, n - 1 - i)); var sx = 0f; var sz = 0f
                    for (k in i - r..i + r) { sx += a[k][0]; sz += a[k][1] }; floatArrayOf(sx / (2 * r + 1), sz / (2 * r + 1)) } }
            }
            // sokajy ~2 m
            val rs = ArrayList<FloatArray>(); rs.add(pts[0]); var acc = 0f; val step = 2f
            for (i in 1 until pts.size) {
                val seg = hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); acc += seg
                if (acc >= step) { rs.add(pts[i]); acc = 0f }
            }
            if (hypot(rs.last()[0] - pts.last()[0], rs.last()[1] - pts.last()[1]) > 0.3f) rs.add(pts.last())
            if (rs.size < 2) continue
            // manitatra ny tendrony malalaka (ny skeleton dia mihena ~ antsasaky ny sakany)
            fun inMask(x: Float, z: Float): Boolean { val ix = ((x - x0) / c).toInt() + pad; val iz = ((z - z0) / c).toInt() + pad
                return ix in 0 until w && iz in 0 until h && mask[iz * w + ix].toInt() != 0 }
            fun extend(a: FloatArray, b: FloatArray): FloatArray? {   // b = tendrony, a = teboka teo aloha
                val dx = b[0] - a[0]; val dz = b[1] - a[1]; val l = hypot(dx, dz); if (l < 1e-4f) return null
                var x = b[0]; var z = b[1]; var run = 0f; val mx = min(wEst * 0.6f, 5f)
                while (run + c * 0.5f <= mx && inMask(x + dx / l * c * 0.5f, z + dz / l * c * 0.5f)) { x += dx / l * c * 0.5f; z += dz / l * c * 0.5f; run += c * 0.5f }
                return if (run >= 0.5f) floatArrayOf(x, z) else null
            }
            val ps = rs.toMutableList()
            if (pa.d0 == 1 && !pa.closed) extend(ps[min(2, ps.size - 1)], ps[0])?.let { ps.add(0, it) }
            if (pa.d1 == 1 && !pa.closed) extend(ps[max(ps.size - 3, 0)], ps[ps.size - 1])?.let { ps.add(it) }
            // fironana mitovy foana (ho an'ny Lane+/Lane-)
            val dxs = ps.last()[0] - ps.first()[0]; val dzs = ps.last()[1] - ps.first()[1]
            if (!pa.closed && dxs + 0.01f * dzs < 0f) ps.reverse()
            out.add(ps)
        }
        return out
    }

    /** Zhang-Suen + fanadiovana ny zoro "L": miverina ny lisitry ny pixel (index) amin'ny skeleton. */
    private fun thin(m: ByteArray, w: Int): IntArray {
        var n = 0; var cur = IntArray(1024)
        for (i in m.indices) if (m[i].toInt() != 0) { if (n == cur.size) cur = cur.copyOf(n * 2); cur[n++] = i }
        val del = IntArray(max(n, 1))
        var changed = true
        while (changed) {
            changed = false
            for (sub in 0..1) {
                var nd = 0
                for (e in 0 until n) {
                    val i = cur[e]
                    val p2 = m[i - w].toInt(); val p3 = m[i - w + 1].toInt(); val p4 = m[i + 1].toInt(); val p5 = m[i + w + 1].toInt()
                    val p6 = m[i + w].toInt(); val p7 = m[i + w - 1].toInt(); val p8 = m[i - 1].toInt(); val p9 = m[i - w - 1].toInt()
                    val b = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9
                    if (b < 2 || b > 6) continue
                    var a = 0
                    if (p2 == 0 && p3 == 1) a++; if (p3 == 0 && p4 == 1) a++; if (p4 == 0 && p5 == 1) a++; if (p5 == 0 && p6 == 1) a++
                    if (p6 == 0 && p7 == 1) a++; if (p7 == 0 && p8 == 1) a++; if (p8 == 0 && p9 == 1) a++; if (p9 == 0 && p2 == 1) a++
                    if (a != 1) continue
                    if (sub == 0) { if (p2 * p4 * p6 != 0 || p4 * p6 * p8 != 0) continue } else { if (p2 * p4 * p8 != 0 || p2 * p6 * p8 != 0) continue }
                    del[nd++] = i
                }
                if (nd > 0) {
                    changed = true; for (e in 0 until nd) m[del[e]] = 0
                    var k = 0; for (e in 0 until n) if (m[cur[e]].toInt() != 0) cur[k++] = cur[e]; n = k
                }
            }
        }
        // fanadiovana: esorina ny pixel "simple" rehetra (tsy tendrony) ka tsy mamaky ny fifandraisana -> tsipika 8-connected 1 pixel (tsy misy zoro/diagonal 2 pixel)
        val ex = IntArray(8); val ez = IntArray(8); val par = IntArray(8)
        fun find(a: Int): Int { var r = a; while (par[r] != r) r = par[r]; return r }
        var again = true; var guard = 0
        while (again && guard < 8) {
            again = false; guard++
            for (e in 0 until n) {
                val i = cur[e]; if (m[i].toInt() == 0) continue
                var cnt = 0
                for (d in 0..7) if (m[i + DZ[d] * w + DX[d]].toInt() != 0) { ex[cnt] = DX[d]; ez[cnt] = DZ[d]; cnt++ }
                if (cnt < 2) continue
                for (a in 0 until cnt) par[a] = a
                for (a in 0 until cnt) for (b in a + 1 until cnt) if (max(abs(ex[a] - ex[b]), abs(ez[a] - ez[b])) <= 1) { val ra = find(a); val rb = find(b); if (ra != rb) par[ra] = rb }
                var comps = 0; for (a in 0 until cnt) if (find(a) == a) comps++
                if (comps == 1) { m[i] = 0; again = true }
            }
            var k = 0; for (e in 0 until n) if (m[cur[e]].toInt() != 0) cur[k++] = cur[e]; n = k
        }
        return cur.copyOf(n)
    }
}
