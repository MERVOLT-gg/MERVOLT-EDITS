# Terrain3D

Application Android (Kotlin + OpenGL ES 3) hanaovana terrain 3D, hanaovana lalana mivantana eo amin'ny terrain, ary hamoahana `.obj`.

## Fampiasana

| Bokotra | Asa |
|---|---|
| **Camera** | 1 rantsantanana = mihodina. 2 rantsantanana = pinch (zoom), mihodina (twist) ary mifindra (drag) |
| **Asandrato / Ahenao / Malamao / Fisaka** | Sculpt: tsindrio na alaviro eo amin'ny terrain. Mbola mihodina/mizoom amin'ny 2 rantsantanana foana |
| **Lalana** | Soraty amin'ny rantsantanana ny lalana. Ny terrain ihany no tapahina ho lalana (mesh hafa, texture hafa) |
| **Fafao lalana** | Tsindrio ny lalana hofafana |
| **Undo** | Mamerina ny fanovana farany (hatramin'ny 15) |
| **Vaovao** | Terrain vaovao (foana ny lalana) |
| **Export OBJ** | Manoratra ao amin'ny `Download/Terrain3D_<daty>/`: `terrain.obj`, `terrain.mtl`, `terrain.png`, `road.png` |

Sliders: habe ny brush, hery, sakan'ny lalana.

### Fitohizan'ny lalana
Rehefa manomboka na mamarana lalana vaovao ianao akaiky (~4 unit) tendron'ny lalana efa misy, mifandrohy ho azy izy (mitovy tangent, mitambatra ho lalana iray). Raha akaiky ny afovoan'ny lalana, dia T-junction. Misy teboka mena mipoitra rehefa hifandrohy.

## Fanamboarana APK amin'ny GitHub Actions

1. Mamoròna repository vaovao ao amin'ny GitHub.
2. Ao amin'ny lahatahiry ity project ity:
   ```
   git init
   git add .
   git commit -m "Terrain3D"
   git branch -M main
   git remote add origin https://github.com/<anaranao>/<repo>.git
   git push -u origin main
   ```
3. Ao amin'ny GitHub: **Actions → Build APK**. Rehefa vita (3-6 minitra), misokatra ny run dia hita ao ambany ny **Artifacts → Terrain3D-debug-apk**. Alaivo ilay zip, ao anatiny ny `app-debug.apk`.
4. Alefaso ao amin'ny finday ary apetraho (alefaso "Install unknown apps" raha ilaina).

Azo atao koa ny manao build amin'ny tanana: **Actions → Build APK → Run workflow**.

## Fanamarihana
- Android 10+ (minSdk 29).
- Debug APK ity (tsy mila keystore). Raha mila release signed, ampiana ao amin'ny workflow ny keystore amin'ny GitHub Secrets.
- Ny workflow dia mampiasa Gradle 8.7 mivantana (tsy mila `gradlew`).
