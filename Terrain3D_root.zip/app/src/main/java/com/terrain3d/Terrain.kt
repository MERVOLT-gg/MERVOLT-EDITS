package com.terrain3d

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Heightmap grid. Ity no "source tokana": ny mesh rehetra (terrain + lalana)
 * dia averina amboarina avy amin'ity isaky ny misy fanovana.
 */
class Terrain {
    companion object {
        const val N = 257                    // isan'ny vertex isaky ny sisiny
        const val CELLS = N - 1
        const val SIZE = 100f                // habe eo amin'ny tontolo (unit)
        const val HALF = SIZE / 2f
        const val CELL = SIZE / CELLS
        const val CHUNK_CELLS = 32
        const val CHUNKS = CELLS / CHUNK_CELLS   // 8
        const val MIN_H = -5f
        const val MAX_H = 40f

        const val BR_RAISE = 0
        const val BR_LOWER = 1
        const val BR_SMOOTH = 2
        const val BR_FLAT = 3

        /** Haavo bilinear avy amin'ny array heightmap. */
        fun sample(h: FloatArray, x: Float, z: Float): Float {
            val fx = ((x + HALF) / CELL).coerceIn(0f, CELLS - 0.001f)
            val fz = ((z + HALF) / CELL).coerceIn(0f, CELLS - 0.001f)
            val i = fx.toInt()
            val j = fz.toInt()
            val tx = fx - i
            val tz = fz - j
            val a = h[j * N + i]
            val b = h[j * N + i + 1]
            val c = h[(j + 1) * N + i]
            val d = h[(j + 1) * N + i + 1]
            return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz
        }
    }

    var h = FloatArray(N * N)
    val nrm = FloatArray(N * N * 3)

    // Faritra vertex nisy fanovana farany (ho an'ny chunk dirty)
    var dI0 = 0
    var dI1 = 0
    var dJ0 = 0
    var dJ1 = 0

    init {
        generate(7)
    }

    fun heightAt(x: Float, z: Float): Float = sample(h, x, z)

    // ---------------------------------------------------------------- noise
    private fun hash(ix: Int, iz: Int, seed: Int): Float {
        var n = ix * 374761393 + iz * 668265263 + seed * 1274126177
        n = (n xor (n ushr 13)) * 1274126177
        n = n xor (n ushr 16)
        return (n and 0x7fffffff) / 2147483647f
    }

    private fun vnoise(x: Float, z: Float, seed: Int): Float {
        val x0 = floor(x).toInt()
        val z0 = floor(z).toInt()
        val fx = x - x0
        val fz = z - z0
        val sx = fx * fx * (3f - 2f * fx)
        val sz = fz * fz * (3f - 2f * fz)
        val a = hash(x0, z0, seed)
        val b = hash(x0 + 1, z0, seed)
        val c = hash(x0, z0 + 1, seed)
        val d = hash(x0 + 1, z0 + 1, seed)
        val top = a + (b - a) * sx
        val bot = c + (d - c) * sx
        return top + (bot - top) * sz
    }

    private fun fbm(x: Float, z: Float, seed: Int): Float {
        var amp = 0.5f
        var f = 1f
        var sum = 0f
        var norm = 0f
        for (o in 0 until 4) {
            sum += amp * vnoise(x * f, z * f, seed + o)
            norm += amp
            amp *= 0.5f
            f *= 2f
        }
        return sum / norm
    }

    fun generate(seed: Int) {
        for (j in 0 until N) {
            for (i in 0 until N) {
                val x = -HALF + i * CELL
                val z = -HALF + j * CELL
                val v = fbm(x * 0.035f + 31.7f, z * 0.035f + 12.3f, seed)
                h[j * N + i] = max(0f, (v - 0.32f) * 16f)
            }
        }
        updateNormals(0, N - 1, 0, N - 1)
    }

    // -------------------------------------------------------------- normals
    fun updateNormals(i0: Int, i1: Int, j0: Int, j1: Int) {
        val a0 = max(0, i0)
        val a1 = min(N - 1, i1)
        val b0 = max(0, j0)
        val b1 = min(N - 1, j1)
        for (j in b0..b1) {
            for (i in a0..a1) {
                val hl = h[j * N + max(i - 1, 0)]
                val hr = h[j * N + min(i + 1, N - 1)]
                val hd = h[max(j - 1, 0) * N + i]
                val hu = h[min(j + 1, N - 1) * N + i]
                val nx = (hl - hr) / (2f * CELL)
                val nz = (hd - hu) / (2f * CELL)
                val len = sqrt(nx * nx + 1f + nz * nz)
                val id = (j * N + i) * 3
                nrm[id] = nx / len
                nrm[id + 1] = 1f / len
                nrm[id + 2] = nz / len
            }
        }
    }

    // ---------------------------------------------------------------- brush
    /**
     * Mampihatra brush. Rehefa vita dia voasoratra ao amin'ny dI0..dJ1
     * ny faritra vertex nanovana.
     */
    fun brush(kind: Int, cx: Float, cz: Float, radius: Float, strength: Float, dt: Float, target: Float) {
        val i0 = max(0, floor((cx - radius + HALF) / CELL).toInt())
        val i1 = min(N - 1, ceil((cx + radius + HALF) / CELL).toInt())
        val j0 = max(0, floor((cz - radius + HALF) / CELL).toInt())
        val j1 = min(N - 1, ceil((cz + radius + HALF) / CELL).toInt())
        for (j in j0..j1) {
            for (i in i0..i1) {
                val x = -HALF + i * CELL
                val z = -HALF + j * CELL
                val d = hypot(x - cx, z - cz)
                if (d >= radius) continue
                val t = 1f - d / radius
                val f = t * t * (3f - 2f * t)
                val id = j * N + i
                var v = h[id]
                when (kind) {
                    BR_RAISE -> v += strength * 6f * dt * f
                    BR_LOWER -> v -= strength * 6f * dt * f
                    BR_SMOOTH -> {
                        val avg = (h[j * N + max(i - 1, 0)] + h[j * N + min(i + 1, N - 1)] +
                                h[max(j - 1, 0) * N + i] + h[min(j + 1, N - 1) * N + i]) * 0.25f
                        v += (avg - v) * min(1f, strength * 10f * dt * f)
                    }
                    BR_FLAT -> v += (target - v) * min(1f, strength * 10f * dt * f)
                }
                h[id] = v.coerceIn(MIN_H, MAX_H)
            }
        }
        dI0 = i0
        dI1 = i1
        dJ0 = j0
        dJ1 = j1
        updateNormals(i0 - 1, i1 + 1, j0 - 1, j1 + 1)
    }
}
