package com.terrain3d

/** Lisitra float mitombo ho azy (tsy mampiasa boxing). */
class FloatList(cap: Int = 1024) {
    var a = FloatArray(cap)
    var size = 0

    fun add(v: Float) {
        if (size == a.size) a = a.copyOf(size * 2)
        a[size++] = v
    }

    fun toArray(): FloatArray = a.copyOf(size)
}

/** Lisitra int mitombo ho azy. */
class IntList(cap: Int = 1024) {
    var a = IntArray(cap)
    var size = 0

    fun add(v: Int) {
        if (size == a.size) a = a.copyOf(size * 2)
        a[size++] = v
    }
}
