package com.terrain3d

import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Teboka iray amin'ny curve lalana: toerana (x,z) sy sakany. */
class RP(var x: Float, var z: Float, var w: Float) {
    fun copy() = RP(x, z, w)
}

class Road(val pts: ArrayList<RP>) {
    fun copy() = Road(ArrayList(pts.map { it.copy() }))
}

/** Valiny momba ny teboka azo fikasihana (snap). */
class Snap(
    val road: Road,
    val isEndpoint: Boolean,
    val atStart: Boolean,
    val x: Float,
    val z: Float,
    val tx: Float,   // tangent mivoaka avy amin'ny tendrony (raha endpoint)
    val tz: Float,
    val w: Float
)

/** Tamba-lalana: lisitry ny lalana (polyline malama). */
class RoadNetwork {
    val roads = ArrayList<Road>()

    fun copy(): RoadNetwork {
        val n = RoadNetwork()
        for (r in roads) n.roads.add(r.copy())
        return n
    }

    private fun outDir(r: Road, atStart: Boolean): FloatArray {
        val a: RP
        val b: RP
        if (atStart) {
            a = r.pts[0]; b = r.pts[1]
        } else {
            a = r.pts[r.pts.size - 1]; b = r.pts[r.pts.size - 2]
        }
        var dx = a.x - b.x
        var dz = a.z - b.z
        val l = hypot(dx, dz)
        if (l > 1e-6f) {
            dx /= l; dz /= l
        }
        return floatArrayOf(dx, dz)
    }

    /** Mitady tendrony akaiky, na raha tsy misy, teboka akaiky eo afovoan'ny lalana. */
    fun findSnap(x: Float, z: Float, radius: Float): Snap? {
        var best: Snap? = null
        var bd = radius
        for (r in roads) {
            val a = r.pts.first()
            val b = r.pts.last()
            val da = hypot(a.x - x, a.z - z)
            if (da < bd) {
                bd = da
                val d = outDir(r, true)
                best = Snap(r, true, true, a.x, a.z, d[0], d[1], a.w)
            }
            val db = hypot(b.x - x, b.z - z)
            if (db < bd) {
                bd = db
                val d = outDir(r, false)
                best = Snap(r, true, false, b.x, b.z, d[0], d[1], b.w)
            }
        }
        if (best != null) return best

        bd = radius
        for (r in roads) {
            for (k in 0 until r.pts.size - 1) {
                val a = r.pts[k]
                val b = r.pts[k + 1]
                val abx = b.x - a.x
                val abz = b.z - a.z
                val l2 = abx * abx + abz * abz
                var t = if (l2 > 1e-9f) ((x - a.x) * abx + (z - a.z) * abz) / l2 else 0f
                t = t.coerceIn(0f, 1f)
                val px = a.x + abx * t
                val pz = a.z + abz * t
                val d = hypot(px - x, pz - z)
                if (d < bd) {
                    bd = d
                    best = Snap(r, false, false, px, pz, 0f, 0f, a.w + (b.w - a.w) * t)
                }
            }
        }
        return best
    }

    private fun arc(p: List<RP>): FloatArray {
        val s = FloatArray(p.size)
        for (i in 1 until p.size) s[i] = s[i - 1] + hypot(p[i].x - p[i - 1].x, p[i].z - p[i - 1].z)
        return s
    }

    private fun chaikin(p: List<RP>): ArrayList<RP> {
        if (p.size < 3) return ArrayList(p.map { it.copy() })
        val o = ArrayList<RP>()
        o.add(p.first().copy())
        for (i in 0 until p.size - 1) {
            val a = p[i]
            val b = p[i + 1]
            o.add(RP(0.75f * a.x + 0.25f * b.x, 0.75f * a.z + 0.25f * b.z, 0.75f * a.w + 0.25f * b.w))
            o.add(RP(0.25f * a.x + 0.75f * b.x, 0.25f * a.z + 0.75f * b.z, 0.25f * a.w + 0.75f * b.w))
        }
        o.add(p.last().copy())
        return o
    }

    private fun resample(p: List<RP>, step: Float): ArrayList<RP> {
        val out = ArrayList<RP>()
        out.add(p[0].copy())
        val cum = arc(p)
        val total = cum[cum.size - 1]
        var k = 0
        var d = step
        while (d < total - step * 0.4f) {
            while (k < p.size - 2 && cum[k + 1] < d) k++
            val seg = cum[k + 1] - cum[k]
            val t = if (seg > 1e-6f) (d - cum[k]) / seg else 0f
            val a = p[k]
            val b = p[k + 1]
            out.add(RP(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t))
            d += step
        }
        out.add(p.last().copy())
        return out
    }

    /**
     * Manampy lalana vaovao avy amin'ny sora-tanana (raw = lisitry [x,z]).
     * - Mamolavola ho curve malama (virage).
     * - Raha akaiky tendrony ny fiandohana/farany => mifandrohy sy mitambatra ho lalana iray.
     * - Raha akaiky ny afovoan'ny lalana => T-junction (mifanindry ny faritra, vita ho azy).
     */
    fun addStroke(raw: List<FloatArray>, width: Float, snapR: Float): Boolean {
        if (raw.size < 2) return false
        var p = ArrayList<RP>()
        for (q in raw) {
            val l = p.lastOrNull()
            if (l == null || hypot(q[0] - l.x, q[1] - l.z) >= 1.0f) p.add(RP(q[0], q[1], width))
        }
        val lr = raw.last()
        val lp = p.last()
        if (hypot(lr[0] - lp.x, lr[1] - lp.z) > 0.3f) p.add(RP(lr[0], lr[1], width))
        if (p.size < 2) return false

        var s = arc(p)
        val total = s[s.size - 1]
        if (total < 3f) return false

        val startSnap = findSnap(p.first().x, p.first().z, snapR)
        val endSnap = findSnap(p.last().x, p.last().z, snapR)

        // sakany: mitovy amin'ny lalana nifandrohy, na miova tsikelikely
        val w0 = startSnap?.w ?: width
        val w1 = endSnap?.w ?: (if (startSnap != null) w0 else width)
        for (i in p.indices) p[i].w = w0 + (w1 - w0) * (s[i] / total)

        // fanintonana: mifindra tsikelikely mankany amin'ny teboka snap
        val len0 = min(8f, total * 0.4f)
        if (startSnap != null) {
            val dx = startSnap.x - p[0].x
            val dz = startSnap.z - p[0].z
            for (i in p.indices) {
                val f = 1f - s[i] / len0
                if (f <= 0f) break
                p[i].x += dx * f
                p[i].z += dz * f
            }
        }
        if (endSnap != null) {
            val n = p.size
            val dx = endSnap.x - p[n - 1].x
            val dz = endSnap.z - p[n - 1].z
            for (i in n - 1 downTo 0) {
                val f = 1f - (total - s[i]) / len0
                if (f <= 0f) break
                p[i].x += dx * f
                p[i].z += dz * f
            }
        }

        // tangent tohiny amin'ny tendrony (mba tsy hisy zoro)
        if (startSnap != null && startSnap.isEndpoint) {
            var k = p.size - 1
            for (i in p.indices) if (s[i] >= 4f) {
                k = i; break
            }
            val vx = p[k].x - p[0].x
            val vz = p[k].z - p[0].z
            val l = hypot(vx, vz)
            if (l > 0.1f && (vx * startSnap.tx + vz * startSnap.tz) / l > 0.2f) {
                val ni = ArrayList<RP>()
                ni.add(p[0])
                ni.add(RP(p[0].x + startSnap.tx * 2.5f, p[0].z + startSnap.tz * 2.5f, p[0].w))
                for (i in 1 until p.size) if (s[i] >= 3.5f || i == p.size - 1) ni.add(p[i])
                p = ni
                s = arc(p)
            }
        }
        if (endSnap != null && endSnap.isEndpoint) {
            val tot = s[s.size - 1]
            val n = p.size
            var k = 0
            for (i in n - 1 downTo 0) if (tot - s[i] >= 4f) {
                k = i; break
            }
            val vx = p[k].x - p[n - 1].x
            val vz = p[k].z - p[n - 1].z
            val l = hypot(vx, vz)
            if (l > 0.1f && (vx * endSnap.tx + vz * endSnap.tz) / l > 0.2f) {
                val ni = ArrayList<RP>()
                for (i in 0 until n - 1) if (i == 0 || tot - s[i] >= 3.5f) ni.add(p[i])
                val e = p[n - 1]
                ni.add(RP(e.x + endSnap.tx * 2.5f, e.z + endSnap.tz * 2.5f, e.w))
                ni.add(e)
                p = ni
                s = arc(p)
            }
        }

        // famolavolana: Chaikin x3 dia resample
        var q: ArrayList<RP> = p
        repeat(3) { q = chaikin(q) }
        val pts = resample(q, 0.8f)
        if (pts.size < 2) return false

        // fitambarana amin'ny lalana efa misy (tendrony)
        var merged: ArrayList<RP> = pts
        var usedA: Road? = null
        if (startSnap != null && startSnap.isEndpoint) {
            val a = startSnap.road
            val ap = ArrayList(a.pts.map { it.copy() })
            if (startSnap.atStart) ap.reverse()      // mifarana amin'ny teboka snap
            val m = ArrayList<RP>(ap)
            for (i in 1 until pts.size) m.add(pts[i])
            merged = m
            roads.remove(a)
            usedA = a
        }
        if (endSnap != null && endSnap.isEndpoint && endSnap.road !== usedA) {
            val b = endSnap.road
            val bp = ArrayList(b.pts.map { it.copy() })
            if (!endSnap.atStart) bp.reverse()       // manomboka amin'ny teboka snap
            val m = ArrayList<RP>(merged)
            for (i in 1 until bp.size) m.add(bp[i])
            merged = m
            roads.remove(b)
        }
        roads.add(Road(merged))
        return true
    }

    private fun segDist(x: Float, z: Float, a: RP, b: RP): Float {
        val abx = b.x - a.x
        val abz = b.z - a.z
        val l2 = abx * abx + abz * abz
        var t = if (l2 > 1e-9f) ((x - a.x) * abx + (z - a.z) * abz) / l2 else 0f
        t = t.coerceIn(0f, 1f)
        return hypot(a.x + abx * t - x, a.z + abz * t - z)
    }

    /** Mamafa ny lalana akaiky indrindra amin'ny teboka (raha ao anatin'ny radius). */
    fun eraseAt(x: Float, z: Float, radius: Float): Boolean {
        var bestR: Road? = null
        var bd = Float.MAX_VALUE
        for (r in roads) {
            for (k in 0 until r.pts.size - 1) {
                val d = segDist(x, z, r.pts[k], r.pts[k + 1]) - r.pts[k].w * 0.5f
                if (d < radius && d < bd) {
                    bd = d
                    bestR = r
                }
            }
        }
        if (bestR != null) {
            roads.remove(bestR)
            return true
        }
        return false
    }
}

/**
 * Quad (na triangle) convex iray amin'ny lalana, miaraka amin'ny half-plane
 * fanapahana sy ny frame ho an'ny UV.
 */
class RoadQuad(
    val n: Int,
    x: FloatArray,
    z: FloatArray,
    val ox: Float,
    val oz: Float,
    val dx: Float,
    val dz: Float,
    val s0: Float,
    val w: Float
) {
    val planes = FloatArray(n * 3)
    var minX = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE
    var minZ = Float.MAX_VALUE
    var maxZ = -Float.MAX_VALUE

    init {
        var area = 0f
        for (k in 0 until n) {
            val j = (k + 1) % n
            area += x[k] * z[j] - x[j] * z[k]
            minX = min(minX, x[k]); maxX = max(maxX, x[k])
            minZ = min(minZ, z[k]); maxZ = max(maxZ, z[k])
        }
        val sgn = if (area >= 0f) 1f else -1f
        for (k in 0 until n) {
            val j = (k + 1) % n
            val a = -(z[j] - z[k]) * sgn
            val b = (x[j] - x[k]) * sgn
            val c = -(a * x[k] + b * z[k])
            planes[3 * k] = a
            planes[3 * k + 1] = b
            planes[3 * k + 2] = c
        }
    }
}

object RoadGeometry {
    /** Manamboatra ny quads rehetra avy amin'ny tamba-lalana. */
    fun buildQuads(net: RoadNetwork): ArrayList<RoadQuad> {
        val out = ArrayList<RoadQuad>()
        for (road in net.roads) {
            val pts = road.pts
            val m = pts.size
            if (m < 2) continue
            val lx = FloatArray(m)
            val lz = FloatArray(m)
            val rx = FloatArray(m)
            val rz = FloatArray(m)
            val cs = FloatArray(m)
            for (i in 0 until m) {
                val a = pts[max(i - 1, 0)]
                val b = pts[min(i + 1, m - 1)]
                var tx = b.x - a.x
                var tz = b.z - a.z
                val len = hypot(tx, tz)
                if (len < 1e-5f) {
                    tx = 1f; tz = 0f
                } else {
                    tx /= len; tz /= len
                }
                val nx = -tz
                val nz = tx
                val hw = pts[i].w * 0.5f
                lx[i] = pts[i].x + nx * hw
                lz[i] = pts[i].z + nz * hw
                rx[i] = pts[i].x - nx * hw
                rz[i] = pts[i].z - nz * hw
                if (i > 0) cs[i] = cs[i - 1] + hypot(pts[i].x - pts[i - 1].x, pts[i].z - pts[i - 1].z)
            }
            for (i in 0 until m - 1) {
                var dx = pts[i + 1].x - pts[i].x
                var dz = pts[i + 1].z - pts[i].z
                val l = hypot(dx, dz)
                if (l < 1e-6f) continue
                dx /= l; dz /= l
                val w = (pts[i].w + pts[i + 1].w) * 0.5f
                val xs = floatArrayOf(lx[i], lx[i + 1], rx[i + 1], rx[i])
                val zs = floatArrayOf(lz[i], lz[i + 1], rz[i + 1], rz[i])

                var area = 0f
                for (k in 0 until 4) {
                    val j = (k + 1) % 4
                    area += xs[k] * zs[j] - xs[j] * zs[k]
                }
                val sgn = if (area >= 0f) 1f else -1f
                var convex = true
                for (k in 0 until 4) {
                    val j = (k + 1) % 4
                    val h = (k + 2) % 4
                    val cr = (xs[j] - xs[k]) * (zs[h] - zs[j]) - (zs[j] - zs[k]) * (xs[h] - xs[j])
                    if (cr * sgn < -1e-4f) convex = false
                }
                if (convex) {
                    out.add(RoadQuad(4, xs, zs, pts[i].x, pts[i].z, dx, dz, cs[i], w))
                } else {
                    out.add(
                        RoadQuad(
                            3, floatArrayOf(xs[0], xs[1], xs[2]), floatArrayOf(zs[0], zs[1], zs[2]),
                            pts[i].x, pts[i].z, dx, dz, cs[i], w
                        )
                    )
                    out.add(
                        RoadQuad(
                            3, floatArrayOf(xs[0], xs[2], xs[3]), floatArrayOf(zs[0], zs[2], zs[3]),
                            pts[i].x, pts[i].z, dx, dz, cs[i], w
                        )
                    )
                }
            }
        }
        return out
    }
}

/** Index spatial: quads isaky ny cell amin'ny grid terrain. */
class RoadIndex(val quads: ArrayList<RoadQuad>) {
    val cells = arrayOfNulls<ArrayList<Int>>(Terrain.CELLS * Terrain.CELLS)

    init {
        for (qi in quads.indices) {
            val q = quads[qi]
            val i0 = floor((q.minX + Terrain.HALF) / Terrain.CELL).toInt().coerceIn(0, Terrain.CELLS - 1)
            val i1 = floor((q.maxX + Terrain.HALF) / Terrain.CELL).toInt().coerceIn(0, Terrain.CELLS - 1)
            val j0 = floor((q.minZ + Terrain.HALF) / Terrain.CELL).toInt().coerceIn(0, Terrain.CELLS - 1)
            val j1 = floor((q.maxZ + Terrain.HALF) / Terrain.CELL).toInt().coerceIn(0, Terrain.CELLS - 1)
            for (j in j0..j1) {
                for (i in i0..i1) {
                    val c = j * Terrain.CELLS + i
                    var l = cells[c]
                    if (l == null) {
                        l = ArrayList()
                        cells[c] = l
                    }
                    l.add(qi)
                }
            }
        }
    }
}
