package com.terrain3d

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Manamboatra ny mesh an'ny chunk iray: ny terrain no TAPAHINA eo amin'ny sisin'ny
 * lalana. Ny triangles ao anatin'ny lalana dia lasa mesh "road" (material hafa),
 * ny hafa mijanona "terrain". Mitovy ny haavo (avy amin'ny plane an'ny triangle).
 *
 * Vertex: pos(3) normal(3) uv(2) = 8 float.
 */
object MeshBuilder {
    private const val TILE = 6f
    private const val MIN_AREA = 2e-6f

    private class Tri {
        val x = FloatArray(3)
        val z = FloatArray(3)
        val y = FloatArray(3)
        val n = FloatArray(9)
        var det = 1f

        private fun put(k: Int, t: Terrain, i: Int, j: Int) {
            x[k] = -Terrain.HALF + i * Terrain.CELL
            z[k] = -Terrain.HALF + j * Terrain.CELL
            val id = j * Terrain.N + i
            y[k] = t.h[id]
            n[3 * k] = t.nrm[3 * id]
            n[3 * k + 1] = t.nrm[3 * id + 1]
            n[3 * k + 2] = t.nrm[3 * id + 2]
        }

        fun set(t: Terrain, i0: Int, j0: Int, i1: Int, j1: Int, i2: Int, j2: Int) {
            put(0, t, i0, j0)
            put(1, t, i1, j1)
            put(2, t, i2, j2)
            det = (z[1] - z[2]) * (x[0] - x[2]) + (x[2] - x[1]) * (z[0] - z[2])
        }

        fun bary(px: Float, pz: Float, out: FloatArray) {
            val l0 = ((z[1] - z[2]) * (px - x[2]) + (x[2] - x[1]) * (pz - z[2])) / det
            val l1 = ((z[2] - z[0]) * (px - x[2]) + (x[0] - x[2]) * (pz - z[2])) / det
            out[0] = l0
            out[1] = l1
            out[2] = 1f - l0 - l1
        }
    }

    private val bw = FloatArray(3)

    /** Miverina [terrainData, roadData]. */
    fun buildChunk(t: Terrain, idx: RoadIndex?, cx: Int, cz: Int): Array<FloatArray> {
        val tOut = FloatList(1 shl 16)
        val rOut = FloatList(1 shl 12)
        val tri = Tri()
        val i0 = cx * Terrain.CHUNK_CELLS
        val j0 = cz * Terrain.CHUNK_CELLS
        for (j in j0 until j0 + Terrain.CHUNK_CELLS) {
            for (i in i0 until i0 + Terrain.CHUNK_CELLS) {
                val qs = idx?.cells?.get(j * Terrain.CELLS + i)
                tri.set(t, i, j, i, j + 1, i + 1, j)
                processTri(tri, qs, idx, tOut, rOut)
                tri.set(t, i + 1, j, i, j + 1, i + 1, j + 1)
                processTri(tri, qs, idx, tOut, rOut)
            }
        }
        return arrayOf(tOut.toArray(), rOut.toArray())
    }

    private fun processTri(
        tri: Tri, qs: List<Int>?, idx: RoadIndex?, tOut: FloatList, rOut: FloatList
    ) {
        val base = floatArrayOf(tri.x[0], tri.z[0], tri.x[1], tri.z[1], tri.x[2], tri.z[2])
        if (qs == null || qs.isEmpty() || idx == null) {
            emitPoly(base, tri, tOut, null)
            return
        }
        var outside = ArrayList<FloatArray>()
        outside.add(base)
        val res = arrayOfNulls<FloatArray>(2)
        for (qi in qs) {
            val q = idx.quads[qi]
            val next = ArrayList<FloatArray>()
            for (poly in outside) {
                if (!overlaps(poly, q)) {
                    next.add(poly)
                    continue
                }
                var cur: FloatArray? = poly
                for (e in 0 until q.n) {
                    val c = cur ?: break
                    split(c, q.planes[3 * e], q.planes[3 * e + 1], q.planes[3 * e + 2], res)
                    val o = res[1]
                    if (o != null) next.add(o)
                    cur = res[0]
                }
                if (cur != null) emitPoly(cur, tri, rOut, q)
            }
            outside = next
        }
        for (poly in outside) emitPoly(poly, tri, tOut, null)
    }

    private fun overlaps(p: FloatArray, q: RoadQuad): Boolean {
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minZ = Float.MAX_VALUE
        var maxZ = -Float.MAX_VALUE
        var k = 0
        while (k < p.size) {
            val x = p[k]
            val z = p[k + 1]
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (z < minZ) minZ = z
            if (z > maxZ) maxZ = z
            k += 2
        }
        return !(maxX < q.minX || minX > q.maxX || maxZ < q.minZ || minZ > q.maxZ)
    }

    private fun area(p: FloatArray, n: Int): Float {
        var a = 0f
        for (k in 0 until n) {
            val j = if (k + 1 == n) 0 else k + 1
            a += p[2 * k] * p[2 * j + 1] - p[2 * j] * p[2 * k + 1]
        }
        return abs(a) * 0.5f
    }

    /** Mizara polygon convex amin'ny half-plane a*x+b*z+c >= 0 (anatiny). res[0]=anatiny, res[1]=ivelany. */
    private fun split(p: FloatArray, a: Float, b: Float, c: Float, res: Array<FloatArray?>) {
        val n = p.size / 2
        val ins = FloatArray(4 * n + 4)
        val outs = FloatArray(4 * n + 4)
        var ni = 0
        var no = 0
        for (k in 0 until n) {
            val j = if (k + 1 == n) 0 else k + 1
            val x0 = p[2 * k]
            val z0 = p[2 * k + 1]
            val x1 = p[2 * j]
            val z1 = p[2 * j + 1]
            val f0 = a * x0 + b * z0 + c
            val f1 = a * x1 + b * z1 + c
            if (f0 >= 0f) {
                ins[2 * ni] = x0; ins[2 * ni + 1] = z0; ni++
            } else {
                outs[2 * no] = x0; outs[2 * no + 1] = z0; no++
            }
            if ((f0 >= 0f) != (f1 >= 0f)) {
                val t = f0 / (f0 - f1)
                val xi = x0 + (x1 - x0) * t
                val zi = z0 + (z1 - z0) * t
                ins[2 * ni] = xi; ins[2 * ni + 1] = zi; ni++
                outs[2 * no] = xi; outs[2 * no + 1] = zi; no++
            }
        }
        res[0] = if (ni >= 3 && area(ins, ni) > MIN_AREA) ins.copyOf(ni * 2) else null
        res[1] = if (no >= 3 && area(outs, no) > MIN_AREA) outs.copyOf(no * 2) else null
    }

    private fun emitPoly(poly: FloatArray, tri: Tri, out: FloatList, q: RoadQuad?) {
        val n = poly.size / 2
        for (k in 1 until n - 1) {
            emitV(tri, poly[0], poly[1], out, q)
            emitV(tri, poly[2 * k], poly[2 * k + 1], out, q)
            emitV(tri, poly[2 * k + 2], poly[2 * k + 3], out, q)
        }
    }

    private fun emitV(tri: Tri, px: Float, pz: Float, out: FloatList, q: RoadQuad?) {
        tri.bary(px, pz, bw)
        val y = bw[0] * tri.y[0] + bw[1] * tri.y[1] + bw[2] * tri.y[2]
        var nx = bw[0] * tri.n[0] + bw[1] * tri.n[3] + bw[2] * tri.n[6]
        var ny = bw[0] * tri.n[1] + bw[1] * tri.n[4] + bw[2] * tri.n[7]
        var nz = bw[0] * tri.n[2] + bw[1] * tri.n[5] + bw[2] * tri.n[8]
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l > 1e-6f) {
            nx /= l; ny /= l; nz /= l
        } else {
            nx = 0f; ny = 1f; nz = 0f
        }
        out.add(px)
        out.add(y)
        out.add(pz)
        out.add(nx)
        out.add(ny)
        out.add(nz)
        if (q == null) {
            out.add((px + Terrain.HALF) / Terrain.SIZE)
            out.add((pz + Terrain.HALF) / Terrain.SIZE)
        } else {
            val rx = px - q.ox
            val rz = pz - q.oz
            val along = rx * q.dx + rz * q.dz
            val lat = -rx * q.dz + rz * q.dx
            out.add(lat / q.w + 0.5f)
            out.add((q.s0 + along) / TILE)
        }
    }
}
