package com.terrain3d

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedWriter
import java.io.IOException
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Mamoaka .obj + .mtl + texture ao amin'ny Download/Terrain3D_<daty>/ */
object Exporter {

    private data class VKey(val a: Int, val b: Int, val c: Int, val d: Int, val e: Int, val g: Int)

    /** Miverina ny anaran'ny lahatahiry nanoratana. */
    fun export(
        ctx: Context,
        tChunks: List<FloatArray>,
        rChunks: List<FloatArray>,
        heights: FloatArray,
        roadBmp: Bitmap
    ): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val folder = "Terrain3D_$stamp"
        val rel = Environment.DIRECTORY_DOWNLOADS + "/" + folder

        writeFile(ctx, rel, "terrain.obj", "application/octet-stream") { os ->
            writeObj(os, tChunks, rChunks)
        }
        writeFile(ctx, rel, "terrain.mtl", "application/octet-stream") { os ->
            val mtl = "newmtl terrain\nKd 1.0 1.0 1.0\nmap_Kd terrain.png\n\n" +
                    "newmtl road\nKd 1.0 1.0 1.0\nmap_Kd road.png\n"
            os.write(mtl.toByteArray(Charsets.UTF_8))
        }
        writeFile(ctx, rel, "terrain.png", "image/png") { os ->
            val bmp = bakeTerrain(heights)
            bmp.compress(Bitmap.CompressFormat.PNG, 100, os)
            bmp.recycle()
        }
        writeFile(ctx, rel, "road.png", "image/png") { os ->
            roadBmp.compress(Bitmap.CompressFormat.PNG, 100, os)
        }
        return "Download/$folder"
    }

    private fun writeFile(
        ctx: Context, rel: String, name: String, mime: String, body: (OutputStream) -> Unit
    ) {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            ?: throw IOException("Tsy afaka namorona fichier: $name")
        val os = ctx.contentResolver.openOutputStream(uri)
            ?: throw IOException("Tsy afaka nanokatra: $name")
        os.use { body(it) }
    }

    // ------------------------------------------------------------------ OBJ
    private fun writeObj(os: OutputStream, tChunks: List<FloatArray>, rChunks: List<FloatArray>) {
        val verts = FloatList(1 shl 20)
        val tIdx = IntList(1 shl 18)
        val rIdx = IntList(1 shl 16)

        fun collect(chunks: List<FloatArray>, outIdx: IntList, group: Int) {
            val map = HashMap<VKey, Int>(1 shl 17)
            for (d in chunks) {
                var p = 0
                while (p < d.size) {
                    val key = VKey(
                        (d[p] * 1000f).roundToInt(),
                        (d[p + 1] * 1000f).roundToInt(),
                        (d[p + 2] * 1000f).roundToInt(),
                        (d[p + 6] * 10000f).roundToInt(),
                        (d[p + 7] * 10000f).roundToInt(),
                        group
                    )
                    var id = map[key]
                    if (id == null) {
                        id = verts.size / 8
                        map[key] = id
                        for (k in 0 until 8) verts.add(d[p + k])
                    }
                    outIdx.add(id)
                    p += 8
                }
            }
        }
        collect(tChunks, tIdx, 0)
        collect(rChunks, rIdx, 1)

        val w = BufferedWriter(OutputStreamWriter(os, Charsets.UTF_8), 1 shl 16)
        val sb = StringBuilder()
        fun flushIf() {
            if (sb.length > (1 shl 15)) {
                w.write(sb.toString()); sb.setLength(0)
            }
        }

        sb.append("# Terrain3D export\nmtllib terrain.mtl\n")
        val nv = verts.size / 8
        val a = verts.a
        for (i in 0 until nv) {
            sb.append("v "); fmt(sb, a[i * 8]); sb.append(' '); fmt(sb, a[i * 8 + 1]); sb.append(' ')
            fmt(sb, a[i * 8 + 2]); sb.append('\n'); flushIf()
        }
        for (i in 0 until nv) {
            // OBJ: v mipoitra miakatra, ka 1 - v (ny sary PNG dia manomboka avy ambony)
            sb.append("vt "); fmt(sb, a[i * 8 + 6]); sb.append(' '); fmt(sb, 1f - a[i * 8 + 7]); sb.append('\n')
            flushIf()
        }
        for (i in 0 until nv) {
            var nx = a[i * 8 + 3]
            var ny = a[i * 8 + 4]
            var nz = a[i * 8 + 5]
            val l = sqrt(nx * nx + ny * ny + nz * nz)
            if (l > 1e-6f) {
                nx /= l; ny /= l; nz /= l
            }
            sb.append("vn "); fmt(sb, nx); sb.append(' '); fmt(sb, ny); sb.append(' '); fmt(sb, nz)
            sb.append('\n'); flushIf()
        }

        fun faces(name: String, mtl: String, idx: IntList) {
            sb.append("g ").append(name).append("\nusemtl ").append(mtl).append('\n')
            var k = 0
            while (k + 2 < idx.size) {
                val i0 = idx.a[k] + 1
                val i1 = idx.a[k + 1] + 1
                val i2 = idx.a[k + 2] + 1
                sb.append("f ").append(i0).append('/').append(i0).append('/').append(i0).append(' ')
                    .append(i1).append('/').append(i1).append('/').append(i1).append(' ')
                    .append(i2).append('/').append(i2).append('/').append(i2).append('\n')
                flushIf()
                k += 3
            }
        }
        faces("terrain", "terrain", tIdx)
        faces("road", "road", rIdx)
        w.write(sb.toString())
        w.flush()
    }

    private fun fmt(sb: StringBuilder, v: Float) {
        var x = v
        if (x < 0f) {
            sb.append('-'); x = -x
        }
        val scaled = Math.round(x.toDouble() * 10000.0)
        sb.append(scaled / 10000)
        sb.append('.')
        val frac = (scaled % 10000).toInt()
        if (frac < 1000) sb.append('0')
        if (frac < 100) sb.append('0')
        if (frac < 10) sb.append('0')
        sb.append(frac)
    }

    // ------------------------------------------------------- texture terrain
    private fun bakeTerrain(h: FloatArray): Bitmap {
        val s = 1024
        val px = IntArray(s * s)
        val e = 0.4f
        for (py in 0 until s) {
            val z = -Terrain.HALF + (py + 0.5f) / s * Terrain.SIZE
            for (pxl in 0 until s) {
                val x = -Terrain.HALF + (pxl + 0.5f) / s * Terrain.SIZE
                val hh = Terrain.sample(h, x, z)
                val gx = (Terrain.sample(h, x - e, z) - Terrain.sample(h, x + e, z)) / (2f * e)
                val gz = (Terrain.sample(h, x, z - e) - Terrain.sample(h, x, z + e)) / (2f * e)
                val ny = 1f / sqrt(gx * gx + 1f + gz * gz)
                px[py * s + pxl] = TerrainColor.argb(hh, ny)
            }
        }
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, s, 0, 0, s, s)
        return bmp
    }
}
