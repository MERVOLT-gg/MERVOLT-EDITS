package com.terrain3d

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** GLSurfaceView izay mandefa ny touch mankany amin'ny thread GL. */
class TerrainGLView(ctx: Context, private val r: TerrainRenderer) : GLSurfaceView(ctx) {
    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 24, 0)
        setRenderer(r)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val action = e.actionMasked
        val skip = if (action == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        for (p in 0 until e.pointerCount) {
            if (p == skip) continue
            xs.add(e.getX(p))
            ys.add(e.getY(p))
        }
        val count = xs.size
        val fx = xs.toFloatArray()
        val fy = ys.toFloatArray()
        queueEvent { r.onTouch(action, count, fx, fy) }
        return true
    }
}

class MainActivity : Activity() {

    private lateinit var glView: TerrainGLView
    private lateinit var renderer: TerrainRenderer
    private val modeButtons = ArrayList<Pair<Button, Int>>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderer = TerrainRenderer(this)
        glView = TerrainGLView(this, renderer)

        val root = FrameLayout(this)
        root.addView(
            glView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(0xCC1E1E1E.toInt())
        panel.setPadding(dp(6), dp(4), dp(6), dp(4))
        panel.isClickable = true   // mba tsy hiditra amin'ny terrain ny touch eto
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            )
        )

        // ---- bokotra
        val scroll = HorizontalScrollView(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        scroll.addView(row)
        panel.addView(scroll)

        fun modeBtn(label: String, mode: Int, hint: String) {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.setTextColor(Color.WHITE)
            b.setOnClickListener {
                renderer.mode = mode
                refreshButtons()
                Toast.makeText(this, hint, Toast.LENGTH_SHORT).show()
            }
            row.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
            modeButtons.add(Pair(b, mode))
        }

        fun actionBtn(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.setTextColor(Color.WHITE)
            b.setBackgroundColor(0xFF6A4C93.toInt())
            b.setOnClickListener { action() }
            row.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        }

        modeBtn("Camera", TerrainRenderer.CAMERA, "1 rantsantanana = mihodina. 2 rantsantanana = zoom, mihodina, mifindra")
        modeBtn("Asandrato", TerrainRenderer.RAISE, "Tsindrio sy alaviro eo amin'ny terrain hampiakatra")
        modeBtn("Ahenao", TerrainRenderer.LOWER, "Tsindrio sy alaviro hampidina")
        modeBtn("Malamao", TerrainRenderer.SMOOTH, "Mampamalama ny terrain")
        modeBtn("Fisaka", TerrainRenderer.FLAT, "Mampitovy haavo amin'ny toerana nitsindrinao")
        modeBtn("Lalana", TerrainRenderer.ROAD, "Soraty amin'ny rantsantanana ny lalana. Akaiky tendrony = mifandrohy ho azy")
        modeBtn("Fafao lalana", TerrainRenderer.ERASE, "Tsindrio ny lalana hofafana")
        actionBtn("Undo") { glView.queueEvent { renderer.undo() } }
        actionBtn("Vaovao") { glView.queueEvent { renderer.newTerrain() } }
        actionBtn("Export OBJ") {
            Toast.makeText(this, "Mamoaka .obj...", Toast.LENGTH_SHORT).show()
            glView.queueEvent { renderer.startExport() }
        }
        refreshButtons()

        // ---- slider
        val sliders = LinearLayout(this)
        sliders.orientation = LinearLayout.HORIZONTAL
        panel.addView(sliders)

        fun slider(label: String, progress: Int, onChange: (Int) -> Unit) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            val tv = TextView(this)
            tv.text = label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            val sb = SeekBar(this)
            sb.max = 100
            sb.progress = progress
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = onChange(p)
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(tv)
            box.addView(sb)
            sliders.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            onChange(progress)
        }

        slider("Habe brush", 35) { renderer.brushRadius = 2f + it * 0.18f }
        slider("Hery", 50) { renderer.strength = 0.05f + it / 100f * 0.95f }
        slider("Sakan'ny lalana", 17) { renderer.roadWidth = 2f + it * 0.06f }

        setContentView(root)
    }

    private fun refreshButtons() {
        for ((b, m) in modeButtons) {
            b.setBackgroundColor(if (m == renderer.mode) 0xFF3D7BFF.toInt() else 0xFF444444.toInt())
        }
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }
}
