package com.terrain3d

import android.graphics.Bitmap
import kotlin.math.abs

/** Loko terrain arakaraka ny haavo sy ny fiolahana (mitovy amin'ny shader). */
object TerrainColor {
    private fun ss(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private val sand = floatArrayOf(0.76f, 0.70f, 0.50f)
    private val grass = floatArrayOf(0.33f, 0.55f, 0.24f)
    private val rock = floatArrayOf(0.45f, 0.42f, 0.40f)
    private val snow = floatArrayOf(0.95f, 0.95f, 0.97f)

    fun argb(h: Float, ny: Float): Int {
        val t1 = ss(0.3f, 1.5f, h)
        val t2 = ss(5.5f, 8.0f, h)
        val t3 = ss(10.0f, 12.0f, h)
        val t4 = ss(0.25f, 0.5f, 1f - ny)
        val rgb = IntArray(3)
        for (k in 0 until 3) {
            var c = sand[k] + (grass[k] - sand[k]) * t1
            c += (rock[k] - c) * t2
            c += (snow[k] - c) * t3
            c += (rock[k] - c) * t4
            rgb[k] = (c * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        return (0xFF shl 24) or (rgb[0] shl 16) or (rgb[1] shl 8) or rgb[2]
    }
}

/** Texture lalana (asphalt + tsipika). 128 x 256; v mihodina isaky ny 6 unit. */
object RoadTexture {
    private fun noise(x: Int, y: Int): Int {
        var n = x * 73856093 xor y * 19349663
        n = (n xor (n ushr 13)) * 1274126177
        return (n ushr 16) and 15
    }

    fun create(): Bitmap {
        val w = 128
        val h = 256
        val px = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val u = (x + 0.5f) / w
                val v = (y + 0.5f) / h
                var r = 58 + noise(x, y)
                var g = 58 + noise(x, y)
                var b = 62 + noise(x, y)
                // sisiny fotsy
                if ((u in 0.05f..0.10f) || (u in 0.90f..0.95f)) {
                    r = 235; g = 235; b = 235
                }
                // tsipika afovoany mitapaka (mavo)
                if (abs(u - 0.5f) < 0.035f && v < 0.5f) {
                    r = 245; g = 205; b = 60
                }
                px[y * w + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }
}
