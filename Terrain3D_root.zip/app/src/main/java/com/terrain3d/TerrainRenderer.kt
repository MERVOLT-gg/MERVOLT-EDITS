package com.terrain3d

import android.app.Activity
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.MotionEvent
import android.widget.Toast
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Ny zava-drehetra (terrain, lalana, touch, GL) dia mandeha amin'ny thread GL ihany
 * (ny touch dia alefa amin'ny queueEvent), ka tsy misy race condition.
 */
class TerrainRenderer(private val activity: Activity) : GLSurfaceView.Renderer {

    companion object {
        const val CAMERA = 0
        const val RAISE = 1
        const val LOWER = 2
        const val SMOOTH = 3
        const val FLAT = 4
        const val ROAD = 5
        const val ERASE = 6
        const val SNAP_R = 4f
    }

    val terrain = Terrain()
    private var network = RoadNetwork()
    private var roadIndex: RoadIndex? = null

    @Volatile var mode = CAMERA
    @Volatile var brushRadius = 8f
    @Volatile var strength = 0.5f
    @Volatile var roadWidth = 3f

    private class Chunk {
        var tVbo = 0
        var rVbo = 0
        var tCount = 0
        var rCount = 0
        var dirty = true
        var tData = FloatArray(0)
        var rData = FloatArray(0)
    }

    private val chunks = Array(Terrain.CHUNKS * Terrain.CHUNKS) { Chunk() }

    private class Snapshot(val h: FloatArray, val net: RoadNetwork)

    private val undoStack = ArrayDeque<Snapshot>()

    // ------------------------------------------------------------------ GL
    private var terrainProg = 0
    private var roadProg = 0
    private var lineProg = 0
    private var uTMvp = 0
    private var uTBrush = 0
    private var uRMvp = 0
    private var uRBrush = 0
    private var uRTex = 0
    private var uLMvp = 0
    private var uLColor = 0
    private var uLSize = 0
    private var uLRound = 0
    private var previewVbo = 0
    private var roadTex = 0
    private var roadBitmap: Bitmap? = null
    private var scratch: FloatBuffer? = null

    private var viewW = 1
    private var viewH = 1
    private var lastNs = 0L

    // ------------------------------------------------------------- camera
    private var yaw = 35f
    private var pitch = 50f
    private var dist = 120f
    private var camTx = 0f
    private var camTz = 0f
    private var camTy = 0f
    private val viewM = FloatArray(16)
    private val projM = FloatArray(16)
    private val vpM = FloatArray(16)
    private val invM = FloatArray(16)

    // -------------------------------------------------------------- touch
    private var touchMode = 0            // 0 tsy misy, 1 rantsantanana iray, 2 roa
    private var lastX = 0f
    private var lastY = 0f
    private var prevDist = 0f
    private var prevAng = 0f
    private var prevMx = 0f
    private var prevMy = 0f

    private var sculpting = false
    private var brushVisible = false
    private var brushX = 0f
    private var brushZ = 0f
    private var flatTarget = 0f

    private var stroke: ArrayList<FloatArray>? = null
    private var startInd: Snap? = null
    private var hoverInd: Snap? = null

    // ============================================================ shaders
    private val vsMesh = "#version 300 es\n" +
            "layout(location=0) in vec3 aP;\n" +
            "layout(location=1) in vec3 aN;\n" +
            "layout(location=2) in vec2 aUV;\n" +
            "uniform mat4 uMVP;\n" +
            "out vec3 vN; out vec3 vP; out vec2 vUV;\n" +
            "void main(){ vN=aN; vP=aP; vUV=aUV; gl_Position=uMVP*vec4(aP,1.0); }\n"

    private val ringCode =
        "float ring(vec3 p, vec4 b){\n" +
                "  float d = length(p.xz - b.xy);\n" +
                "  return b.w * (1.0 - smoothstep(0.0, 0.25, abs(d - b.z)));\n" +
                "}\n"

    private val fsTerrain = "#version 300 es\n" +
            "precision highp float;\n" +
            "in vec3 vN; in vec3 vP; in vec2 vUV;\n" +
            "uniform vec4 uBrush;\n" +
            "out vec4 oC;\n" +
            ringCode +
            "vec3 terrainColor(float h, float ny){\n" +
            "  vec3 sand=vec3(0.76,0.70,0.50); vec3 grass=vec3(0.33,0.55,0.24);\n" +
            "  vec3 rock=vec3(0.45,0.42,0.40); vec3 snow=vec3(0.95,0.95,0.97);\n" +
            "  vec3 c = mix(sand, grass, smoothstep(0.3,1.5,h));\n" +
            "  c = mix(c, rock, smoothstep(5.5,8.0,h));\n" +
            "  c = mix(c, snow, smoothstep(10.0,12.0,h));\n" +
            "  c = mix(c, rock, smoothstep(0.25,0.5,1.0-ny));\n" +
            "  return c;\n" +
            "}\n" +
            "void main(){\n" +
            "  vec3 n = normalize(vN);\n" +
            "  vec3 base = terrainColor(vP.y, n.y);\n" +
            "  float d = max(dot(n, normalize(vec3(0.5,0.8,0.3))), 0.0);\n" +
            "  vec3 col = base * (0.4 + 0.7 * d);\n" +
            "  col = mix(col, vec3(1.0,0.9,0.2), ring(vP, uBrush) * 0.9);\n" +
            "  oC = vec4(col, 1.0);\n" +
            "}\n"

    private val fsRoad = "#version 300 es\n" +
            "precision highp float;\n" +
            "in vec3 vN; in vec3 vP; in vec2 vUV;\n" +
            "uniform vec4 uBrush;\n" +
            "uniform sampler2D uTex;\n" +
            "out vec4 oC;\n" +
            ringCode +
            "void main(){\n" +
            "  vec3 n = normalize(vN);\n" +
            "  vec3 base = texture(uTex, vUV).rgb;\n" +
            "  float d = max(dot(n, normalize(vec3(0.5,0.8,0.3))), 0.0);\n" +
            "  vec3 col = base * (0.4 + 0.7 * d);\n" +
            "  col = mix(col, vec3(1.0,0.9,0.2), ring(vP, uBrush) * 0.9);\n" +
            "  oC = vec4(col, 1.0);\n" +
            "}\n"

    private val vsLine = "#version 300 es\n" +
            "layout(location=0) in vec3 aP;\n" +
            "uniform mat4 uMVP;\n" +
            "uniform float uSize;\n" +
            "void main(){ gl_Position = uMVP * vec4(aP,1.0); gl_PointSize = uSize; }\n"

    private val fsLine = "#version 300 es\n" +
            "precision mediump float;\n" +
            "uniform vec4 uColor;\n" +
            "uniform float uRound;\n" +
            "out vec4 oC;\n" +
            "void main(){\n" +
            "  if (uRound > 0.5 && length(gl_PointCoord - vec2(0.5)) > 0.5) discard;\n" +
            "  oC = uColor;\n" +
            "}\n"

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun program(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    private fun makeTexture(bmp: Bitmap): Int {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        return t[0]
    }

    // ======================================================= GL callbacks
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.55f, 0.72f, 0.88f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)

        terrainProg = program(vsMesh, fsTerrain)
        uTMvp = GLES20.glGetUniformLocation(terrainProg, "uMVP")
        uTBrush = GLES20.glGetUniformLocation(terrainProg, "uBrush")

        roadProg = program(vsMesh, fsRoad)
        uRMvp = GLES20.glGetUniformLocation(roadProg, "uMVP")
        uRBrush = GLES20.glGetUniformLocation(roadProg, "uBrush")
        uRTex = GLES20.glGetUniformLocation(roadProg, "uTex")

        lineProg = program(vsLine, fsLine)
        uLMvp = GLES20.glGetUniformLocation(lineProg, "uMVP")
        uLColor = GLES20.glGetUniformLocation(lineProg, "uColor")
        uLSize = GLES20.glGetUniformLocation(lineProg, "uSize")
        uLRound = GLES20.glGetUniformLocation(lineProg, "uRound")

        val ids = IntArray(chunks.size * 2 + 1)
        GLES20.glGenBuffers(ids.size, ids, 0)
        for (i in chunks.indices) {
            val c = chunks[i]
            c.tVbo = ids[2 * i]
            c.rVbo = ids[2 * i + 1]
            c.tCount = 0
            c.rCount = 0
            c.dirty = true
        }
        previewVbo = ids[ids.size - 1]

        val bmp = roadBitmap ?: RoadTexture.create().also { roadBitmap = it }
        roadTex = makeTexture(bmp)

        rebuildRoadIndex()
        lastNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewW = max(1, width)
        viewH = max(1, height)
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = min((now - lastNs) / 1e9f, 0.05f)
        lastNs = now

        val m = mode
        if (sculpting && m in RAISE..FLAT) {
            terrain.brush(m - 1, brushX, brushZ, brushRadius, strength, dt, flatTarget)
            markDirtyRect(terrain.dI0, terrain.dI1, terrain.dJ0, terrain.dJ1)
        }
        rebuildDirty(8_000_000L)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        updateCamera()
        drawTerrain()
        drawRoads()
        drawPreview()
    }

    // ============================================================ camera
    private fun updateCamera() {
        camTy = terrain.heightAt(camTx, camTz)
        val yr = Math.toRadians(yaw.toDouble()).toFloat()
        val pr = Math.toRadians(pitch.toDouble()).toFloat()
        val cp = cos(pr)
        val ex = camTx + dist * cp * sin(yr)
        val ey = camTy + dist * sin(pr)
        val ez = camTz + dist * cp * cos(yr)
        Matrix.setLookAtM(viewM, 0, ex, ey, ez, camTx, camTy, camTz, 0f, 1f, 0f)
        Matrix.perspectiveM(projM, 0, 50f, viewW.toFloat() / viewH.toFloat(), 0.5f, 600f)
        Matrix.multiplyMM(vpM, 0, projM, 0, viewM, 0)
    }

    // ============================================================ drawing
    private fun bindMesh(vbo: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, 32, 0)
        GLES20.glEnableVertexAttribArray(1)
        GLES20.glVertexAttribPointer(1, 3, GLES20.GL_FLOAT, false, 32, 12)
        GLES20.glEnableVertexAttribArray(2)
        GLES20.glVertexAttribPointer(2, 2, GLES20.GL_FLOAT, false, 32, 24)
    }

    private fun brushShown(): Float = if (brushVisible && mode in RAISE..FLAT) 1f else 0f

    private fun drawTerrain() {
        GLES20.glUseProgram(terrainProg)
        GLES20.glUniformMatrix4fv(uTMvp, 1, false, vpM, 0)
        GLES20.glUniform4f(uTBrush, brushX, brushZ, brushRadius, brushShown())
        for (c in chunks) {
            if (c.tCount == 0) continue
            bindMesh(c.tVbo)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, c.tCount)
        }
    }

    private fun drawRoads() {
        GLES20.glUseProgram(roadProg)
        GLES20.glUniformMatrix4fv(uRMvp, 1, false, vpM, 0)
        GLES20.glUniform4f(uRBrush, brushX, brushZ, brushRadius, brushShown())
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, roadTex)
        GLES20.glUniform1i(uRTex, 0)
        for (c in chunks) {
            if (c.rCount == 0) continue
            bindMesh(c.rVbo)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, c.rCount)
        }
    }

    private fun drawPreview() {
        val s = stroke ?: return
        GLES20.glUseProgram(lineProg)
        GLES20.glUniformMatrix4fv(uLMvp, 1, false, vpM, 0)
        GLES20.glDisableVertexAttribArray(1)
        GLES20.glDisableVertexAttribArray(2)
        val n = s.size
        if (n >= 2) {
            val arr = FloatArray(n * 3)
            for (i in 0 until n) {
                arr[i * 3] = s[i][0]
                arr[i * 3 + 1] = terrain.heightAt(s[i][0], s[i][1]) + 0.4f
                arr[i * 3 + 2] = s[i][1]
            }
            upload(previewVbo, arr, arr.size)
            GLES20.glEnableVertexAttribArray(0)
            GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, 12, 0)
            GLES20.glUniform4f(uLColor, 1f, 0.85f, 0.1f, 1f)
            GLES20.glUniform1f(uLSize, 1f)
            GLES20.glUniform1f(uLRound, 0f)
            GLES20.glLineWidth(4f)
            GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, 0, n)
        }
        val pts = ArrayList<Snap>()
        startInd?.let { pts.add(it) }
        hoverInd?.let { pts.add(it) }
        if (pts.isNotEmpty()) {
            val arr = FloatArray(pts.size * 3)
            for (i in pts.indices) {
                arr[i * 3] = pts[i].x
                arr[i * 3 + 1] = terrain.heightAt(pts[i].x, pts[i].z) + 0.6f
                arr[i * 3 + 2] = pts[i].z
            }
            upload(previewVbo, arr, arr.size)
            GLES20.glEnableVertexAttribArray(0)
            GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, 12, 0)
            GLES20.glUniform4f(uLColor, 1f, 0.2f, 0.2f, 1f)
            GLES20.glUniform1f(uLSize, 26f)
            GLES20.glUniform1f(uLRound, 1f)
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, pts.size)
        }
    }

    // ============================================================ meshes
    private fun upload(vbo: Int, data: FloatArray, len: Int) {
        var b = scratch
        if (b == null || b.capacity() < len) {
            b = ByteBuffer.allocateDirect(max(len, 1 shl 16) * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            scratch = b
        }
        b!!.clear()
        b.put(data, 0, len)
        b.flip()
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, len * 4, b, GLES20.GL_DYNAMIC_DRAW)
    }

    private fun rebuildChunk(ci: Int) {
        val c = chunks[ci]
        val cx = ci % Terrain.CHUNKS
        val cz = ci / Terrain.CHUNKS
        val r = MeshBuilder.buildChunk(terrain, roadIndex, cx, cz)
        c.tData = r[0]
        c.rData = r[1]
        if (r[0].isNotEmpty()) upload(c.tVbo, r[0], r[0].size)
        if (r[1].isNotEmpty()) upload(c.rVbo, r[1], r[1].size)
        c.tCount = r[0].size / 8
        c.rCount = r[1].size / 8
        c.dirty = false
    }

    private fun rebuildDirty(budgetNs: Long) {
        val start = System.nanoTime()
        for (i in chunks.indices) {
            if (!chunks[i].dirty) continue
            rebuildChunk(i)
            if (System.nanoTime() - start > budgetNs) break
        }
    }

    private fun markAllDirty() {
        for (c in chunks) c.dirty = true
    }

    private fun markDirtyRect(i0: Int, i1: Int, j0: Int, j1: Int) {
        val ca = max(0, i0 - 2) / Terrain.CHUNK_CELLS
        val cb = min(Terrain.CELLS - 1, i1 + 1) / Terrain.CHUNK_CELLS
        val da = max(0, j0 - 2) / Terrain.CHUNK_CELLS
        val db = min(Terrain.CELLS - 1, j1 + 1) / Terrain.CHUNK_CELLS
        for (cz in da..db) for (cx in ca..cb) chunks[cz * Terrain.CHUNKS + cx].dirty = true
    }

    private fun rebuildRoadIndex() {
        roadIndex = if (network.roads.isEmpty()) {
            null
        } else {
            val q = RoadGeometry.buildQuads(network)
            if (q.isEmpty()) null else RoadIndex(q)
        }
    }

    private fun roadsChanged() {
        rebuildRoadIndex()
        markAllDirty()
    }

    // ============================================================= undo
    private fun pushUndo() {
        undoStack.addLast(Snapshot(terrain.h.copyOf(), network.copy()))
        if (undoStack.size > 15) undoStack.removeFirst()
    }

    fun undo() {
        val s = undoStack.removeLastOrNull() ?: return
        terrain.h = s.h
        terrain.updateNormals(0, Terrain.N - 1, 0, Terrain.N - 1)
        network = s.net
        roadsChanged()
    }

    fun newTerrain() {
        pushUndo()
        terrain.generate((System.nanoTime() and 0xFFFF).toInt())
        network = RoadNetwork()
        roadsChanged()
    }

    // ============================================================= picking
    private val tmp4 = FloatArray(4)
    private val tmpIn = FloatArray(4)

    private fun unproject(nx: Float, ny: Float, nz: Float, out: FloatArray) {
        tmpIn[0] = nx; tmpIn[1] = ny; tmpIn[2] = nz; tmpIn[3] = 1f
        Matrix.multiplyMV(tmp4, 0, invM, 0, tmpIn, 0)
        val w = if (abs(tmp4[3]) < 1e-9f) 1f else tmp4[3]
        out[0] = tmp4[0] / w
        out[1] = tmp4[1] / w
        out[2] = tmp4[2] / w
    }

    /** Raycast avy amin'ny toerana eo amin'ny efijery mankany amin'ny terrain. Miverina [x, z]. */
    private fun pick(sx: Float, sy: Float): FloatArray? {
        val nx = 2f * sx / viewW - 1f
        val ny = 1f - 2f * sy / viewH
        if (!Matrix.invertM(invM, 0, vpM, 0)) return null
        val o = FloatArray(3)
        val f = FloatArray(3)
        unproject(nx, ny, -1f, o)
        unproject(nx, ny, 1f, f)
        val d = floatArrayOf(f[0] - o[0], f[1] - o[1], f[2] - o[2])
        val len = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
        if (len < 1e-6f) return null
        for (k in 0..2) d[k] /= len

        val lo = floatArrayOf(-Terrain.HALF, Terrain.MIN_H, -Terrain.HALF)
        val hi = floatArrayOf(Terrain.HALF, Terrain.MAX_H, Terrain.HALF)
        var tmin = 0f
        var tmax = len
        for (a in 0..2) {
            if (abs(d[a]) < 1e-8f) {
                if (o[a] < lo[a] || o[a] > hi[a]) return null
            } else {
                var t1 = (lo[a] - o[a]) / d[a]
                var t2 = (hi[a] - o[a]) / d[a]
                if (t1 > t2) {
                    val tt = t1; t1 = t2; t2 = tt
                }
                tmin = max(tmin, t1)
                tmax = min(tmax, t2)
                if (tmin > tmax) return null
            }
        }
        var t = tmin
        var prevT = tmin
        while (t <= tmax) {
            val x = o[0] + d[0] * t
            val y = o[1] + d[1] * t
            val z = o[2] + d[2] * t
            if (y <= terrain.heightAt(x, z)) {
                var a = prevT
                var b = t
                for (it in 0 until 8) {
                    val m = (a + b) * 0.5f
                    val mx = o[0] + d[0] * m
                    val my = o[1] + d[1] * m
                    val mz = o[2] + d[2] * m
                    if (my <= terrain.heightAt(mx, mz)) b = m else a = m
                }
                val hx = (o[0] + d[0] * b).coerceIn(-Terrain.HALF, Terrain.HALF)
                val hz = (o[2] + d[2] * b).coerceIn(-Terrain.HALF, Terrain.HALF)
                return floatArrayOf(hx, hz)
            }
            prevT = t
            t += 0.25f
        }
        return null
    }

    // ============================================================== touch
    fun onTouch(action: Int, count: Int, xs: FloatArray, ys: FloatArray) {
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                touchMode = 1
                lastX = xs[0]
                lastY = ys[0]
                beginTool(xs[0], ys[0])
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                cancelTool()
                if (count >= 2) {
                    touchMode = 2
                    initMulti(xs, ys)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (touchMode == 1 && count == 1) moveSingle(xs[0], ys[0])
                else if (touchMode == 2 && count >= 2) moveMulti(xs, ys)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (count >= 2) {
                    touchMode = 2
                    initMulti(xs, ys)
                } else {
                    touchMode = 0
                }
            }
            MotionEvent.ACTION_UP -> {
                if (touchMode == 1) endTool()
                touchMode = 0
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelTool()
                touchMode = 0
            }
        }
    }

    private fun initMulti(xs: FloatArray, ys: FloatArray) {
        prevDist = hypot(xs[1] - xs[0], ys[1] - ys[0])
        prevAng = atan2(ys[1] - ys[0], xs[1] - xs[0])
        prevMx = (xs[0] + xs[1]) * 0.5f
        prevMy = (ys[0] + ys[1]) * 0.5f
    }

    private fun moveMulti(xs: FloatArray, ys: FloatArray) {
        val d = hypot(xs[1] - xs[0], ys[1] - ys[0])
        if (prevDist > 1f && d > 1f) dist = (dist * prevDist / d).coerceIn(15f, 250f)
        val ang = atan2(ys[1] - ys[0], xs[1] - xs[0])
        var da = ang - prevAng
        while (da > PI) da -= (2 * PI).toFloat()
        while (da < -PI) da += (2 * PI).toFloat()
        yaw += Math.toDegrees(da.toDouble()).toFloat()
        val mx = (xs[0] + xs[1]) * 0.5f
        val my = (ys[0] + ys[1]) * 0.5f
        val dx = mx - prevMx
        val dy = my - prevMy
        val k = dist * 0.0012f
        val yr = Math.toRadians(yaw.toDouble()).toFloat()
        val rx = cos(yr)
        val rz = -sin(yr)
        val fx = -sin(yr)
        val fz = -cos(yr)
        camTx = (camTx - rx * dx * k + fx * dy * k).coerceIn(-Terrain.HALF, Terrain.HALF)
        camTz = (camTz - rz * dx * k + fz * dy * k).coerceIn(-Terrain.HALF, Terrain.HALF)
        prevDist = d
        prevAng = ang
        prevMx = mx
        prevMy = my
    }

    private fun beginTool(x: Float, y: Float) {
        val m = mode
        if (m == CAMERA) return
        val hit = pick(x, y) ?: return
        when (m) {
            RAISE, LOWER, SMOOTH, FLAT -> {
                pushUndo()
                sculpting = true
                brushVisible = true
                brushX = hit[0]
                brushZ = hit[1]
                flatTarget = terrain.heightAt(hit[0], hit[1])
            }
            ROAD -> {
                val s = ArrayList<FloatArray>()
                s.add(floatArrayOf(hit[0], hit[1]))
                stroke = s
                startInd = network.findSnap(hit[0], hit[1], SNAP_R)
                hoverInd = null
            }
            ERASE -> eraseAt(hit[0], hit[1])
        }
    }

    private fun eraseAt(x: Float, z: Float) {
        val snap = Snapshot(terrain.h.copyOf(), network.copy())
        if (network.eraseAt(x, z, max(1.5f, roadWidth))) {
            undoStack.addLast(snap)
            if (undoStack.size > 15) undoStack.removeFirst()
            roadsChanged()
        }
    }

    private fun moveSingle(x: Float, y: Float) {
        val dx = x - lastX
        val dy = y - lastY
        lastX = x
        lastY = y
        val m = mode
        if (m == CAMERA) {
            yaw -= dx * 0.35f
            pitch = (pitch + dy * 0.25f).coerceIn(8f, 88f)
            return
        }
        val hit = pick(x, y) ?: return
        when (m) {
            RAISE, LOWER, SMOOTH, FLAT -> {
                if (sculpting) {
                    brushX = hit[0]
                    brushZ = hit[1]
                }
            }
            ROAD -> {
                val s = stroke ?: return
                val l = s[s.size - 1]
                if (hypot(hit[0] - l[0], hit[1] - l[1]) >= 0.5f) s.add(floatArrayOf(hit[0], hit[1]))
                hoverInd = network.findSnap(hit[0], hit[1], SNAP_R)
            }
            ERASE -> eraseAt(hit[0], hit[1])
        }
    }

    private fun endTool() {
        sculpting = false
        brushVisible = false
        val s = stroke
        stroke = null
        startInd = null
        hoverInd = null
        if (s != null && s.size >= 2) {
            val snap = Snapshot(terrain.h.copyOf(), network.copy())
            if (network.addStroke(s, roadWidth, SNAP_R)) {
                undoStack.addLast(snap)
                if (undoStack.size > 15) undoStack.removeFirst()
                roadsChanged()
            }
        }
    }

    private fun cancelTool() {
        sculpting = false
        brushVisible = false
        stroke = null
        startInd = null
        hoverInd = null
    }

    // ============================================================= export
    private fun toast(msg: String) {
        activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_LONG).show() }
    }

    fun startExport() {
        for (i in chunks.indices) if (chunks[i].dirty) rebuildChunk(i)
        val t = chunks.map { it.tData }
        val r = chunks.map { it.rData }
        val hs = terrain.h.copyOf()
        val bmp = roadBitmap ?: RoadTexture.create()
        Thread {
            try {
                val where = Exporter.export(activity, t, r, hs, bmp)
                toast("Vita! Fichier ao amin'ny: $where")
            } catch (e: Exception) {
                toast("Tsy nahomby ny export: " + e.message)
            }
        }.start()
    }
}
