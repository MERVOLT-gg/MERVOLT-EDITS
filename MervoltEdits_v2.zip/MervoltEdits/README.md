# MERVOLT EDITS — version évoluée

## Fanamboarana
- Road: tsindrio `Road vita` rehefa vita ny teboka. Ny courbe Catmull-Rom sy ny raccordement amin'ny tendrony dia manalefaka ny fiolahana.
- Gen > `Karazana`: Terrain, Carrefour, Rond-point, Objet, Poto Jirama, Traffic.
- Carrefour / Rond-point: apetraho eo afovoan'ny fihaonan-dalana ny point iray, dia `Generate`.
- Objet: import-o ny `.obj`, safidio ilay objet, apetraho amin'ny mode Gen ny points, dia `Generate`. Objet iray no apetraka isaky ny point ary snap amin'ny terrain.
- Poto Jirama: apetraho ny points manaraka ny lalana, dia `Generate`. Poto iray isaky ny point; rehefa misy point faharoa vao miforona ny fil roa mampitohy azy.
- Traffic: vitao aloha ny road, import-o ary safidio ny véhicule `.obj`, dia tsindrio `Generate traffic`. Azo safidiana sy afindra tsirairay ireo véhicules. `Re-snap traffic` no mampamerina azy ireo eo ambonin'ny terrain.
- Ny traffic taloha izay namboarina ho azy isaky ny rebuild road dia nesorina. Ny traffic vaovao dia OBJ misaraka amin'ny matériau road.

## Fananganana APK
**Android Studio:** File > Open > sokafy ity dossier ity > Build > Build APK(s).

**GitHub Actions:** alefaso ao amin'ny repository GitHub, avy eo Actions > Build APK > alaivo ny artifact `MervoltEdits-apk`.

## Fanamarihana
- Mbola tazonina ny terrain, sculpt, textures, import/export OBJ, profils, Undo/Redo ary ny mesh carré/carré efa nisy.
- Tsy niova ny format de sauvegarde fototra; ireo objets générés dia tehirizina miaraka amin'ny projet.
