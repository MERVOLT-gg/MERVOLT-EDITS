package com.mervolt.edits

import kotlin.math.*

/** Road mipetaka amin'ny terrain + carré traffic (toy ny ecalier: mifandimby tsy misy banga, manaraka ny tany). */
object Road {
    var width = 4f; var lanes = 2; var spacing = 2f; var quad = 1f; var lift = 0.06f

    private fun cr(a: Float, b: Float, c: Float, d: Float, t: Float) =
        0.5f * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t * t * t)

    private fun dense(p: List<FloatArray>): List<FloatArray> {
        val out = ArrayList<FloatArray>(); val last = p.size - 1
        for (i in 0 until last) {
            val p0 = p[max(i - 1, 0)]; val p1 = p[i]; val p2 = p[i + 1]; val p3 = p[min(i + 2, last)]
            for (s in 0 until 16) { val t = s / 16f
                out.add(floatArrayOf(cr(p0[0], p1[0], p2[0], p3[0], t), cr(p0[1], p1[1], p2[1], p3[1], t))) }
        }
        out.add(p[last]); return out
    }

    /** Elanelana mitovy araka ny halavan'ny lalana 3D (miakatra/midina). */
    private fun resample(d: List<FloatArray>, step: Float, t: Terrain): List<FloatArray> {
        val out = ArrayList<FloatArray>(); out.add(d[0]); var acc = 0f
        for (i in 1 until d.size) {
            val a = d[i - 1]; val b = d[i]
            val dy = t.height(b[0], b[1]) - t.height(a[0], a[1])
            val len = sqrt((b[0] - a[0]).pow(2) + dy * dy + (b[1] - a[1]).pow(2))
            if (len < 1e-5f) continue
            var pos = step - acc
            while (pos <= len) { val f = pos / len
                out.add(floatArrayOf(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)); pos += step }
            acc = len - (pos - step)
        }
        return out
    }

    private fun right(a: FloatArray, b: FloatArray): FloatArray? {
        val dx = b[0] - a[0]; val dz = b[1] - a[1]; val l = sqrt(dx * dx + dz * dz)
        return if (l < 1e-4f) null else floatArrayOf(-dz / l, dx / l)
    }

    fun build(ctrl: List<FloatArray>, t: Terrain): List<Part> {
        val d = dense(ctrl); val out = ArrayList<Part>()
        // Mesh road = carré foana (isa-carré = sakany/cols, ohatra 1x1). UV: u 0..1 manodidina ny sakany, v miverina isaky ny sakany.
        val cols = max(1, width.roundToInt()); val cell = width / cols
        val rs = resample(d, cell, t)
        val pos = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>()
        for (i in rs.indices) {
            val r = right(rs[max(i - 1, 0)], rs[min(i + 1, rs.lastIndex)]) ?: floatArrayOf(0f, 1f)
            val c = rs[i]
            for (k in 0..cols) {
                val off = (k - cols / 2f) * cell
                val x = c[0] + r[0] * off; val z = c[1] + r[1] * off
                pos.add(x); pos.add(t.height(x, z) + lift); pos.add(z)
                uv.add(k / cols.toFloat()); uv.add(i * cell / width)
            }
            if (i > 0) for (k in 0 until cols) {
                val p0 = (i - 1) * (cols + 1) + k; val p1 = p0 + 1; val p2 = i * (cols + 1) + k; val p3 = p2 + 1
                idx.addAll(listOf(p0, p1, p3, p0, p3, p2))
            }
        }
        if (rs.size > 1) out.add(Part("road", Mat("road").apply { kd = floatArrayOf(0.25f, 0.25f, 0.27f) },
            pos.toFloatArray(), uv.toFloatArray(), idx.toIntArray()))

        val tr = resample(d, spacing, t); val tm = Mat("traffic").apply { kd = floatArrayOf(1f, 0.25f, 0.25f) }
        val offs = if (lanes <= 1) listOf(0f) else (0 until lanes).map { (it - (lanes - 1) / 2f) * (width / lanes) }
        var n = 1
        for (o in offs) for (i in tr.indices) {
            val c = tr[i]
            val bk = if (i == 0) c else floatArrayOf((tr[i - 1][0] + c[0]) / 2, (tr[i - 1][1] + c[1]) / 2)
            val fr = if (i == tr.lastIndex) c else floatArrayOf((tr[i + 1][0] + c[0]) / 2, (tr[i + 1][1] + c[1]) / 2)
            val r = right(bk, fr) ?: continue
            val cs = listOf(bk to (o - quad / 2), bk to (o + quad / 2), fr to (o + quad / 2), fr to (o - quad / 2))
            val p = ArrayList<Float>()
            for ((q, off) in cs) { val x = q[0] + r[0] * off; val z = q[1] + r[1] * off
                p.add(x); p.add(t.height(x, z) + lift * 2); p.add(z) }
            out.add(Part("traffic_%03d".format(n++), tm, p.toFloatArray(), FloatArray(8), intArrayOf(0, 1, 2, 0, 2, 3)))
        }
        return out
    }
}
