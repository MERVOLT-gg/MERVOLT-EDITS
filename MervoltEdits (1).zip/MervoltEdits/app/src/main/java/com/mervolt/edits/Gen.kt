package com.mervolt.edits

import kotlin.math.*

/** Mamorona ny endriky ny terrain manodidina ny lalana: plate 5 m, avy eo profil (havoana / mianjera) amin'ny sisiny roa, ary rampe (rise). */
object Gen {
    var flat = 5f
    val names = arrayOf("Havoana havanana", "Havoana havia", "Midina roa tonta", "Miakatra roa tonta")

    private class Nr(val d: Float, val lat: Float, val i: Int, val u: Float)

    private fun nearest(rs: List<Row>, x: Float, z: Float): Nr {
        var bd = 1e18f; var bi = 0; var bu = 0f; var lat = 0f
        for (q in 0 until rs.size - 1) {
            val a = rs[q]; val b = rs[q + 1]; val dx = b.cx - a.cx; val dz = b.cz - a.cz; val l2 = dx * dx + dz * dz
            if (l2 < 1e-9f) continue
            val u = (((x - a.cx) * dx + (z - a.cz) * dz) / l2).coerceIn(0f, 1f); val px = a.cx + dx * u; val pz = a.cz + dz * u
            val d2 = (x - px) * (x - px) + (z - pz) * (z - pz)
            if (d2 < bd) { bd = d2; bi = q; bu = u; lat = ((x - px) * -dz + (z - pz) * dx) / sqrt(l2) }
        }
        return Nr(sqrt(bd), lat, bi, bu)
    }

    /** rs = lalana (andalana 1 m). others = lalana generate teo aloha (tsy simbana: ny tany akaiky azy no azy). */
    fun apply(ts: List<Terrain>, rs: List<Row>, profile: Int, rise: Float, hf: (Float, Float) -> Float, others: List<List<Row>>) {
        val n = rs.size; if (n < 2) return
        val base = FloatArray(n) { hf(rs[it].cx, rs[it].cz) }
        val sm = FloatArray(n) { i -> var s = 0f; var c = 0; for (k in max(0, i - 8)..min(n - 1, i + 8)) { s += base[k]; c++ }; s / c }   // lalana malama
        val total = max(1f, rs.last().s)
        val hc = FloatArray(n) { sm[it] + rise * rs[it].s / total }                                                                 // rampe: fiakarana/fidinana
        val half = Road.width / 2 + flat; val reach = 60f
        val minx = rs.minOf { it.cx } - reach; val maxx = rs.maxOf { it.cx } + reach; val minz = rs.minOf { it.cz } - reach; val maxz = rs.maxOf { it.cz } + reach
        val aff = HashMap<Terrain, ArrayList<Pair<Int, Float>>>()
        for (t in ts) for (j in 0 until t.n) for (i in 0 until t.n) {
            val x = t.ox + t.cc(i); val z = t.oz + t.cc(j)
            if (x < minx || x > maxx || z < minz || z > maxz) continue
            val nr = nearest(rs, x, z); val a = nr.d; if (a > reach) continue
            var skip = false
            for (o in others) if (o.size >= 2 && nearest(o, x, z).d + 0.5f < a) { skip = true; break }
            if (skip) continue
            val hcAt = hc[nr.i] + (hc[nr.i + 1] - hc[nr.i]) * nr.u
            val m = max(0f, a - half)
            val hill = when (profile) { 0 -> nr.lat > 0; 1 -> nr.lat < 0; 2 -> false; else -> true }
            val e = m - 6f * (1 - exp(-m / 6f))                        // fanombohana malama (tsy misy kink)
            val amp = if (hill) 14f else 10f; val slope = if (hill) 0.55f else 0.45f
            val off = (if (hill) 1f else -1f) * amp * tanh(slope * e / amp)
            val noise = (sin(x * 0.13f) * cos(z * 0.17f) + 0.5f * sin(x * 0.31f + z * 0.23f)) * min(1f, m / 15f) * 1.2f
            val w = if (a <= 30f) 1f else { val u = ((a - 30f) / (reach - 30f)).coerceIn(0f, 1f); 1 - u * u * (3 - 2 * u) }
            val k = j * t.n + i
            t.setH(k, t.h[k] * (1 - w) + (hcAt + off + noise) * w)
            aff.getOrPut(t) { ArrayList() }.add(k to a)
        }
        repeat(2) {   // famafana ivelan'ny lalana (tsy mikasika ny fandrosoan'ny road)
            for ((t, l) in aff) {
                val cp = t.h.copyOf(); val nn = t.n
                for ((k, a) in l) {
                    if (a <= half) continue
                    val i = k % nn; val j = k / nn
                    val avg = (cp[j * nn + max(i - 1, 0)] + cp[j * nn + min(i + 1, nn - 1)] + cp[max(j - 1, 0) * nn + i] + cp[min(j + 1, nn - 1) * nn + i]) / 4f
                    t.setH(k, cp[k] * 0.5f + avg * 0.5f)
                }
            }
        }
    }
}
